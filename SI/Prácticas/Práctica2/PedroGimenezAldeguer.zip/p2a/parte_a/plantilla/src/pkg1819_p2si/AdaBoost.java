/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

/**
 *
 * @author phado
 */
class ClasificadorDebil{
    
    public static final int DIMENSIONES = 784;
    public static final int MAX_VALUE = 255;
    
    ArrayList<Double> hiperplano;
    private double terminoIndependiente;
    private double Confio;
    private double error;
    
    public ArrayList<Double> getHiperplano(){
        return hiperplano;
    }
    
    public double getTermino(){
        return terminoIndependiente;
    }
    
    public ClasificadorDebil(ArrayList<Double> hiper, double termino, double confio){
        this.hiperplano = new ArrayList<>();
        for(int i = 0; i < hiper.size(); i++){
            hiperplano.add(hiper.get(i));
        }        
        terminoIndependiente = termino;
        Confio = confio;
    }
        
    public ClasificadorDebil(){
        this.hiperplano = new ArrayList<>();
        terminoIndependiente = 0;
        Confio = 0;
        error = 0;
    }
    
    public void generarClasificadorAzar(){
                  
        //Generar vector normal aleatorio
        for(int i = 0; i < DIMENSIONES; i++){
            double dato;
            int p = (int)(Math.random()*(2));
            if(p == 1){
                dato = (int)(Math.random()*(-11));
            }else{
                dato = (int)(Math.random()*(11));
            }
            //System.out.println (dato);
            hiperplano.add(dato);
        }
        
        //Normalizar el vector (V y W) Vectores unitarios
        double modulo = 0;
        for (int i = 0; i < DIMENSIONES; i++){
            modulo += hiperplano.get(i) * hiperplano.get(i);
        }
        modulo = (Math.sqrt(modulo));
        double x;
        for (int i = 0; i < DIMENSIONES; i++){
           x = hiperplano.get(i);
           x = x/modulo;
           hiperplano.set(i, x);
        }
        
        //Valor del termino independiente
        double y;
        for (int i = 0; i < DIMENSIONES; i++){
            
            y = hiperplano.get(i) * ((int) (Math.random() * 256));
            //System.out.println (y);
            terminoIndependiente -= y;
            //System.out.println (terminoIndependiente);
        }
    }
    
    // 1 o -1 para saber en que lado esta
    public Boolean[] aplicarClasificadorDebil(ArrayList<Imagen> datos){
        Boolean [] resultado = new Boolean [datos.size()];
        
        Double cosas = 0.0;
        
        Imagen x;
        
        //Recorremos las imágenes
        for(int i = 0; i < datos.size(); i++){
            x = datos.get(i);
            byte [] imagen = x.getImageData();
            
            for(int j = 0; j < hiperplano.size(); j++){
               cosas += hiperplano.get(j) * (imagen[j] & 0xff); //(coges el vector normal y una imagen)
            }
            
            //System.out.println (cosas);
            cosas += terminoIndependiente; //Ves si se encuentra en la inclinacion del hiperplano
        
            if (cosas < 0){
                resultado[i] = false;
            }
            else resultado[i] = true;        
        }    
        return resultado; 
    }
    
    public void obtenerErrorClasificador(ArrayList<Imagen> datos, Boolean[] resultadosCorrectos, ArrayList<Double> D){
        Boolean[] resultados = aplicarClasificadorDebil (datos);
        
        for(int i = 0; i < resultados.length; i++){
            if( !resultados[i].equals(resultadosCorrectos[i])){
                error += D.get(i);
            }
        }
        Confio = 0.5 * (Math.log10((1 - error) / error)/ Math.log10(2)); 
    }
    public double getConfio(){
        return Confio;
    }
    public double getError(){
        return error;
    }
}

class ClasificadorFuerte{
    
    ArrayList<ClasificadorDebil> clasificadores;
    
    
    public static final int TOTAL_CD = 50;
    public static final int PRUEBAS = 50;
    public static final int DIMENSIONES = 784; 
    
    public ArrayList<ClasificadorDebil> getClasificadores(){
        return clasificadores;
    }
    
    public ClasificadorFuerte(){
        clasificadores = new ArrayList<>();
    }
    
    public ClasificadorFuerte(ArrayList<ClasificadorDebil> debiles){
        this.clasificadores = new ArrayList<>();
        for(int i = 0; i < debiles.size(); i++){
            clasificadores.add(debiles.get(i));
        }
    }
    
    public ClasificadorFuerte(ArrayList<Imagen> datos, Boolean [] resultadosCorrectos){

        ArrayList<Double> D = new ArrayList<>();
        double Confianza;
        clasificadores = new ArrayList<>();
        
        for(int d = 0; d < datos.size(); d++){
            D.add(1.0/datos.size());
        } 
        for(int i = 0; i < TOTAL_CD; i++){
            
            int primera = 0;
            ClasificadorDebil auxdeb = new ClasificadorDebil();
            double auxerror = 0.0;
            //Entrenar hiperp teniendo en cuenta D
           
            for(int h = 0; h < PRUEBAS; h++){
                ClasificadorDebil cd = new ClasificadorDebil();
                
                cd.generarClasificadorAzar();
                cd.obtenerErrorClasificador(datos, resultadosCorrectos, D);
                         
                //Minimo de todas las pruebas
                if(primera == 0){
                    auxdeb = cd;
                    auxerror = cd.getError();
                    primera = 1;
                }
                else{
                    if(auxerror > cd.getError()){
                        auxerror = cd.getError();
                        auxdeb = cd;
                    }
                }
            }
            clasificadores.add(auxdeb);
            Confianza = auxdeb.getConfio();
            
            double Z = 0;
            
            for(int c = 0; c < datos.size(); c++){
               double A;
               Boolean [] h = auxdeb.aplicarClasificadorDebil(datos); 
               if (!h[c].equals(resultadosCorrectos[c])){
                       A = Math.pow(Math.E, Confianza);
               }
               else{
                       A = Math.pow(Math.E, -Confianza);
               }
               D.set(c,  D.get(c)* A);
            }
            
            for(int j = 0; j < datos.size(); j++){
               Z += D.get(j);
            }
            
            for(int c = 0; c < datos.size(); c++){
                D.set(c,  D.get(c)/Z);
            } 
        }        
    }
}


public class AdaBoost {
    ArrayList<ClasificadorFuerte> cf = new ArrayList<>(); //Los arrays entrenados
    ArrayList<ClasificadorDebil> dd = new ArrayList<>(); //Los arrays debiles auxiliar
    ArrayList<ClasificadorFuerte> rr = new ArrayList<>(); //Los arrays que coges entrenados
    ArrayList<Imagen> datos;
    Boolean[] rc;
    
    public AdaBoost(){
        
    }
    
    public AdaBoost(ArrayList<Imagen> datos){
        cf = new ArrayList<>();
    }
    
    public void entrenamiento(){
        DBLoader ml = new DBLoader();
        ml.loadDBFromPath("./db");
        
        
        ArrayList abrigo = ml.getImageDatabaseForDigit(0);
        ArrayList bolso = ml.getImageDatabaseForDigit(1);
        ArrayList camiseta = ml.getImageDatabaseForDigit(2);
        ArrayList pantalon = ml.getImageDatabaseForDigit(3);
        ArrayList sueter = ml.getImageDatabaseForDigit(4);
        ArrayList vestido = ml.getImageDatabaseForDigit(5);
        ArrayList zapatilla = ml.getImageDatabaseForDigit(6);
        ArrayList zapato = ml.getImageDatabaseForDigit(7);
        
        for(int este = 0; este < 8; este++){
            datos = new ArrayList<>();
            rc = new Boolean[500];
            ArrayList elegido = ml.getImageDatabaseForDigit(este);

            for(int i = 0; i < 500; i++){
                int numero = (int) (Math.random() * 2);
                if(numero == 0){
                    int elegir = (int) (Math.random() * elegido.size());
                    Imagen img = (Imagen) elegido.get(elegir);
                    datos.add(img);
                    rc[i] = true;
                }
                else{
                    int otro = este;
                    while(otro == este){

                        otro = (int) (Math.random() * 8);
                        
                    }
                    Imagen img;
                    int elegir;
                    switch (otro){
                        case 0:
                            //System.out.println ("Paso por 0");
                            elegir = (int) (Math.random() * abrigo.size());
                            img = (Imagen) abrigo.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        case 1:
                            //System.out.println ("Paso por 1");
                            elegir = (int) (Math.random() * bolso.size());
                            img = (Imagen) bolso.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        case 2:
                            //System.out.println ("Paso por 2");
                            elegir = (int) (Math.random() * camiseta.size());
                            img = (Imagen) camiseta.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        case 3:
                            //System.out.println ("Paso por 3");
                            elegir = (int) (Math.random() * pantalon.size());
                            img = (Imagen) pantalon.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        case 4:
                            //System.out.println ("Paso por 4");
                            elegir = (int) (Math.random() * sueter.size());
                            img = (Imagen) sueter.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        case 5:
                            //System.out.println ("Paso por 5");
                            elegir = (int) (Math.random() * vestido.size());
                            img = (Imagen) vestido.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        case 6:
                            //System.out.println ("Paso por 6");
                            elegir = (int) (Math.random() * zapatilla.size());
                            img = (Imagen) zapatilla.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                        default:
                            //System.out.println ("Paso por defa");
                            elegir = (int) (Math.random() * zapato.size());
                            img = (Imagen) zapato.get(elegir);
                            datos.add(img);
                            rc[i] = false;
                            break;
                    }
                }
            }
            ClasificadorFuerte ff = new ClasificadorFuerte(datos, rc);
            cf.add(ff);
        }
        
    }
    
    public void crearFichero(String fichero){
        //Genero el fichero
        File archivo = new File(fichero);
        BufferedWriter bw;
        
        entrenamiento();
        
        try{
            bw = new BufferedWriter(new FileWriter(archivo));
            //Busco los hiperplanos y el confio.
            for(int j = 0; j < cf.size(); j++){
                ClasificadorFuerte f;
                ClasificadorDebil d;
                f = cf.get(j);
                ArrayList<ClasificadorDebil> c = f.getClasificadores();
                for(int x = 0; x < c.size(); x++){
                    d = c.get(x);
                    ArrayList<Double> hiper = d.getHiperplano();
                    for(int h = 0; h < hiper.size(); h++){
                        if(h == hiper.size()-1){
                            bw.write(hiper.get(h) + " ");
                        }
                        else{
                            bw.write(hiper.get(h) + ",");
                        } //El hiperplano
                    }
                    bw.write(d.getConfio() + " " + d.getTermino() + "\n"); //confianza
                }
                bw.write(" " + "\n");
            }
            bw.close();
        }catch(IOException e){
            System.out.println ("El error es: " + e.getMessage());
        }
    }
    
    public void abrirFichero(String archivo){
        String cadena;
        try{
            FileReader f = new FileReader(archivo);
            rr = new ArrayList<>();
            BufferedReader bw = new BufferedReader(f);
            while((cadena = bw.readLine())!= null) {

                if(!cadena.equals(" ")){
                    String[] partes1 = cadena.split(",");
                    ArrayList<Double> hiperp = new ArrayList<>();
                    double conf = 0;
                    double termino = 0;
                    for(int x = 0; x < partes1.length; x++){
                        if(x == partes1.length-1){
                            String [] parte2 = partes1[x].split(" ");

                            hiperp.add(Double.parseDouble(parte2[0]));
                            conf = Double.parseDouble(parte2[1]);
                            termino = Double.parseDouble(parte2[2]);
                        }else{
                            hiperp.add(Double.parseDouble(partes1[x]));
                        }
                    }
                    ClasificadorDebil d = new ClasificadorDebil(hiperp, termino, conf);
                    dd.add(d);
                }else{
                    ClasificadorFuerte fuerte = new ClasificadorFuerte(dd);
                    rr.add(fuerte);
                }
            }
            bw.close();
        }catch(Exception e){
            System.out.println ("El error es: " + e.getMessage());
        }
    }
    
    public String Conclusion(Imagen imagen){
        ArrayList<Imagen> im = new ArrayList<>();
        im.add(imagen);
        String conclusion = "";
        Boolean [] resultado; // = new Boolean [im.size()];
        int posicion = 0;
        double mayor = 0.0;
        int primera = 0;
        for(int i = 0; i < rr.size() ; i++){
            double dato;
            double sumatorio = 0.0;
            
            ClasificadorFuerte f = rr.get(i);
            for(int j = 0; j < f.getClasificadores().size(); j++){
                ArrayList<ClasificadorDebil> d = f.getClasificadores();
                for(int x = 0; x < d.size(); x++){
                    resultado = d.get(x).aplicarClasificadorDebil(im);
                    if(resultado[0]){
                        dato = 1;
                    }
                    else{
                        dato = -1;
                    }
                    sumatorio += d.get(x).getConfio() * dato; //Sumatorio (alfa * h)
                }
            }
            if(primera == 0){
                mayor = sumatorio;
                posicion = i;
                primera = 1;
            }
            else{
                if(mayor < sumatorio){
                    mayor = sumatorio;
                    posicion = i;

                }
            }
        }
        switch (posicion) {
            case 0:  conclusion = "Abrigo";
                     break;
            case 1:  conclusion = "Bolso";
                     break;
            case 2:  conclusion = "Camiseta";
                     break;
            case 3:  conclusion = "Pantalon";
                     break;
            case 4:  conclusion = "Suéter";
                     break;
            case 5:  conclusion = "Vestido";
                     break;
            case 6:  conclusion = "Zapatilla";
                     break;
            case 7: conclusion = "Zapato";
                     break;
        }
        
        return conclusion;
    }
}
