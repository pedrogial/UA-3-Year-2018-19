/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.util.ArrayList;

/**
 *
 * @author fidel
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        //System.out.println ("Paso por -train");
        /*
        //Cargador de la BD de SI
        DBLoader ml = new DBLoader();
        ml.loadDBFromPath("./db");
        
        //Accedo a las imagenes de bolsos
        ArrayList d0imgs = ml.getImageDatabaseForDigit(1);
        
        //Y cojo el decimo bolso de la bd
        Imagen img = (Imagen) d0imgs.get(9);
        
        //La invierto para ilustrar como acceder a los pixels y imprimo los pixeles
        //en hexadecimal
        System.out.print("Image pixels: ");
        byte imageData[] = img.getImageData();
        for (int i = 0; i < imageData.length; i++)
        {
            imageData[i] = (byte) (255 - imageData[i]);
            System.out.format("%02X ", imageData[i]);
        }
        
        //Muestro la imagen invertida
        MostrarImagen imgShow = new MostrarImagen();
        imgShow.setImage(img);
        imgShow.mostrar();
        */
        AdaBoost ada = new AdaBoost();
        if("-train".equals(args[0])){
            System.out.println ("Paso por -train");

            ada.crearFichero(args[1]);
        }
        else{
            if("-run".equals(args[0])){
                Imagen im = new Imagen();
                im.loadFromPath(args[2]);
                
                System.out.println ("Paso por -run");

                ada.abrirFichero(args[1]);
                System.out.println (ada.Conclusion(im));
            }
            else{
                int sumador = 0;
                int error = 0;
                DBLoader ml = new DBLoader();
                ml.loadDBFromPath("./db");
                ada.abrirFichero(args[0]);
                for(int i = 0; i < 8; i++){
                    ArrayList im = ml.getImageDatabaseForDigit(i);
                    for(int x = 0; x < im.size(); x++){
                        Imagen img = (Imagen) im.get(x);
                        String esto = ada.Conclusion(img);
                        
                        if(!esto.equals("Abrigo") && i == 0){
                            sumador += 1;
                        }else if(!esto.equals("Bolso") && i == 1){
                            sumador += 1;
                        }else if(!esto.equals("Camiseta") && i == 2){
                            sumador += 1;
                        }else if(!esto.equals("Pantalon") && i == 3){
                            sumador += 1;
                        }else if(!esto.equals("Suéter") && i == 4){
                            sumador += 1;
                        }else if(!esto.equals("Vestido") && i == 5){
                            sumador += 1;
                        }else if (!esto.equals("Zapatilla")&& i == 6){
                            sumador += 1;
                        }else if (!esto.equals("Zapato")&& i == 7){
                            sumador += 1;
                        }
                    }
                }
                System.out.println (sumador);
                //error = Math.abs(sumador - 4001)/4001;
                error = sumador/4001;
                error = error * 100;
                System.out.println (error + "%");
            }
        }
    }
}
