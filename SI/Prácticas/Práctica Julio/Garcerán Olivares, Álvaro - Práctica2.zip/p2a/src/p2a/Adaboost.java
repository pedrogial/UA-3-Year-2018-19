/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2a;

import java.util.ArrayList;
import java.io.Serializable;
import java.util.SplittableRandom;

/**
 *
 * @author Alvaro
 */
public class Adaboost implements Serializable{
    private final ArrayList listaClasificadores; // Clasificardores debiles ponderados según su confianza
    private transient SplittableRandom random;
    public double tasa = 0d;
    public double tasaE = 0d; 

    public ArrayList obtenerClasificadorAzar(ArrayList<Objeto> objetos, int tipo){
        double[]xi = new double[784];
        double C = 0;
 
        for (int i = 0; i < xi.length; i++) {
            xi[i] = random.nextDouble(-1, 1);
            C += xi[i] * random.nextInt(0, 255);
        }
       
        ArrayList clasificador = new ArrayList();
        clasificador.add(xi);
        clasificador.add(C);
        
        return clasificador;
    }
    
    public int resultadoClasificador(ArrayList clasificador, Objeto o){
        double resultado = 0d;
        double[] xi = (double[]) clasificador.get(0);
        double constante= (double) clasificador.get(1);
        byte[] puntos = o.getImageData();
        for (int i = 0; i < 784; i++){
            resultado += xi[i] * (puntos[i] & 0xff);
        }
        return (resultado - constante) > 0d ? 1 : -1;      
    }
    
    public ArrayList obtenerClasificadorDebil(int nClasificadores, ArrayList<Objeto> objetos, int tipo){
        double error = 0d;        
        double minError = 0d;
        
        ArrayList clasificador;
        ArrayList mejor = new ArrayList();
        
        for (int i = 0; i < nClasificadores; i++) {
            error = 0;
            clasificador = obtenerClasificadorAzar(objetos, tipo); 
            for (Objeto o : objetos){
                if (resultadoClasificador(clasificador, o) != o.esTipo(tipo)){
                    error+= o.getPeso();
                }
            }

            if (i == 0){
                mejor = clasificador;
                minError = error;
            } 
            else if (error < minError){
                mejor = clasificador;
                minError = error;
            } 
        }
        
        mejor.add(minError);
        mejor.add(0.5d * Math.log((1 - minError)/minError));
        
        return mejor;
    }
    
    public double recalcularPeso(Objeto obj, ArrayList clasificador, double at, int tipo){
  
        double peso = obj.getPeso() * Math.pow(Math.E, -at * obj.esTipo(tipo) * resultadoClasificador(clasificador, obj));
        return peso;
    }
    
    public int resultadoAdaboost(Objeto obj) {
        double acumulador = 0d;   
        
        for(int i=0; i < listaClasificadores.size(); i++){
            ArrayList cdebil = (ArrayList) listaClasificadores.get(i);
            double[] xi = (double[]) cdebil.get(0);
            double C = (double) cdebil.get(1);
            double at = (double) cdebil.get(3);
            
            double resultado = 0;
            for (int j = 0; j < 784; j++){
                resultado += xi[j] * (obj.getImageData()[j] & 0xff);
            }
            acumulador += at * (resultado - C);     
        }
        return acumulador > 0d ? 1 : -1;
    }
    
    public int obtenerAciertos(ArrayList<Objeto> objetos, int tipo) {
        int aciertos = 0;
        for (Objeto obj : objetos) {
            if (resultadoAdaboost(obj) == obj.esTipo(tipo)){
                aciertos++;
            }
        }
        return aciertos;
    }
    
    public Adaboost(ArrayList<Objeto> objetos, ArrayList<Objeto> testObjetos, int nCDebiles, int nHiperplanos, int tipo) {
        listaClasificadores = new ArrayList();
        random = new SplittableRandom();
        
        for (Objeto obj : objetos){
            obj.setPeso(1d/objetos.size());
        }
        
        for (int t = 0; t < nCDebiles; t++) {

            ArrayList cdebil = obtenerClasificadorDebil(nHiperplanos, objetos, tipo);
            double at = (double) cdebil.get(3);
            double Zt = 0d;
            listaClasificadores.add(cdebil);     
            
            for(int i=0; i < objetos.size(); i++){
                Objeto obj = objetos.get(i);
                double peso = recalcularPeso(obj, cdebil, at, tipo);
                obj.setPeso(peso);
                Zt += peso;
                
            }

            for (Objeto obj : objetos){
                obj.setPeso(obj.getPeso() / Zt);
            }
            
            System.out.println("\tCalculando clasificador fuerte " + tipo + ": Debil " + t);
            
            tasa = (double)obtenerAciertos(testObjetos, tipo)/testObjetos.size();
            tasaE = (double)obtenerAciertos(objetos, tipo)/objetos.size();
            
            if ((double) cdebil.get(2) == 0) break; 
        }  
        
        System.out.println("\t-------------------------------------------------------------");
    }  
}
