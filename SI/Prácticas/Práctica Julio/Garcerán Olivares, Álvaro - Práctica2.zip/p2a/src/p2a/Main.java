/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2a;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.SplittableRandom;

/**
 *
 * @author fidel
 */
public class Main {

    static DBLoader ml = new DBLoader();
    private SplittableRandom random = new SplittableRandom();
    
    public static void generarAyT(int clase, ArrayList entrenamiento, ArrayList test){

        ArrayList<Integer> otros = new ArrayList();
        
        for(int i=0; i<8; i++){
            if(i != clase) otros.add(i);
        }
        
        int tamTotal =  ml.imageDB[clase].size();
        int tamEntr = Math.round(tamTotal*0.8f);
        
        int otra, j;
        for(int i=0; i<tamEntr; i++){
            entrenamiento.add(new Objeto(clase,(Imagen)ml.imageDB[clase].get(i)));
            otra = otros.get(i%7);
            j = i/7;
            entrenamiento.add(new Objeto(otra,(Imagen)ml.imageDB[otra].get(j)));
        } 
        
        for(int i=tamEntr; i<tamTotal; i++){
            test.add(new Objeto(clase,(Imagen)ml.imageDB[clase].get(i)));
            otra = otros.get(i%7);
            j = i/7;
            test.add(new Objeto(otra,(Imagen)ml.imageDB[otra].get(j)));
        } 
        
        Collections.shuffle(entrenamiento);
        Collections.shuffle(test);
         
    }
    
    public static void mensajeAdaboost(int t){
        
        switch(t){
            case 0:
                System.out.println("La imagen introducida es un abrigo.");
                break;
            case 1:
                System.out.println("La imagen introducida es un bolso.");
                break;
            case 2:
                System.out.println("La imagen introducida es una camiseta.");
                break;
            case 3:
                System.out.println("La imagen introducida es un pantalon.");
                break;
            case 4:
                System.out.println("La imagen introducida es un sueter.");
                break; 
            case 5:
                System.out.println("La imagen introducida es un vestido.");
                break; 
            case 6:
                System.out.println("La imagen introducida es una zapatilla");
                break; 
            case 7:
                System.out.println("La imagen introducida es un zapato");
                break; 
            default:
                System.out.println("La imagen no se ha podido clasificar");
                break; 
                
        }
    }
    
    
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        if(args.length == 2 && args[0].equals("-train")){
            
            ml.loadDBFromPath("./db");

            int T = 50;
            int A = 500;
            String fichero = args[1];

            try {
                FileOutputStream fileOut = new FileOutputStream(fichero);
                ObjectOutputStream out = new ObjectOutputStream(fileOut);
            
                
                ArrayList<Objeto> entrenamiento0 = new ArrayList();
                ArrayList<Objeto> test0 = new ArrayList();
                generarAyT(0,entrenamiento0, test0);
                
                ArrayList<Objeto> entrenamiento1 = new ArrayList();
                ArrayList<Objeto> test1 = new ArrayList();
                generarAyT(1,entrenamiento1, test1);
                
                ArrayList<Objeto> entrenamiento2 = new ArrayList();
                ArrayList<Objeto> test2 = new ArrayList();
                generarAyT(2,entrenamiento2, test2);
                
                ArrayList<Objeto> entrenamiento3 = new ArrayList();
                ArrayList<Objeto> test3 = new ArrayList();
                generarAyT(3,entrenamiento3, test3);
                
                ArrayList<Objeto> entrenamiento4 = new ArrayList();
                ArrayList<Objeto> test4 = new ArrayList();
                generarAyT(4,entrenamiento4, test4);
                
                ArrayList<Objeto> entrenamiento5 = new ArrayList();
                ArrayList<Objeto> test5 = new ArrayList();
                generarAyT(5,entrenamiento5, test5);
                
                ArrayList<Objeto> entrenamiento6 = new ArrayList();
                ArrayList<Objeto> test6 = new ArrayList();
                generarAyT(6,entrenamiento6, test6);
                
                ArrayList<Objeto> entrenamiento7 = new ArrayList();
                ArrayList<Objeto> test7 = new ArrayList();
                generarAyT(7,entrenamiento7, test7);

                    Adaboost abrigos = new Adaboost(entrenamiento0, test0, T, A, 0);
                    Adaboost bolsos = new Adaboost(entrenamiento1, test1, T, A, 1);
                    Adaboost camisetas = new Adaboost(entrenamiento2, test2, T, A, 2);
                    Adaboost pantalones =new Adaboost(entrenamiento3, test3, T, A, 3);
                    Adaboost sueters = new Adaboost(entrenamiento4, test4, T, A, 4);
                    Adaboost vestidos = new Adaboost(entrenamiento5, test5, T, A, 5);
                    Adaboost zapatillas = new Adaboost(entrenamiento6, test6, T, A, 6);
                    Adaboost zapatos = new Adaboost(entrenamiento7, test7, T, A, 7);
                    
                System.out.println("Tasa de acierto individual de abrigos: (Test)" + (double)abrigos.tasa * 100 + " (Entrenamiento) "+ (double)abrigos.tasaE * 100);
                System.out.println("Tasa de acierto individual de bolsos: (Test)" + (double)bolsos.tasa * 100 + " (Entrenamiento) "+ (double)bolsos.tasaE * 100);
                System.out.println("Tasa de acierto individual de camisetas: (Test)" + (double)camisetas.tasa * 100 + " (Entrenamiento) "+ (double)camisetas.tasaE * 100);
                System.out.println("Tasa de acierto individual de pantalones: (Test)" + (double)pantalones.tasa * 100 + " (Entrenamiento) "+ (double)pantalones.tasaE * 100);
                System.out.println("Tasa de acierto individual de sueters: (Test)" + (double)sueters.tasa * 100 + " (Entrenamiento) "+ (double)sueters.tasaE * 100);
                System.out.println("Tasa de acierto individual de vestidos: (Test)" + (double)vestidos.tasa * 100 + " (Entrenamiento) "+ (double)vestidos.tasaE * 100);
                System.out.println("Tasa de acierto individual de zapatillas: (Test)" + (double)zapatillas.tasa * 100 + " (Entrenamiento) "+ (double)zapatillas.tasaE * 100);
                System.out.println("Tasa de acierto individual de zapatos: (Test)" + (double)zapatos.tasa * 100 + " (Entrenamiento) "+ (double)zapatos.tasaE * 100);
                    
                    out.writeObject(abrigos);
                    out.writeObject(bolsos);
                    out.writeObject(camisetas);
                    out.writeObject(pantalones);
                    out.writeObject(sueters);
                    out.writeObject(vestidos);
                    out.writeObject(zapatillas);
                    out.writeObject(zapatos);
                    
                
                System.out.println("Se ha guardado el clasificador en " + fichero);
                out.close();
                fileOut.close();
            } catch (IOException i) {
             i.printStackTrace();
            }
            
        }else if (args.length == 3 && args[0].equals("-run")){
            String fichero = args[1];
            ml.loadDBFromPath("./db");
             
            Adaboost abrigos = null;
            Adaboost bolsos = null;
            Adaboost camisetas = null;
            Adaboost pantalones = null;
            Adaboost sueteres = null;
            Adaboost vestidos = null;
            Adaboost zapatillas = null;
            Adaboost zapatos = null;
            
            
            try {

                File f = new File(fichero);
                
                if(f.exists()){
                    FileInputStream fileIn = new FileInputStream(fichero);
                    ObjectInputStream in = new ObjectInputStream(fileIn);
                    abrigos = (Adaboost) in.readObject();
                    bolsos = (Adaboost) in.readObject();
                    camisetas = (Adaboost) in.readObject();
                    pantalones = (Adaboost) in.readObject();
                    sueteres = (Adaboost) in.readObject();
                    vestidos = (Adaboost) in.readObject();
                    zapatillas = (Adaboost) in.readObject();
                    zapatos = (Adaboost) in.readObject();
                    in.close();
                    fileIn.close();

                } else {
                    System.out.println("No existe el fichero: "+fichero);
                }

                int[] res = new int[8];
                double[] tasa = new double[8];
                
                tasa[0] = abrigos.tasa;
                tasa[1] = bolsos.tasa;
                tasa[2] = camisetas.tasa;
                tasa[3] = pantalones.tasa;
                tasa[4] = sueteres.tasa;
                tasa[5] = vestidos.tasa;
                tasa[6] = zapatillas.tasa;
                tasa[7] = zapatos.tasa;
  
                
                Imagen img=new Imagen();
                img.loadFromPath(args[2]);
                Objeto obj = new Objeto(0, img);


                double max = 0d;
                int tipo = -1;
                    
                    
                res[0] = abrigos.resultadoAdaboost(obj);
                res[1] = bolsos.resultadoAdaboost(obj);
                res[2] = camisetas.resultadoAdaboost(obj);
                res[3] = pantalones.resultadoAdaboost(obj);
                res[4] = sueteres.resultadoAdaboost(obj);
                res[5] = vestidos.resultadoAdaboost(obj);
                res[6] = zapatillas.resultadoAdaboost(obj);
                res[7] = zapatos.resultadoAdaboost(obj);
                    
                    
                for(int j =0; j < 8; j++){
                        
                    if(res[j] == 1){
                        if(tasa[j] > max){
                            tipo = j;
                            max = tasa[j];
                        }
                    }
                }

                mensajeAdaboost(tipo);
            
                

            } catch (IOException i) {
               i.printStackTrace();
            } catch (ClassNotFoundException c) {
               System.out.println("Employee class not found");
               c.printStackTrace();
            }
            
        }else{
            System.out.print("Error de sintaxis: Los parametros ");
            for(int i=0; i< args.length; i++){
                System.out.print("'"+ args[i]+"' " );
            }
            System.out.print("no son admisibles.\n");
            System.out.println("Sintaxis admisible: ");
            System.out.println("\tTrain: -train fichero ");
            System.out.println("\tRun: -run fichero imagen_prueba");
           
        }
    } 
}
