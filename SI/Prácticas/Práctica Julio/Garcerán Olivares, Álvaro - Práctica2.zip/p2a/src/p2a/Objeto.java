/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p2a;

/**
 *
 * @author Alvaro
 */
public class Objeto {
    public int tipo;
    public Imagen img;
    private double peso;
    
    public Objeto(int t, Imagen i){
        this.tipo = t;
        this.img = i;
    }
    
    public int getTipo() {
        return tipo;
    }
    
    public int esTipo(int t) {
        return tipo == t ? 1 : -1;
    }

    public void setTipo(int tipo) {
        this.tipo = tipo;
    }

    public Imagen getImg() {
        return img;
    }
    
    public byte [] getImageData(){
        return img.getImageData();
    }

    public void setImg(Imagen img) {
        this.img = img;
    }

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }
}
