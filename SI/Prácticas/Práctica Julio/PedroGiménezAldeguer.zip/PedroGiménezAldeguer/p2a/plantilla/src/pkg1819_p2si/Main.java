/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.SplittableRandom;

/**
 *
 * @author fidel
 */
public class Main {

    private SplittableRandom random = new SplittableRandom();
    
    public static void entrenamiento(int T, int A, String fichero){
        DBLoader ml = new DBLoader();
        ml.loadDBFromPath("./db");
        ArrayList<Adaboost> ada = new ArrayList();
        ArrayList<Imagen> entrenamiento = new ArrayList();
        ArrayList<Imagen> test = new ArrayList();
        ArrayList<Integer> otros = new ArrayList();
        ArrayList<Imagen> elegido = new ArrayList();
        ArrayList<Imagen> resto = new ArrayList();
        double[] promedio = new double[8];
        double[] promedio2 = new double[8];

        for(int cat = 0; cat < 8; cat++){
            otros = new ArrayList();
            elegido = new ArrayList();
            resto = new ArrayList();
            entrenamiento = new ArrayList();
            test = new ArrayList();
            
            //Elegido tiene el tamanyo n
            elegido = ml.getImageDatabaseForDigit(cat);
            int tamEntr = Math.round(elegido.size()*0.8f);
            
            for(int i=0; i<8; i++){
                if(i != cat){
                    otros.add(i);
                }
            }
            for(int y = 0; y < 8; y++){
                resto = ml.getImageDatabaseForDigit(y);
            }
            int otra, j;
            //Hay que ir añadiendo 2n para un 80%
            for(int i = 0; i < tamEntr; i++){
                Imagen im1 =elegido.get(i);
                entrenamiento.add(im1);
                im1.setPertenece(cat);
                
                otra = otros.get(i%7);
                j = i/7;
                
                resto = ml.getImageDatabaseForDigit(otra);
                Imagen im2 = resto.get(j);
                entrenamiento.add(im2);
                im2.setPertenece(otra);
            }
            //Hay que ir añadiendo 2n para un 20%
            for(int i=tamEntr; i<elegido.size(); i++){

                Imagen im1 = elegido.get(i);
                test.add(im1);
                im1.setPertenece(cat);
                
                otra = otros.get(i%7);
                j = i/7;
                
                resto = ml.getImageDatabaseForDigit(otra);
                Imagen im2 = resto.get(j);
                test.add(im2);
                im2.setPertenece(otra);
            }
            
            //Para desordenarlo mucho más (no es necesario)
            Collections.shuffle(entrenamiento);
            Collections.shuffle(test);
            
            System.out.println("\tCantidad de imagenes para TEST: " + test.size());
            System.out.println("\tCantidad de imagenes para ENTRENAMIENTO: " +entrenamiento.size());
            Adaboost tipo = new Adaboost(entrenamiento, test, T, A, cat);
            System.out.println("\tTasa de acierto de la categoria " + Categoria(cat) + " del TEST: " + (double)tipo.tasaTest * 100 + "%");
            System.out.println("\tTasa de acierto de la categoria " + Categoria(cat) + " del ENTRENAMIENTO: " + (double)tipo.tasaEntrenamiento * 100 + "%");
            System.out.println("\t------------------------------------------------------------");

            promedio[cat] = (double)tipo.tasaTest * 100;
            promedio2[cat] = (double)tipo.tasaEntrenamiento * 100;
            ada.add(tipo);
        }
        double porcentaje = 0.0;
        for(int i = 0; i < 8; i++){
            porcentaje += promedio[i];
        }
        double porcentaje2 = 0.0;
        for(int i = 0; i < 8; i++){
            porcentaje2 += promedio2[i];
        }
        System.out.println("\tTasa de acierto promedio del TEST: " + (double)porcentaje/8 + "%");
        System.out.println("\tTasa de acierto promedio del ENTRENAMIENTO: " + (double)porcentaje2/8 + "%");

        crearFichero(ada, fichero);
    }
    
     public static void crearFichero(ArrayList<Adaboost> ada, String fichero){
        //Genero el fichero
        File archivo = new File(fichero);
        BufferedWriter bw;
        
        try{
            bw = new BufferedWriter(new FileWriter(archivo));
            //Busco los hiperplanos y el resto
            for(int j = 0; j < ada.size(); j++){
                Adaboost a = ada.get(j);
                ArrayList c = a.getLista();
                double tasa = a.tasaTest;
                ArrayList d = new ArrayList();
                for(int x = 0; x < c.size(); x++){
                    d = (ArrayList)c.get(x);
                    double[] hiper = (double[])d.get(0);
                    double confianza = (double)d.get(2);
                    double terminoIndependiente = (double)d.get(1);

                    for(int h = 0; h < hiper.length; h++){
                        if(h == hiper.length - 1){
                            bw.write(hiper[h] + " ");
                        }
                        else{
                            bw.write(hiper[h] + ",");
                        } //El hiperplano
                    }
                    bw.write(confianza+ " " + terminoIndependiente + " " + tasa + "\n"); //El resto
                }
                bw.write(" " + "\n");
            }
            bw.close();
        }catch(IOException e){
            System.out.println ("El error es: " + e.getMessage());
        }
    }
     
    public static ArrayList<Adaboost> abrirFichero(String archivo){
        String cadena;
        int debiles = 0;
        int fuertes = 0;
        double tas = 0;
        ArrayList<Adaboost> aa = new ArrayList<>();
        try{
            FileReader f = new FileReader(archivo);
            BufferedReader bw = new BufferedReader(f);
            
            Adaboost ada = new Adaboost();
            while((cadena = bw.readLine())!= null) {
                if(!cadena.equals(" ")){
                    String[] partes1 = cadena.split(",");
                    double[] hiperp = new double[784];
                    double conf = 0d;
                    double termino = 0d;
                    tas = 0d;
                    for(int x = 0; x < partes1.length; x++){
                        if(x == partes1.length-1){
                            String [] parte2 = partes1[x].split(" ");
                            hiperp[x] = Double.parseDouble(parte2[0]);
                            //System.out.println ("H: " + hiperp[x]);
                            conf = Double.parseDouble(parte2[1]);
                            termino = Double.parseDouble(parte2[2]);
                            tas = Double.parseDouble(parte2[3]);
                           
                            //System.out.println ("C: " + conf + ", T: " + termino);
                        }else{
                            hiperp[x] = Double.parseDouble(partes1[x]);
                            //System.out.println ("H2: " + hiperp[x]);
                        }
                    }
                    debiles++;
                    //System.out.println ("Deb: " + debiles);
                    ArrayList d = new ArrayList();
                    d.add(hiperp);
                    d.add(termino);
                    d.add(conf);
                    d.add(0.0);
                    ada.getLista().add(d);
                }else{
                    fuertes++;
                    //System.out.println ("fuert: " + fuertes);
                    ada.tasaTest = tas;
                    //System.out.println ("tas: " + tas);
                    aa.add(ada);
                    //System.out.println ("fuert: " + fuerte.clasificadores.size());
                    ada = new Adaboost();
                }
            }
            bw.close();
            //System.out.println ("Deb: " + debiles);
            //System.out.println ("fuert: " + fuertes);
            
        }catch(Exception e){
            System.out.println ("El error es2: " + e.getMessage());
        }
        return aa;
    }
    
    public static String Categoria(int t){
        String tipo = "";
        switch(t){
            case 0:
                tipo = "abrigo";
                break;
            case 1:
                tipo = "bolso";
                break;
            case 2:
                tipo = "camiseta";
                break;
            case 3:
                tipo = "pantalon";
                break;
            case 4:
                tipo = "sueter";
                break; 
            case 5:
                tipo = "vestido";
                break; 
            case 6:
                tipo = "zapatilla";
                break; 
            case 7:
                tipo = "zapato";
                break; 
            default:
                tipo = "";
                break; 
        }
        return tipo;
    }
    
    public static String Conclusion(Imagen im, ArrayList<Adaboost> ada){        
        double[] tasas = new double[8];
        double[] sumatorio = new double[8];
        double max = 0d;
        int tipo = -1;
        
        for(int i = 0; i < 8; i++){
            tasas[i] = ada.get(i).tasaTest;
        }
        for(int j = 0; j < 8; j++){
            sumatorio[j] = ada.get(j).aplicarAdaboost(im);
        }
        
        //Me quedo con el que mejor tasa promedio me ha dado los test de 20%
        for(int x =0; x < 8; x++){
            if(sumatorio[x] == 1){
                if(tasas[x] > max){
                    tipo = x;
                    max = tasas[x];
                }
            }
        }
        return Categoria(tipo);
    }
    
    public static void main(String[] args) {
        int T = 100;
        int A = 500;
        
        if(args[1].equals("-train") && args.length == 3){
            System.out.println ("Paso por -train");
            String fichero = args[2];
            entrenamiento(T,A,fichero);
        }else if(args[1].equals("-run") && args.length == 4){
        
            Imagen im = new Imagen();
            im.loadFromPath(args[3]);

            System.out.println ("Paso por -run");

            ArrayList<Adaboost> ada = abrirFichero(args[2]);
            System.out.println ("La imagen es un/una: " + Conclusion(im, ada));
            
        }else if(args.length == 2){
        
            int sumador = 0;
            int ab, bol, cam, pan, su, ves, zap, za;
            ab = bol = cam = pan = su = ves = zap = za = 0;
            int mal = 0;
            double error = 0;
            DBLoader ml = new DBLoader();
            ml.loadDBFromPath("./db");
            ArrayList<Adaboost> ada = abrirFichero(args[1]);
            for(int i = 0; i < 8; i++){
                ArrayList im = ml.getImageDatabaseForDigit(i);
                for(int x = 0; x < im.size(); x++){
                    Imagen img = (Imagen) im.get(x);
                    String esto = Conclusion(img, ada);

                    if(esto.equals("abrigo") && i == 0){
                        sumador++;
                        ab++;
                    }else if(esto.equals("bolso") && i == 1){
                        sumador++;
                        bol++;
                    }else if(esto.equals("camiseta") && i == 2){
                        sumador++;
                        cam++;
                    }else if(esto.equals("pantalon") && i == 3){
                        sumador++;
                        pan++;
                    }else if(esto.equals("sueter") && i == 4){
                        sumador ++;
                        su++;
                    }else if(esto.equals("vestido") && i == 5){
                        sumador ++;
                        ves++;
                    }else if (esto.equals("zapatilla")&& i == 6){
                        sumador ++;
                        za++;
                    }else if (esto.equals("zapato")&& i == 7){
                        sumador ++;
                        zap++;
                    }
                    else{
                        mal ++;
                    }
                }
            }
            System.out.println ("0: " + ab);
            System.out.println ("1: " + bol);
            System.out.println ("2: " + cam);
            System.out.println ("3: " + pan);
            System.out.println ("4: " + su);
            System.out.println ("5: " + ves);
            System.out.println ("6: " + za);
            System.out.println ("7: " + zap);

            error = (double) sumador * 100 / (double)4001;
            System.out.println (error + "%");

        }
    }   
}
