/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.util.ArrayList;
import java.util.SplittableRandom;

/**
 *
 * @author pedro
 */

class ClasificadorDebil{
    public static final int DIMENSIONES = 784;
    public static final int MAX_VALUE = 255;
    private transient SplittableRandom random = new SplittableRandom();
    
    public ArrayList generarClasificadorAzar(ArrayList<Imagen> objetos, int tipo){
        double[]hiperplanos = new double[DIMENSIONES];
        double terminoIndependiente = 0.0;
 
        for (int i = 0; i < hiperplanos.length; i++) {
            hiperplanos[i] = random.nextDouble(-1, 1);
            terminoIndependiente += hiperplanos[i] * random.nextInt(0, MAX_VALUE);
        }
       
        ArrayList clasificador = new ArrayList();
        clasificador.add(hiperplanos); //0
        clasificador.add(terminoIndependiente); //1
        
        return clasificador;
    }
    
    public double aplicarClasificador(ArrayList debil, Imagen im){
        double resultado = 0.0;
        double[] hiper = (double[]) debil.get(0);
        double termino = (double) debil.get(1);
        byte[] pixel = im.getImageData();
        
        for (int i = 0; i < 784; i++){
            resultado += hiper[i] * (pixel[i] & 0xff);
        }
        resultado = resultado - termino;
                
        if (resultado > 0){
            resultado = 1;
        }
        else{
            resultado = -1;
        }
        return resultado;
    }
}

public class Adaboost{
    private final ArrayList clasificadoresDebiles;
    public double tasaTest = 0.0;
    public double tasaEntrenamiento = 0.0; 
    
    public ArrayList getLista(){
        return clasificadoresDebiles;
    }
    
    public Adaboost(){
        clasificadoresDebiles = new ArrayList();
    }

    public ArrayList generarDebil(ArrayList<Imagen> imagenes, int pruebas, int categoria, double[] D){
        double error, mejorErr, tipo;        
        error = mejorErr = tipo = 0.0;
        ArrayList clasificador;
        ArrayList mejor = new ArrayList();
        ClasificadorDebil debil = new ClasificadorDebil();
        
        for (int i = 0; i < pruebas; i++) {
            error = 0.0;
            clasificador = debil.generarClasificadorAzar(imagenes, categoria); 
            for (int j = 0; j < imagenes.size(); j++){
                tipo = 0.0;
                if(categoria == imagenes.get(j).getPertenece()){
                    tipo = 1;
                }else tipo = -1;
                if (debil.aplicarClasificador(clasificador, imagenes.get(j)) != tipo){
                    error+= D[j];
                }
            }
            if (i == 0){
                mejor = clasificador;
                mejorErr = error;
            } 
            else if (error < mejorErr){
                mejor = clasificador;
                mejorErr = error;
            } 
        }
        mejor.add(0.5d * Math.log((1 - mejorErr)/mejorErr)); //2
        mejor.add(mejorErr); //3
        return mejor;
    }
    
    public double actualizarPesos(Imagen im, ArrayList clasificador, double confianza, int categoria, double D){
        int cat = 0;
        ClasificadorDebil debil = new ClasificadorDebil();
        if(categoria == im.getPertenece()){
            cat = 1;
        }else cat = -1;
        
        return D * Math.pow(Math.E, -confianza * cat * debil.aplicarClasificador(clasificador, im));
    }
   
    public int aplicarAdaboost(Imagen obj) {
        double sumatorio = 0.0;   
        int r = 0;
        double[] hiper;
        double termino, confianza, aplicar;
        
        for(int i=0; i < clasificadoresDebiles.size(); i++){
            ArrayList cdebil = (ArrayList) clasificadoresDebiles.get(i);
            hiper = (double[]) cdebil.get(0);
            termino = (double) cdebil.get(1);
            confianza = (double) cdebil.get(2);            
            aplicar = 0;
            for (int j = 0; j < 784; j++){
                aplicar += hiper[j] * (obj.getImageData()[j] & 0xff);
            }
            sumatorio += confianza * (aplicar - termino);     
        }
        if(sumatorio > 0){
            r = 1;
        }else{
            r = -1;
        }
        return r; 
    }
     
    public int calcularTasas(int categoria, ArrayList<Imagen> imagenes) {
        int bien = 0;
        for (Imagen im : imagenes) {
            int cat = 0;
            if(categoria == im.getPertenece()){
                cat = 1;
            }else cat = -1;
            if (aplicarAdaboost(im) == cat){
                bien++;
            }
        }
        return bien;
    }

    public Adaboost(ArrayList<Imagen> imagenes, ArrayList<Imagen> testImagenes, int clasificadores, int pruebas, int categoria) {
        clasificadoresDebiles = new ArrayList();
        double[] D = new double[imagenes.size()];

        for (int i = 0; i < imagenes.size(); i++){
            D[i] = 1.0/imagenes.size();
        }
        
        for (int t = 0; t < clasificadores; t++) {
            ArrayList d = generarDebil(imagenes, pruebas, categoria, D);
            double confianza = (double) d.get(2);
            double Z = 0.0;
            clasificadoresDebiles.add(d);     
            
            for(int i=0; i < imagenes.size(); i++){
                Imagen obj = imagenes.get(i);
                D[i] = actualizarPesos(obj, d, confianza, categoria, D[i]);
                Z += D[i];
            }

            for(int c = 0; c < imagenes.size(); c++){
                D[c] = D[c]/Z;
            }
            
            //System.out.println("\tClasificador Fuerte " + categoria + " y Debil " + t);
            tasaTest = (double)calcularTasas(categoria, testImagenes)/ testImagenes.size();
            tasaEntrenamiento = (double)calcularTasas(categoria, imagenes)/ imagenes.size();
            
            if ((double) d.get(3) == 0){
                break;
            } 
        }
        System.out.println("\t------------------------------------------------------------");
    } 
}
