package pkg1819_p2si;

import java.util.Random;

public class Hiperplano implements java.io.Serializable{
    private static final int TAM = 784;
    private double[] vector = new double[TAM];
    private int [] punto = new int [TAM];
    public double[] plano = new double[TAM+1];
    private double error;
    double getError() { return error; }
    void setError(double error) { this.error = error; }
    //Generacion del hiperplano con vector 
    Hiperplano(){
        Random rand = new Random ();
        //termino libre D se calcula como el sumatorio de vector[i]*punto[i]
        double D=0d;
        for(int i=0; i<TAM ; i++){
            vector[i] = rand.nextDouble()*2-1;
            punto[i] = rand.nextInt(256)-128;
            plano[i] = punto[i];
            D = vector[i]*punto[i];
        }
        plano[TAM]= D;
    }
    //Una vez tengo generado mi hiperplano con mi vector y mi termino libre, puedo sustituir el punto( mi imagen)
    // y ver que me da si es un valor negativo o positivo.
    double evaluarImagen (byte[] pixel){
        double aux=0;
        for (int i = 0; i< TAM ; i++){
            aux+=pixel[i]*plano[i];
        }
        aux=aux-plano[TAM];
        return aux;
    }
}
