/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.util.ArrayList;
import java.io.*;
/**
 *
 * @author Rafa
 */
public class Adaboost {
    ArrayList<ImagenesPrueba> listaImagenesPrueba = new ArrayList<ImagenesPrueba>();
    ArrayList<ImagenesTest> listaImagenesTest = new ArrayList<ImagenesTest>();
    ArrayList<clasificadorFuerte> listaCF = new ArrayList<clasificadorFuerte>();
    
    
    public void inicioAdaboost(String nombreFichero){
        //Generar conjuntos para test y para prueba para cada categoria
        for(int i = 0; i < 8; i++){
            ImagenesPrueba imgP = new ImagenesPrueba(i);
            listaImagenesPrueba.add(imgP);            
            ImagenesTest imgT = new ImagenesTest(i);          
            listaImagenesTest.add(imgT);
            System.out.println("Tamaño prueba " + i+ " "+imgP.imgPrueba.size() );
            System.out.println("Tamaño test" +i+ " "+ imgT.imgPrueba.size());
            
        }

        //Tengo que generar 8 clasificadores fuertes uno para cada categoria
        for(int i = 0; i < 8; i++){
            System.out.println();
            System.out.println("Categoria " + i );
            System.out.println();
            clasificadorFuerte CF = new clasificadorFuerte(listaImagenesPrueba.get(i),listaImagenesTest.get(i),400,50,i);
            
            listaCF.add(CF);
        }
        //Serialización del clasificador fuerte
            try {
                FileOutputStream fileOut =
                new FileOutputStream("./"+nombreFichero+".ser");
                ObjectOutputStream out = new ObjectOutputStream(fileOut);
                out.writeObject(listaCF);
                out.close();
                fileOut.close();
                System.out.printf("Los datos serializados se han almacenado en " + nombreFichero);
             } catch (IOException ex) {
                ex.printStackTrace();
             }
        //Calculo si eso la tasa de aciertos luego.
           
    }
    public static void main(String[] args) {
        
        String option = args[0];
        //System.out.println(args[2]);
        if(option.equals("-train")){
            String nombreFichero= args[1];
            Adaboost a = new Adaboost();
            a.inicioAdaboost(nombreFichero);
        }
        else if(option.equals("-run")){
            String nombreFichero= args[1];
            String imagenPrueba= args[2];

            ArrayList<clasificadorFuerte> listaCF = null;
            try {
               FileInputStream fileIn = new FileInputStream("./"+nombreFichero+".ser");
               ObjectInputStream in = new ObjectInputStream(fileIn);
               listaCF = (ArrayList<clasificadorFuerte>) in.readObject();
               in.close();
               fileIn.close();
            } catch (IOException i) {
               i.printStackTrace();
               return;
            } catch (ClassNotFoundException c) {
               System.out.println("La clase no ha sido encontrada");
               c.printStackTrace();
               return;
            }
            
            //Llegados este punto, tengo la dirección a una imagen y tengo que aplicarle los clasificadores fuertes y quedarme con el que menos error tenga
            //Aplicar clasificadores fuertes a una imagen
            int mejor=0;
            for(int i = 0; i < 8; i++){
                Imagen img = new Imagen();
                img.loadFromPath(imagenPrueba);
                
                if (listaCF.get(i).calcularResultadoCF(img)== +1){
                    if(listaCF.get(mejor).tasaAciertos < listaCF.get(i).tasaAciertos){
                        mejor=i;
                    }
                   // System.out.println(listaCF.get(i).tasaAciertos);
                }       
            }
            //System.out.println("mejor " + listaCF.get(mejor).tasaAciertos );
            switch(mejor){
                case 0:
                    System.out.println("Es un abrigo");
                    break;
                case 1:
                    System.out.println("Es un bolso");
                    break;
                case 2:
                    System.out.println("Es una camiseta");
                    break;
                case 3:
                    System.out.println("Es un pantalon");
                    break;
                case 4:
                    System.out.println("Es un sueter");
                    break;  
                case 5:
                    System.out.println("Es un vestido");
                    break;
                case 6:
                    System.out.println("Son unas zapatillas");
                    break;
                case 7:
                    System.out.println("Son unos zapatos");
                    break;
                    
            }
            
        } 
    }
}
