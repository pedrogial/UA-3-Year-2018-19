/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.util.ArrayList;

/**
 * El clasificador debil generara la cantidad de hiperplanos que nosotros decidamos y se quedará con el que 
 * tenga menos error
 */
public class clasificadorDebil implements java.io.Serializable{
    //Mejor hiperplano de los generados
    Hiperplano bestHp;
    //Nos indica como de bueno es el clasificador
    double nivelConfianza;
    
    Hiperplano getHp(){
        return bestHp;
    }
    
    double getConfianza(){
        return nivelConfianza;
    }
    
    //Constructor del clasificador Debil, a partir de los hiperplanos generados (nº elegido por nosotros A) 
    //después de generarlos se queda con el que nos proporcione menor error
    clasificadorDebil(int A, ImagenesPrueba  imagenes){
        ArrayList<Imagen> imgsPrueba = imagenes.getImagenesPrueba();
        ArrayList<Integer> Y = imagenes.getImagenesPruebaY();
        //Número de clasificadores debiles a generar, de todos ellos devuelvo el que menos error tenga.
        for(int i=0;i<A;i++){
            int cont=0;
            Hiperplano h = new Hiperplano();//Genero nuevo hiperplano aleatorio
            double errorClasificador=0d; 
            //Le paso todas las imagenes de prueba a mi plano
            for (Imagen img : imgsPrueba){
                if(calcularPosicion(h,img) != Y.get(cont)){
                    errorClasificador+=img.getPeso();
                }
                cont++;
            }
            h.setError(errorClasificador);
            
            if (i == 0){
                bestHp = h;
            } 
            else if(h.getError() < bestHp.getError()){
               bestHp = h;
            }
        }
        //Calculamos el nivel de confianza del mejor hiperplano elegido
        nivelConfianza = 0.5d * Math.log((1 - bestHp.getError())/bestHp.getError()); //Formulita Adaboost
    }
    //Compruebo la posición de una imagen en un hiperplano generado aleatoriamente, por lo que puede
    //que sea bueno o malo, para valorar eso miraremos los errores que ha cometido para el tipo que nos covenga.
    int calcularPosicion (Hiperplano h, Imagen i){
        //Si al evaluar una imagen el signo es positivo asumo que 
        if (h.evaluarImagen(i.getImageData())>0d){
            return +1;
        }else{
            return -1;
        }
    }
    int calcularPosicion(Imagen i){
        return calcularPosicion(bestHp,i);
    }
}
