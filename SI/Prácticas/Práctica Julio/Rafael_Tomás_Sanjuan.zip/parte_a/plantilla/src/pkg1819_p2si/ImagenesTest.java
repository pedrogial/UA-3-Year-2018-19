/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.util.ArrayList;

/**
 *
 * @author Rafa
 */
public class ImagenesTest {
    //ArrayList que indica si la imagen corresponde al conjunto o no 
    ArrayList<Integer> Y;
    //Listado de imagenes.
    ArrayList<Imagen> imgPrueba;
    
    //genero un ArrayList con un 50% de imagenes de la categoria a la cual quiero hacerle la prueba, y el otro 50% aproximadamente intento que sea del resto de categorias.
    ImagenesTest (int categoria){
        this.imgPrueba = new ArrayList<Imagen> ();
        this.Y = new ArrayList<Integer> ();
        DBLoader ml = new DBLoader();
        ml.loadDBFromPath("./db");
        
        ArrayList imgsCategoria = ml.getImageDatabaseForDigit(categoria);
        imgsCategoria.size();
        //Llevar cuidado al hacer las divisiones ya que los números posiblemente no sean enteros.(Espero que funcione igualmente)
        for(int i=imgsCategoria.size()/2;i<imgsCategoria.size();i++){
            imgPrueba.add((Imagen)imgsCategoria.get(i)); 
            Y.add(1);
        }
        for(int i=0;i<8;i++){
            if(i!=categoria){
                ArrayList imgsCategoriaAux = ml.getImageDatabaseForDigit(i);
                for(int j=(imgsCategoria.size()/2)/7;j<((imgsCategoria.size()/2)/7)*2;j++){
                    imgPrueba.add((Imagen)imgsCategoriaAux.get(j)); 
                    Y.add(-1);
                }
            }
        }
    }
    ArrayList<Imagen> getImagenesPrueba(){
        return imgPrueba;
    }
    ArrayList<Integer> getImagenesPruebaY(){
        return Y;
    }
}
