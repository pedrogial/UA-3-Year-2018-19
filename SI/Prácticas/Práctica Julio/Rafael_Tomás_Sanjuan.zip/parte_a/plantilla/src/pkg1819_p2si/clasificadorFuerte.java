/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package pkg1819_p2si;

import java.util.ArrayList;

/**
 *
 * Clasificador complejo, dado un T clasificadores simples se forma uno complejo 
 * Se da más peso a las imagenes que los clasificadores no clasifican bien con la intención de que 
 * cuando se genere un nuevo clasificador se esfuerce más en clasificar aquellas imagenes más dificiles
 * 
 */
public class clasificadorFuerte  implements java.io.Serializable{
    ArrayList<clasificadorDebil> listaCD = new ArrayList<clasificadorDebil>() ;//Lista de los clasificadores debiles que voy creando
    int categoria;
    double tasaAciertosPrueba=0d;
    double tasaAciertosTest=0d;
    double tasaAciertos;
     
    
    public clasificadorFuerte(ImagenesPrueba imgsPrueba,ImagenesTest imgsTest, int numHiperplanos, int numClasificadoresD,int categoria ){
        this.categoria=categoria;
        //Primero de todo asignamos a las imagenes de prueba el mismo peso.
        //D1(i) = 1/N donde N es el tamaño del conjunto de entrenamiento:
        for(Imagen i : imgsPrueba.getImagenesPrueba()){
            i.setPeso(1d/imgsPrueba.getImagenesPrueba().size());//REVISAR!
        }
        
        for(int i = 0; i < numClasificadoresD; i++) {
            //Generamos un clasificador debil
            clasificadorDebil CD = new clasificadorDebil(numHiperplanos,imgsPrueba);
            listaCD.add(CD);
            //Actualizamos los pesos de las imagenes
            double Zt = 0d; //Constante normalizadora
            int cont=0;
            for(Imagen img : imgsPrueba.getImagenesPrueba()){
                img.setPeso(img.getPeso()*Math.pow( Math.E, -CD.getConfianza() * imgsPrueba.Y.get(cont) * CD.calcularPosicion(img)));//Puta mierda no se si funciona
                Zt+=img.getPeso();//Suma de todos los pesos de las imagenes
                cont++;  
            }
            //Debemos normalizar los pesos de las imagenes
            for(Imagen img : imgsPrueba.getImagenesPrueba()){
                img.setPeso(img.getPeso()/Zt);
            }
            int[] result = contarFallos(imgsPrueba);
            int[] resultTest = contarFallosTest(imgsTest);
            System.out.println("Clasificador "+ i + "\t" + "aciertos " + result[0] + "\t" + "fallos " + result[1] + "\t" + "aciertosTest " + resultTest[0]+ "\t" + "fallosTest " + resultTest[1]  );
            double aux = (double)result[0]/(double)imgsPrueba.getImagenesPrueba().size();
            double aux1 = (double)resultTest[0]/(double)imgsPrueba.getImagenesPrueba().size();
            tasaAciertosPrueba+=aux;
            tasaAciertosTest+=aux1;
            if (CD.bestHp.getError() == 0) break;//Si mi clasificador no tiene ningún fallo corto la ejecución
            
        }
        tasaAciertosPrueba=(tasaAciertosPrueba*100)/(double)listaCD.size();
        tasaAciertosTest=(tasaAciertosTest*100)/(double)listaCD.size();
        tasaAciertos=(tasaAciertosPrueba+tasaAciertosTest)/2;
        System.out.println("La tasa de aciertos del entrenamiento es: "+tasaAciertosPrueba);
        System.out.println("La tasa de aciertos del test es: "+tasaAciertosTest);
    }
    //Dada una imagen calcula el resultado aplicando los N clasificadores debiles
    public int calcularResultadoCF(Imagen i){
        double aux = 0d;
        for(clasificadorDebil cd : listaCD){
            aux+=cd.getConfianza()*cd.bestHp.evaluarImagen(i.getImageData());
        }
        if(aux> 0d){
            return +1;
        }else{
            return -1;
        }
    }
    int[] contarFallos(ImagenesPrueba imgs){
        int aciertos = 0 ,fallos= 0;
        int cont=0;
        for(Imagen img : imgs.getImagenesPrueba()){
            if(calcularResultadoCF(img) == imgs.getImagenesPruebaY().get(cont) ){
                aciertos++;
            }
            else{
                fallos++;
            }
            cont++;
        }
        return new int[] {aciertos,fallos};
    }
    int[] contarFallosTest (ImagenesTest imgs){
        int aciertos = 0 ,fallos= 0;
        int cont=0;
        for(Imagen img : imgs.getImagenesPrueba()){
            if(calcularResultadoCF(img) == imgs.getImagenesPruebaY().get(cont) ){
                aciertos++;
            }
            else{
                fallos++;
            }
            cont++;
        }
        return new int[] {aciertos,fallos};
    }
}


