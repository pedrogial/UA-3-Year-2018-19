# SDS_GenPass
Password generator to SDS
<p>&nbsp;</p>
<p><strong>Distribuci&oacute;n de trabajo:</strong></p>
<ul style="list-style-type: disc;">
<li><strong>Pedro:</strong>
<ul style="list-style-type: circle;">
<li>Realizar el servidor.</li>
</ul>
</li>
</ul>
<p>&nbsp;</p>
<ul style="list-style-type: disc;">
<li><strong>Melanie:</strong>
<ul style="list-style-type: circle;">
<li>Realizar el cliente.</li>
</ul>
</li>
</ul>
