package main

import (
	"io/ioutil"
	"net/http"
	"os"
)

func add(w http.ResponseWriter, req *http.Request) {
	os.Remove(req.Form.Get("name") + ".json")
	if req != nil {
		_, err := os.Create(req.Form.Get("name") + ".json")
		chk(err)
		jsonF := decode64(req.Form.Get("json"))
		err = ioutil.WriteFile(req.Form.Get("name")+".json", jsonF, 0644)
		chk(err)
		response(w, true, "Añadido a la base de datos")
	}
}
