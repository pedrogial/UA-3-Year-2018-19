package main

import (
	"io/ioutil"
	"net/http"
	"os"
)

func fix(w http.ResponseWriter, req *http.Request) {
	file, err := os.Open(req.Form.Get("name") + ".json") // abrimos el primer fichero (entrada)
	defer file.Close()
	if err != nil {
		_, err := os.Create(req.Form.Get("name") + ".json")
		chk(err)
		responsefix(w, "", false, "El fichero no existe")
		return
	}
	aux, _ := ioutil.ReadAll(file)
	responsefix(w, encode64(aux), true, "Envio de fichero")
}
