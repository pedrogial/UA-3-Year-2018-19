package main

import (
	"bufio"
	"bytes"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"crypto/sha512"
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"os"
	"strings"
)

func chk(e error) {
	if e != nil {
		panic(e)
	}
}

func leerTerminal() string {
	text := bufio.NewReader(os.Stdin)
	read, _ := text.ReadString('\n')
	tipo := strings.TrimRight(read, "\r\n")
	return tipo
}

// función para cifrar (con AES en este caso), adjunta el IV al principio
func encrypt(data, key []byte) (out []byte) {
	out = make([]byte, len(data)+16)    // reservamos espacio para el IV al principio
	rand.Read(out[:16])                 // generamos el IV
	blk, err := aes.NewCipher(key)      // cifrador en bloque (AES), usa key
	chk(err)                            // comprobamos el error
	ctr := cipher.NewCTR(blk, out[:16]) // cifrador en flujo: modo CTR, usa IV
	ctr.XORKeyStream(out[16:], data)    // ciframos los datos
	return
}

// función para descifrar (con AES en este caso)
func decrypt(data, key []byte) (out []byte) {
	out = make([]byte, len(data)-16)     // la salida no va a tener el IV
	blk, err := aes.NewCipher(key)       // cifrador en bloque (AES), usa key
	chk(err)                             // comprobamos el error
	ctr := cipher.NewCTR(blk, data[:16]) // cifrador en flujo: modo CTR, usa IV
	ctr.XORKeyStream(out, data[16:])     // desciframos (doble cifrado) los datos
	return
}

// función para decodificar de string a []bytes (Base64)
func decode64(s string) []byte {
	b, err := base64.StdEncoding.DecodeString(s)
	chk(err)
	return b
}

// función para codificar de []bytes a string (Base64)
func encode64(data []byte) string {
	return base64.StdEncoding.EncodeToString(data)
}

type user struct {
	Name string            // nombre de usuario
	Hash []byte            // hash de la contraseña
	Salt []byte            // sal para la contraseña
	Data map[string]string // datos adicionales del usuario
}

type registry struct {
	Key   []byte
	Users map[string]user
}

// (se podría codificar en JSON y escribir/leer de disco para persistencia)
var gUsers map[string]user
var codee []byte

type resp struct {
	Ok  bool   // true -> correcto, false -> error
	Msg string // mensaje adicional
}

type respf struct {
	Ok   bool // true -> correcto, false -> error
	File string
	Msg  string // mensaje adicional
}

// función para escribir una respuesta del servidor
func response(w io.Writer, ok bool, msg string) {
	r := resp{Ok: ok, Msg: msg}
	rJSON, err := json.Marshal(&r)
	chk(err)
	w.Write(rJSON)
}

func responsefix(w io.Writer, file string, ok bool, msg string) {
	r := respf{Ok: ok, File: file, Msg: msg}
	rJSON, err := json.Marshal(&r)
	chk(err)
	w.Write(rJSON)
}

func handler(w http.ResponseWriter, req *http.Request) {
	req.ParseForm()
	//fmt.Println("Handler")
	w.Header().Set("Content-Type", "text/plain")
	//fmt.Println("set")
	switch req.Form.Get("cmd") {

	case "register": // ** registro
		fmt.Println("Register")
		register(w, req)
	case "login": // ** login
		fmt.Println("Login")
		login(w, req)
	case "fix": // ** fix
		fmt.Println("Coger datos")
		fix(w, req)
	case "add": // ** add
		fmt.Println("Enviar datos")
		add(w, req)
	default:
		response(w, false, "Comando inválido")
	}
}

func abrirArchivo() {
	file, err := os.Open("registro.json") // abrimos el primer fichero (entrada)
	gUsers = make(map[string]user)

	if err != nil {
		file, err = os.Create("registro.json") // abrimos el segundo fichero (salida)
		// inicializamos mapa de usuarios
		if err != nil {
			panic(err)
		}
	} else {
		defer file.Close()
		byteValue, _ := ioutil.ReadAll(file)
		var code []byte = nil
		Regi := registry{Key: code, Users: gUsers}
		json.Unmarshal(decrypt(byteValue, codee), &Regi)
		verdad := bytes.Equal(Regi.Key, codee)
		if verdad == false {
			fmt.Println("La contraseña no es la correcta")
			panic(err)
		} else {
			Regi.Key = codee
			fmt.Println("La contraseña es correcta, puedes continuar")
		}
	}
}

func almacenarArchivo() {
	var code []byte = nil
	Regi := registry{Key: code, Users: gUsers}
	Regi.Key = codee
	Regi.Users = gUsers
	os.Remove("registro.json")
	_, err := os.Create("registro.json")
	chk(err)
	jsonF, err := json.Marshal(&Regi)
	jsonFD := encrypt(jsonF, codee)
	err = ioutil.WriteFile("registro.json", jsonFD, 0644)
	chk(err)
}

func main() {
	fmt.Println("Dime la contraseña del servidor")
	key := leerTerminal()
	data := sha512.Sum512([]byte(key))
	codee = data[:32]
	abrirArchivo()
	fmt.Println("abro archivo")
	http.HandleFunc("/", handler)

	chk(http.ListenAndServeTLS(":10443", "cert.pem", "key.pem", nil))
}
