package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/url"
)

func save(cmd string, resp Resp) {
	fmt.Println("¿Qué dato quieres guardar?")
	fmt.Println("---------------------")
	fmt.Println("(Escribe 'nota', 'tarjeta' o 'contraseña', dependiendo del tipo de dato que quieras guardar o, si lo que deseas es salir de esta opción, escibe 'salir'.)")
	fmt.Print("Opción: ")

	tipo := leerTerminal()
	d := gData["data"]
	switch tipo {
	case "nota":
		if d.Nota == nil {
			gNota = make(map[string]nota)
		} else {
			gNota = d.Nota
		}
		n := nota{}
		fmt.Println("---------------------")
		fmt.Print("Introduce el título: ")
		n.Titulo = leerTerminal()
		fmt.Println("---------------------")
		fmt.Print("Introduce el cuerpo: ")
		n.Cuerpo = leerTerminal()

		_, ok := gNota[n.Titulo]
		if ok {
			fmt.Println("---------------------")
			fmt.Println("\n¡Este título de nota ya existe!\n")
			fmt.Println("Si deseas cancelar la operación, escribe 'NO', sino se editará dicha nota con el nuevo cuerpo introducido.")
			editnota := leerTerminal()
			if editnota == "No" || editnota == "no" || editnota == "NO" {
				Opciones(resp)
				return
			} else {
				gNota[n.Titulo] = n
				d.Nota = gNota
			}
		} else {
			gNota[n.Titulo] = n
			d.Nota = gNota
		}
	case "tarjeta":
		if d.Tarjeta == nil {
			gTarjeta = make(map[string]tarjeta)
		} else {
			gTarjeta = d.Tarjeta
		}
		t := tarjeta{}
		fmt.Println("---------------------")
		fmt.Print("Introduce el tipo: ")
		t.Tipo = leerTerminal()
		fmt.Println("---------------------")
		fmt.Print("Introduce el titular: ")
		t.Titular = leerTerminal()
		fmt.Println("---------------------")
		fmt.Print("Introduce el número de la tarjeta: ")
		t.Numero = StringAInt(leerTerminal())
		fmt.Println("---------------------")
		fmt.Print("Introduce el CVV: ")
		t.CVV = StringAInt(leerTerminal())
		fmt.Println("---------------------")
		fmt.Print("Introduce la fecha de vencimiento: ")
		t.Fecha = leerTerminal()

		_, ok := gTarjeta[t.Tipo]
		if ok {
			fmt.Println("---------------------")
			fmt.Println("\n¡Este tipo de tarjeta ya existe!\n")
			fmt.Println("Si deseas cancelar la operación, escribe 'NO', sino se editará dicha tarjeta con los nuevos valores introducidos.")
			edittarj := leerTerminal()
			if edittarj == "No" || edittarj == "no" || edittarj == "NO" {
				Opciones(resp)
				return
			} else {
				gTarjeta[t.Tipo] = t
				d.Tarjeta = gTarjeta
			}
		} else {
			gTarjeta[t.Tipo] = t
			d.Tarjeta = gTarjeta
		}

	case "contraseña":
		if d.Contraseña == nil {
			gContraseña = make(map[string]contraseña)
		} else {
			gContraseña = d.Contraseña
		}
		c := contraseña{}
		fmt.Println("---------------------")
		fmt.Print("Sitio web/url: ")
		c.Url = leerTerminal()
		fmt.Println("---------------------")
		fmt.Print("Contraseña: ")
		c.Pwd = leerTerminal()

		_, ok := gContraseña[c.Url]
		if ok {
			fmt.Println("---------------------")
			fmt.Println("\n¡Ya tiene registrada una contraseña para este sitio web!\n")
			fmt.Println("Si deseas cancelar la operación, escribe 'NO', sino se editará dicha url con la nueva contraseña introducida.")
			editpasswd := leerTerminal()
			if editpasswd == "No" || editpasswd == "no" || editpasswd == "NO" {
				Opciones(resp)
				return
			} else {
				gContraseña[c.Url] = c
				d.Contraseña = gContraseña
			}
		} else {
			gContraseña[c.Url] = c
			d.Contraseña = gContraseña
		}
	case "salir":
		Opciones(resp)
		return
	default:
		fmt.Println("ERROR: No existe esa opción.")
		Opciones(resp)
		return
	}
	gData["data"] = d
	jsondata, err := json.Marshal(&gData)
	chk(err)
	fmt.Println(gData) //
	jsonData = encode64(encrypt(jsondata, u.KeyData))

	data := url.Values{}   // estructura para contener los valores
	data.Set("cmd", "add") // comando (string)
	data.Set("json", jsonData)
	data.Set("name", u.Name)
	r, err := client.PostForm("https://localhost:10443", data)
	chk(err)

	resp2 := Resp{}
	byteValue, _ := ioutil.ReadAll(r.Body)
	json.Unmarshal([]byte(byteValue), &resp2)
	// fmt.Println(resp2) //
	Opciones(resp2)
}
