package main

import (
	"fmt"
	"math/rand"
)

var alfabetoMayusculas = map[int]rune{0: 'A', 1: 'B', 2: 'C', 3: 'D', 4: 'E', 5: 'F', 6: 'G',
	7: 'H', 8: 'I', 9: 'J', 10: 'K', 11: 'L', 12: 'M', 13: 'N', 14: 'Ñ', 15: 'O', 16: 'P',
	17: 'Q', 18: 'R', 19: 'S', 20: 'T', 21: 'U', 22: 'V', 23: 'W', 24: 'X', 25: 'Y', 26: 'Z'}

var alfabetoMinusculas = map[int]rune{0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f', 6: 'g',
	7: 'h', 8: 'i', 9: 'j', 10: 'k', 11: 'l', 12: 'm', 13: 'n', 14: 'ñ', 15: 'o', 16: 'p',
	17: 'q', 18: 'r', 19: 's', 20: 't', 21: 'u', 22: 'v', 23: 'w', 24: 'x', 25: 'y', 26: 'z'}

var alfabetoMinusculasNums = map[int]rune{0: 'a', 1: 'b', 2: 'c', 3: 'd', 4: 'e', 5: 'f',
	6: 'g', 7: 'h', 8: 'i', 9: 'j', 10: 'k', 11: 'l', 12: 'm', 13: 'n', 14: 'ñ', 15: 'o',
	16: 'p', 17: 'q', 18: 'r', 19: 's', 20: 't', 21: 'u', 22: 'v', 23: 'w', 24: 'x',
	25: 'y', 26: 'z', 27: '0', 28: '1', 29: '2', 30: '3', 31: '4', 32: '5', 33: '6',
	34: '7', 35: '8', 36: '9'}

var alfabetoLetras = map[int]rune{0: 'A', 1: 'a', 2: 'B', 3: 'b', 4: 'C', 5: 'c', 6: 'D',
	7: 'd', 8: 'E', 9: 'e', 10: 'F', 11: 'f', 12: 'G', 13: 'g', 14: 'H', 15: 'h', 16: 'I',
	17: 'i', 18: 'J', 19: 'j', 20: 'K', 21: 'k', 22: 'L', 23: 'l', 24: 'M', 25: 'm', 26: 'N',
	27: 'n', 28: 'Ñ', 29: 'ñ', 30: 'O', 31: 'o', 32: 'P', 33: 'p', 34: 'Q', 35: 'q', 36: 'R',
	37: 'r', 38: 'S', 39: 's', 40: 'T', 41: 't', 42: 'U', 43: 'u', 44: 'V', 45: 'v', 46: 'W',
	47: 'w', 48: 'X', 49: 'x', 50: 'Y', 51: 'y', 52: 'Z', 53: 'z'}

var alfabetoVocales = map[int]rune{0: 'A', 1: 'a', 2: 'E', 3: 'e', 4: 'I', 5: 'i', 6: 'O',
	7: 'o', 8: 'U', 9: 'u'}

var alfabetoVocalesMinusculas = map[int]rune{0: 'a', 1: 'e', 2: 'i', 3: 'o', 4: 'u'}

var alfabetoConsonantes = map[int]rune{0: 'B', 1: 'b', 2: 'C', 3: 'c', 4: 'D', 5: 'd',
	6: 'F', 7: 'f', 8: 'G', 9: 'g', 10: 'H', 11: 'h', 12: 'J', 13: 'j', 14: 'K', 15: 'k',
	16: 'L', 17: 'l', 18: 'M', 19: 'm', 20: 'N', 21: 'n', 22: 'Ñ', 23: 'ñ', 24: 'P', 25: 'p',
	26: 'Q', 27: 'q', 28: 'R', 29: 'r', 30: 'S', 31: 's', 32: 'T', 33: 't', 34: 'V', 35: 'v',
	36: 'W', 37: 'w', 38: 'X', 39: 'x', 40: 'Y', 41: 'y', 42: 'Z', 43: 'z'}

var alfabetoConsonantesMinusculas = map[int]rune{0: 'b', 1: 'c', 2: 'd', 3: 'f', 4: 'g',
	5: 'h', 6: 'j', 7: 'k', 8: 'l', 9: 'm', 10: 'n', 11: 'ñ', 12: 'p', 13: 'q', 14: 'r',
	15: 's', 16: 't', 17: 'v', 18: 'w', 19: 'x', 20: 'y', 21: 'z'}

var alfabetoNumeros = map[int]rune{0: '0', 1: '1', 2: '2', 3: '3',
	4: '4', 5: '5', 6: '6', 7: '7', 8: '8', 9: '9'}

var alfabetoNumeros2 = map[string]int{"0": 0, "1": 1, "2": 2, "3": 3,
	"4": 4, "5": 5, "6": 6, "7": 7, "8": 8, "9": 9}

var alfabetoLetrasNums = map[int]rune{0: 'A', 1: 'a', 2: 'B', 3: 'b', 4: 'C', 5: 'c', 6: 'D',
	7: 'd', 8: 'E', 9: 'e', 10: 'F', 11: 'f', 12: 'G', 13: 'g', 14: 'H', 15: 'h', 16: 'I',
	17: 'i', 18: 'J', 19: 'j', 20: 'K', 21: 'k', 22: 'L', 23: 'l', 24: 'M', 25: 'm', 26: 'N',
	27: 'n', 28: 'Ñ', 29: 'ñ', 30: 'O', 31: 'o', 32: 'P', 33: 'p', 34: 'Q', 35: 'q', 36: 'R',
	37: 'r', 38: 'S', 39: 's', 40: 'T', 41: 't', 42: 'U', 43: 'u', 44: 'V', 45: 'v', 46: 'W',
	47: 'w', 48: 'X', 49: 'x', 50: 'Y', 51: 'y', 52: 'Z', 53: 'z', 54: '0', 55: '1', 56: '2',
	57: '3', 58: '4', 59: '5', 60: '6', 61: '7', 62: '8', 63: '9'}

var alfabetoTodo = map[int]rune{0: 'A', 1: 'a', 2: 'B', 3: 'b', 4: 'C', 5: 'c', 6: 'D', 7: 'd',
	8: 'E', 9: 'e', 10: 'F', 11: 'f', 12: 'G', 13: 'g', 14: 'H', 15: 'h', 16: 'I', 17: 'i',
	18: 'J', 19: 'j', 20: 'K', 21: 'k', 22: 'L', 23: 'l', 24: 'M', 25: 'm', 26: 'N', 27: 'n',
	28: 'Ñ', 29: 'ñ', 30: 'O', 31: 'o', 32: 'P', 33: 'p', 34: 'Q', 35: 'q', 36: 'R', 37: 'r',
	38: 'S', 39: 's', 40: 'T', 41: 't', 42: 'U', 43: 'u', 44: 'V', 45: 'v', 46: 'W', 47: 'w',
	48: 'X', 49: 'x', 50: 'Y', 51: 'y', 52: 'Z', 53: 'z', 54: '0', 55: '1', 56: '2', 57: '3',
	58: '4', 59: '5', 60: '6', 61: '7', 62: '8', 63: '9', 64: '!', 65: '"', 66: '#', 67: '$',
	68: '%', 69: '&', 70: '(', 71: ')', 72: '*', 73: '+', 74: ',', 75: '-', 76: '.', 77: '/',
	78: ':', 79: ';', 80: '<', 81: '=', 82: '>', 83: '?', 84: '@', 85: '[', 86: '\\', 87: ']',
	88: '_', 89: '{', 90: '|', 91: '}'}

var alfabetoSimbolos = map[int]rune{0: '!', 1: '"', 2: '#', 3: '$', 4: '%', 5: '&', 6: '(', 7: ')',
	8: '*', 9: '+', 10: ',', 11: '-', 12: '.', 13: '/', 14: ':', 15: ';', 16: '<', 17: '=',
	18: '>', 19: '?', 20: '@', 21: '[', 22: '\\', 23: ']', 24: '_', 25: '{', 26: '|', 27: '}'}

var condicionesValidas = map[int]string{0: "A", 1: "B", 2: "C", 3: "D", 4: "E", 5: "F", 6: "G"}

func generator() string {
	psword := ""
	okPsword := false
	tocaVocal := false

	for !okPsword {
		psword = ""

		fmt.Println("")
		fmt.Println("=====================")
		fmt.Println("")
		fmt.Println("¿Cómo quieres que sea tu contraseña?")
		fmt.Println("A = Solo letras minúsculas.")
		fmt.Println("B = Letras minúsculas y mayúsculas.")
		fmt.Println("C = Solo números.")
		fmt.Println("D = Números y letras minúsculas.")
		fmt.Println("E = Números y letras minúsculas y mayúsculas.")
		fmt.Println("F = Cualquier caracter.")
		fmt.Println("G = Pronunciable en minúsculas.")
		fmt.Println("H = Pronunciable con minúsculas y mayúsculas.")
		fmt.Println("")
		fmt.Print("Opción: ")
		condicion := leerTerminal()
		fmt.Println("")

		existe := false
		cant := 0

		for cant < 7 {
			if condicion == condicionesValidas[cant] {
				existe = true
			}
			cant++
		}

		if existe {
			fmt.Print("Cantidad de caracteres: ")
			longStr := leerTerminal()
			aleatorio := 0
			longInt := StringAInt(longStr)

			_, ok := alfabetoNumeros2[longStr]

			if ok {
				if condicion == "A" || condicion == "a" {
					for longInt > 0 {
						aleatorio = rand.Intn(27)
						psword += string(alfabetoMinusculas[aleatorio])
						longInt--
					}

				} else if condicion == "B" || condicion == "b" {
					for longInt > 0 {
						aleatorio = rand.Intn(54)
						psword += string(alfabetoLetras[aleatorio])
						longInt--
					}

				} else if condicion == "C" || condicion == "c" {
					for longInt > 0 {
						aleatorio = rand.Intn(10)
						psword += string(alfabetoNumeros[aleatorio])
						longInt--
					}

				} else if condicion == "D" || condicion == "d" {
					for longInt > 0 {
						aleatorio = rand.Intn(64)
						psword += string(alfabetoMinusculasNums[aleatorio])
						longInt--
					}

				} else if condicion == "E" || condicion == "e" {
					for longInt > 0 {
						aleatorio = rand.Intn(74)
						psword += string(alfabetoLetrasNums[aleatorio])
						longInt--
					}

				} else if condicion == "F" || condicion == "f" {
					for longInt > 0 {
						aleatorio = rand.Intn(92)
						psword += string(alfabetoTodo[aleatorio])
						longInt--
					}

				} else if condicion == "G" || condicion == "g" {
					for longInt > 0 {
						if tocaVocal {
							aleatorio = rand.Intn(5)
							psword += string(alfabetoVocalesMinusculas[aleatorio])
							tocaVocal = false
						} else {
							aleatorio = rand.Intn(22)
							psword += string(alfabetoConsonantesMinusculas[aleatorio])
							tocaVocal = true
						}
						longInt--
					}

				} else if condicion == "H" || condicion == "h" {
					for longInt > 0 {
						if tocaVocal {
							aleatorio = rand.Intn(10)
							psword += string(alfabetoVocales[aleatorio])
							tocaVocal = false
						} else {
							aleatorio = rand.Intn(44)
							psword += string(alfabetoConsonantes[aleatorio])
							tocaVocal = true
						}
						longInt--
					}

				}
				fmt.Println("")
				fmt.Println("La contraseña generada ha sido: " + psword)
				fmt.Println("")
				fmt.Print("¿Quieres quedarte con esta contraseña? (S/N): ")
				okey := leerTerminal()

				if okey == "S" || okey == "s" {
					okPsword = true
				}
			} else {
				fmt.Println("Error: No es un número.")
			}
		} else {
			fmt.Println("Error: Esa opción no existe. Vuelve a elegirla.")
		}

	}

	return psword
}
