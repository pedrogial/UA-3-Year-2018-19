package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/url"
	"os"

	arg "github.com/alexflint/go-arg"
)

var jsonData string

func conseguirFichero(cmd string) {
	data := url.Values{} // estructura para contener los valores
	data.Set("cmd", cmd) // comando (string)
	data.Set("name", u.Name)
	r, err := client.PostForm("https://localhost:10443", data)
	chk(err)

	//Respuesta
	resp := Respfix{}

	byteValue, _ := ioutil.ReadAll(r.Body)
	json.Unmarshal([]byte(byteValue), &resp)

	// fmt.Println(resp) //
	gData = make(map[string]Data)

	if resp.File != "" {
		json.Unmarshal(decrypt(decode64(resp.File), u.KeyData), &gData)
	}

	// fmt.Println(gData) //
}

func Opciones(resp Resp) {
	fmt.Println("")
	fmt.Println("-" + resp.Msg + "-")

	if !resp.Ok {
		fmt.Println("Salir")
		return
	} else {

		if resp.Msg == "Usuario registrado" {
			fmt.Println("Ahora Inicia Sesion")
			signin(client, "login")

		} else if resp.Msg == "Credenciales válidas" ||
			resp.Msg == "Añadido a la base de datos" {

			fmt.Println("----------------------")
			fmt.Println("---- MENÚ INICIAL ----")
			fmt.Println("----------------------")
			fmt.Println("Estas son las opciones disponibles:")
			fmt.Println("1. Añadir/Editar datos.")
			fmt.Println("2. Ver/Buscar datos.")
			fmt.Println("3. Borrar datos.")
			fmt.Println("4. Cerrar el programa.")
			fmt.Println("---------------------")
			fmt.Print("Dime la opción que desea realizar: ")
			number := StringAInt(leerTerminal())

			conseguirFichero("fix")
			fmt.Println("")
			switch number {
			case 1:
				save("add", resp)
				return
			case 2:
				view(resp)
				return
			case 3:
				deleteElement("delete", resp)
				return
			case 4:
				return
			default:
				Opciones(resp)
				return
			}
		}
	}
}

//Seleccion de inicio sesion o registrarse
func main() {
	var args struct {
		Operation string `arg:"positional, required" help:"(signup|signin)"`
	}

	fmt.Println("Gestor de Contraseñas")
	fmt.Println("----------------------")
	parser := arg.MustParse(&args)

	switch args.Operation {
	case "signup":
		signup(client, "register")
	case "signin":
		signin(client, "login")
	case "help":
		parser.WriteHelp(os.Stdin)
	default:
		parser.Fail(args.Operation)
	}
}
