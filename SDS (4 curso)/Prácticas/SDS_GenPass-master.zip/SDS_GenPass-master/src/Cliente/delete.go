package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"net/url"
)

func deleteElement(cmd string, resp Resp) {
	fmt.Println("¿Que quieres borrar?")
	fmt.Println("---------------------")
	fmt.Println("(nota/tarjeta/contraseña/salir)")

	tipo := leerTerminal()
	d := gData["data"]
	borrado := false

	//Incializamos por si acaso, si hay alguno que no se ha rellenado y da error,
	//eso no queremos que pase :)

	switch tipo {
	case "nota":
		if d.Nota == nil {
			gNota = make(map[string]nota)
		} else {
			gNota = d.Nota
		}
		n := nota{}
		fmt.Println("---------------------")
		fmt.Print("Introduce el título de la nota que deseas borrar: ")
		n.Titulo = leerTerminal()

		_, ok := gNota[n.Titulo]
		if ok {
			fmt.Println("---------------------")
			fmt.Print("¿Estás seguro/a de querer borrar esta nota? (Si/No): ")
			elimnota := leerTerminal()
			if elimnota == "No" || elimnota == "no" || elimnota == "NO" {
				Opciones(resp)
				return
			} else {
				delete(gNota, n.Titulo)
				d.Nota = gNota
				borrado = true
			}
		} else {
			fmt.Println("ERROR: No existe esa nota.")
		}
	case "tarjeta":
		if d.Tarjeta == nil {
			gTarjeta = make(map[string]tarjeta)
		} else {
			gTarjeta = d.Tarjeta
		}
		t := tarjeta{}
		fmt.Println("---------------------")
		fmt.Print("Introduce el tipo de la tarjeta que deseas borrar: ")
		t.Tipo = leerTerminal()

		_, ok := gTarjeta[t.Tipo]
		if ok {
			fmt.Println("---------------------")
			fmt.Print("¿Estás seguro/a de querer borrar esta tarjeta? (Si/No): ")
			elimtarj := leerTerminal()
			if elimtarj == "No" || elimtarj == "no" || elimtarj == "NO" {
				Opciones(resp)
				return
			} else {
				delete(gTarjeta, t.Tipo)
				d.Tarjeta = gTarjeta
				borrado = true

			}
		} else {
			fmt.Println("ERROR: No existe esa tarjeta.")
		}

	case "contraseña":
		if d.Contraseña == nil {
			gContraseña = make(map[string]contraseña)
		} else {
			gContraseña = d.Contraseña
		}
		c := contraseña{}
		fmt.Println("---------------------")
		fmt.Println("Introduce el sitio web/url de la contraseña que deseas borrar: ")
		c.Url = leerTerminal()

		_, ok := gContraseña[c.Url]
		if ok {
			fmt.Println("---------------------")
			fmt.Print("¿Estás seguro/a de querer borrar esta contraseña? (Si/No): ")
			elimpasswd := leerTerminal()
			if elimpasswd == "No" || elimpasswd == "no" || elimpasswd == "NO" {
				Opciones(resp)
				return
			} else {
				delete(gContraseña, c.Url)
				d.Contraseña = gContraseña
				borrado = true

			}
		} else {
			fmt.Println("No existe esa contraseña")
		}
	case "salir":
		Opciones(resp)
	default:
		fmt.Println("Error, esa opcion no existe")
		Opciones(resp)
	}
	if borrado == true {
		gData["data"] = d
		jsondata, err := json.Marshal(&gData)
		chk(err)
		fmt.Println(gData) //
		jsonData = encode64(encrypt(jsondata, u.KeyData))

		data := url.Values{}   // estructura para contener los valores
		data.Set("cmd", "add") // comando (string)
		data.Set("json", jsonData)
		data.Set("name", u.Name)
		r, err := client.PostForm("https://localhost:10443", data)
		chk(err)

		resp2 := Resp{}
		byteValue, _ := ioutil.ReadAll(r.Body)
		json.Unmarshal([]byte(byteValue), &resp2)
		// fmt.Println(resp2) //
		Opciones(resp2)
		return
	} else {
		Opciones(resp)
		return
	}

}
