package main

import (
	"fmt"
	"strconv"
)

func view(resp Resp) {

	salir := false

	for !salir {
		fmt.Println("")
		fmt.Println("=====================")
		fmt.Println("")
		fmt.Println("¿Que quieres buscar?")
		fmt.Println("N = Todas las notas")
		fmt.Println("T = Todas las tarjetas")
		fmt.Println("C = Todas las contraseñas")
		fmt.Println("A = Todos los archivos")
		fmt.Println("I = Buscar por identificador")
		fmt.Println("M = Volver al menú inicial")
		fmt.Println("")
		fmt.Print("Opción: ")
		busco := leerTerminal()

		d := gData["data"]
		vacio := true

		//Incializamos por si acaso, si hay alguno que no se ha rellenado y da error,
		//eso no queremos que pase :)
		if d.Nota == nil {
			gNota = make(map[string]nota)
		} else {
			gNota = d.Nota
		}
		if d.Tarjeta == nil {
			gTarjeta = make(map[string]tarjeta)
		} else {
			gTarjeta = d.Tarjeta
		}
		if d.Contraseña == nil {
			gContraseña = make(map[string]contraseña)
		} else {
			gContraseña = d.Contraseña
		}

		if busco == "N" || busco == "n" {
			fmt.Println("")
			fmt.Println("*********************")
			fmt.Println("--------Notas--------")
			fmt.Println("*********************")

			for k := range gNota {
				fmt.Println("")
				fmt.Println("Titulo: " + gNota[k].Titulo)
				fmt.Println("Cuerpo: " + gNota[k].Cuerpo)
				fmt.Println("")
				fmt.Println("---------------------")
				vacio = false
			}

			if vacio {
				fmt.Println("No hay notas registradas.")
			}

		} else if busco == "T" || busco == "t" {
			fmt.Println("")
			fmt.Println("*********************")
			fmt.Println("------Tarjetas-------")
			fmt.Println("*********************")

			for k := range gTarjeta {
				fmt.Println("")
				fmt.Println("Tipo: " + gTarjeta[k].Tipo)
				fmt.Println("Titular: " + gTarjeta[k].Titular)
				fmt.Println("Numero de la tarjeta: " + strconv.Itoa(int(gTarjeta[k].Numero)))
				fmt.Println("CVV: " + strconv.Itoa(int(gTarjeta[k].CVV)))
				fmt.Println("Fecha de Vencimiento: " + gTarjeta[k].Fecha)
				fmt.Println("")
				fmt.Println("---------------------")
				vacio = false
			}

			if vacio {
				fmt.Println("No hay tarjetas registradas.")
			}

		} else if busco == "C" || busco == "c" {
			fmt.Println("")
			fmt.Println("*********************")
			fmt.Println("-----Contraseñas-----")
			fmt.Println("*********************")

			for k := range gContraseña {
				fmt.Println("")
				fmt.Println("Url: " + gContraseña[k].Url)
				fmt.Println("Contraseña: " + gContraseña[k].Pwd)
				fmt.Println("")
				fmt.Println("---------------------")
				vacio = false
			}

			if vacio {
				fmt.Println("No hay contraseñas registradas.")
			}

		} else if busco == "A" || busco == "a" {

			vacio = true

			fmt.Println("")
			fmt.Println("*********************")
			fmt.Println("--------Notas--------")
			fmt.Println("*********************")

			for k := range gNota {
				fmt.Println("")
				fmt.Println("Titulo: " + gNota[k].Titulo)
				fmt.Println("Cuerpo: " + gNota[k].Cuerpo)
				fmt.Println("")
				fmt.Println("---------------------")
				vacio = false
			}

			if vacio {
				fmt.Println("No hay notas registradas.")
			}

			vacio = true

			fmt.Println("")
			fmt.Println("*********************")
			fmt.Println("------Tarjetas-------")
			fmt.Println("*********************")

			for k := range gTarjeta {
				fmt.Println("")
				fmt.Println("Tipo: " + gTarjeta[k].Tipo)
				fmt.Println("Titular: " + gTarjeta[k].Titular)
				fmt.Println("Numero de la tarjeta: " + strconv.Itoa(int(gTarjeta[k].Numero))) //Hago esto porque es de tipo int64
				fmt.Println("CVV: " + strconv.Itoa(int(gTarjeta[k].CVV)))                     //y es necesario para el itoa que este en int
				fmt.Println("Fecha de Vencimiento: " + gTarjeta[k].Fecha)
				fmt.Println("")
				fmt.Println("---------------------")
				vacio = false
			}

			if vacio {
				fmt.Println("No hay tarjetas registradas.")
			}

			vacio = true

			fmt.Println("")
			fmt.Println("*********************")
			fmt.Println("-----Contraseñas-----")
			fmt.Println("*********************")

			for k := range gContraseña {
				fmt.Println("")
				fmt.Println("Url: " + gContraseña[k].Url)
				fmt.Println("Contraseña: " + gContraseña[k].Pwd)
				fmt.Println("")
				fmt.Println("---------------------")
				vacio = false
			}

			if vacio {
				fmt.Println("No hay contraseñas registradas.")
			}

		} else if busco == "I" {
			//Primero eliges de los 3 que hay, cual quieres buscar y luego buscas por su
			//identificador, miralo en el editar que lo hice (_, ok := gNota[n.Titulo]) asi
			//buscas el titulo de la nota que te he pasas y como es único solo saldrá ese y
			//lo imprimes si es okey, imprimes todos sus datos
			fmt.Println("")
			fmt.Println("¿De qué tipo?")
			fmt.Println(" N = Notas")
			fmt.Println(" T = Tarjetas")
			fmt.Println(" C = Contraseñas")
			fmt.Println(" M = Volver al menú anterior")
			fmt.Println("")
			fmt.Print("Opción: ")
			tipo := leerTerminal()
			encontrado := false

			if tipo == "N" {
				fmt.Print("Introduce el título de la nota: ")
				identN := leerTerminal()

				for k := range gNota {
					if gNota[k].Titulo == identN {
						fmt.Println("")
						fmt.Println("*********************")
						fmt.Println("--------Nota---------")
						fmt.Println("*********************")
						fmt.Println("")
						fmt.Println("Titulo: " + gNota[k].Titulo)
						fmt.Println("Cuerpo: " + gNota[k].Cuerpo)
						fmt.Println("")
						encontrado = true
						break
					}
				}
				if !encontrado {
					fmt.Println("Error: No existe una nota con dicho título.")
				}

			} else if tipo == "T" || tipo == "t" {
				fmt.Print("Introduce el número de tarjeta: ")
				identT := leerTerminal()

				for k := range gTarjeta {
					if strconv.Itoa(int(gTarjeta[k].Numero)) == identT {
						fmt.Println("")
						fmt.Println("*********************")
						fmt.Println("------Tarjeta--------")
						fmt.Println("*********************")
						fmt.Println("")
						fmt.Println("Tipo: " + gTarjeta[k].Tipo)
						fmt.Println("Titular: " + gTarjeta[k].Titular)
						fmt.Println("Numero de la tarjeta: " + strconv.Itoa(int(gTarjeta[k].Numero)))
						fmt.Println("CVV: " + strconv.Itoa(int(gTarjeta[k].CVV)))
						fmt.Println("Fecha de Vencimiento: " + gTarjeta[k].Fecha)
						fmt.Println("")
						encontrado = true
						break
					}
				}
				if !encontrado {
					fmt.Println("Error: No existe esa tarjeta.")
				}

			} else if tipo == "C" || tipo == "c" {
				fmt.Print("Introduce la URL de la contraseña que desea: ")
				identC := leerTerminal()

				for k := range gContraseña {
					if gContraseña[k].Url == identC {
						fmt.Println("")
						fmt.Println("*********************")
						fmt.Println("-----Contraseña------")
						fmt.Println("*********************")
						fmt.Println("")
						fmt.Println("Url: " + gContraseña[k].Url)
						fmt.Println("Contraseña: " + gContraseña[k].Pwd)
						fmt.Println("")
						encontrado = true
						break
					}
				}
				if !encontrado {
					fmt.Println("Error: No ha guardado contraseña para esa URL.")
				}

			} else if tipo == "M" || tipo == "m" {

			} else {
				fmt.Println("Error: Esa opción no existe.")
				view(resp)
			}

		} else if busco == "M" || busco == "m" {
			salir = true

		} else {
			fmt.Println("Error: Esa opción no existe.")
			view(resp)
			return
		}
	}

	Opciones(resp)
}
