package main

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
)

// ejemplo de tipo para un usuario
type user struct {
	Name string // nombre de usuario
}

// (se podría codificar en JSON y escribir/leer de disco para persistencia)
var gUsers map[string]user

func main() {
	u := user{}
	u.Name = "Melanie"
	gUsers = make(map[string]user)
	jsonFile, err := os.Open("registro.json") // abrimos el primer fichero (entrada)
	if err != nil {
		jsonFile, err = os.Create("registro.json") // abrimos el segundo fichero (salida)
		if err != nil {
			panic(err)
		}
	}
	defer jsonFile.Close()
	byteValue, _ := ioutil.ReadAll(jsonFile)
	json.Unmarshal([]byte(byteValue), &gUsers)
	gUsers[u.Name] = u
	fmt.Println(gUsers)
	os.Remove("registro.json")
	jsonFile, err = os.Create("registro.json")

	jsonF, err := json.Marshal(&gUsers)
	encode64(encrypt(compress(jsonF), keyData))
	err = ioutil.WriteFile("registro.json", jsonF, 0644)

}
