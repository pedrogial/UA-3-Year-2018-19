<?php
use App\User;
use App\Evento;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/', function() {
    $evento = Evento::orderBy('nombre','ASC')->orderBy('precio','DESC')->paginate(3);
    return view('inicio',compact('evento'));
});
Route::get('/search', 'UserController@search')->name('usuario.search');
Route::get('/filter', 'UserController@filter')->name('usuario.filter');
Route::resource('evento','EventoController'); // Este método genera todas las routas automáticamente
Route::resource('usuario','UserController');
Route::resource('ticket','TicketController');
Route::resource('lugar','LugarController');
Route::resource('categoria','CategoriaController');


