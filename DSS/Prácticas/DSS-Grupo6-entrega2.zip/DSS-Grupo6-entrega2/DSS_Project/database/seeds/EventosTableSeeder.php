<?php

use Illuminate\Database\Seeder;
use App\Evento;
use App\Categoria;
use App\Lugar;

class EventosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $img = '/images/evento.jpeg';

        Evento::truncate();

        $c0 = Categoria::where('nombre','Musical')->first();
        $c1 = Categoria::where('nombre','Teatro')->first();
        $c2 = Categoria::where('nombre','Concierto')->first();

        $c0->eventos()->saveMany([
            new Evento(['nombre' => 'Evento1',
                        'descripcion' => 'Hola soy una descripción genérica',
                        'imagen' => $img,
                        'precio' => 10.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))]),                    
        ]);
        $c1->eventos()->saveMany([
            new Evento(['nombre' => 'Evento2',
                        'descripcion' => 'Hola soy una descripción genérica',
                        'imagen' => $img,
                        'precio' => 20.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))]), //Se puede hacer así tb
            new Evento(['nombre' => 'Evento3',
                        'descripcion' => 'Hola soy una descripción genérica',
                        'imagen' => $img,
                        'precio' => 30.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))])
        ]);
        
        $c2->eventos()->saveMany([
            new Evento(['nombre' => 'Evento4',
                        'descripcion' => 'Hola soy una descripción genérica',
                        'imagen' => $img,
                        'precio' => 40.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))])
        ]);

        $l0 = Lugar::where('nombre','Anfiteatro')->first();
        $l1 = Lugar::where('nombre','Teatro principal')->first();
        $l2 = Lugar::where('nombre','Casa de cultura')->first();
        
        $l0->eventos()->saveMany([
            Evento::where('id',1)->first(),
            Evento::where('id',2)->first()
        ]);

        $l1->eventos()->saveMany([
            Evento::where('id',3)->first(),
        ]);

        $l2->eventos()->saveMany([
            Evento::where('id',4)->first(),
        ]);

    }
}
