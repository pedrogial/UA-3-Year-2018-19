<?php

use Illuminate\Database\Seeder;
use Illuminate\Foundation\Auth\User;
use Carbon\Carbon;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::truncate();

        $s = new User(['nombre' => 'Rafa',
                        'email' => 'r1@rafa.com',
                        'password' => 'password1',
                        'telefono' => 111111111,
                        'direccion' => 'Calle 1',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/16/2003')),
                        'esOrganizador' => false]);
        $s->save();
        
        $s = new User(['nombre' => 'Rafa',
                        'email' => 'r2@rafa.com',
                        'password' => 'password1',
                        'telefono' => 111111111,
                        'direccion' => 'Calle 1',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/16/2003')),
                        'esOrganizador' => false]);
        $s->save();
        
        $s = new User(['nombre' => 'Rafa',
                        'email' => 'r3@rafa.com',
                        'password' => 'password1',
                        'telefono' => 111111111,
                        'direccion' => 'Calle 1',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/16/2003')),
                        'esOrganizador' => false]);
        $s->save();
        
        $s = new User(['nombre' => 'Melanie',
                        'email' => 'melanie@nodaunpaloalagua.com',
                        'password' => 'password2',
                        'telefono' => 222222222,
                        'direccion' => 'Calle 2',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/17/2003')),
                        'esOrganizador' => false]);
        $s->save();

        $s = new User(['nombre' => 'Pedro',
                        'email' => 'pedro@pedro.com',
                        'password' => 'password3',
                        'telefono' => 333333333,
                        'direccion' => 'Calle 3',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/18/2003')),
                        'esOrganizador' => false]);
        $s->save();

        $s = new User(['nombre' => 'Dani',
                        'email' => 'dani@dani.com',
                        'password' => 'password4',
                        'telefono' => 444444444,
                        'direccion' => 'Calle 4',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/20/2003')),
                        'esOrganizador' => false]);
        $s->save();  

        $s = new User(['nombre' => 'Dani',
                        'email' => 'd1@dani.com',
                        'password' => 'password4',
                        'telefono' => 444444444,
                        'direccion' => 'Calle 4',
                        'fechaNacimiento' => date('Y-m-d',strtotime('11/20/2003')),
                        'esOrganizador' => false]);
        $s->save();

        $s = new User(['nombre' => 'Dani',
                        'email' => 'd2@dani.com',
                        'password' => 'password4',
                        'telefono' => 444444444,
                        'direccion' => 'Calle 4',
                        'fechaNacimiento' => date('Y-m-d',strtotime('11/16/2003')),
                        'esOrganizador' => false]);
        $s->save();

    }
}
