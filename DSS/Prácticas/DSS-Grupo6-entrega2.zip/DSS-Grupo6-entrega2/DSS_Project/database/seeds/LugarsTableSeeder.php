<?php

use Illuminate\Database\Seeder;
use App\Lugar;
class LugarsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Lugar::truncate();

        $s = new Lugar(['nombre' => 'Anfiteatro',
                        'telefono' => 222222222,
                        'direccion' => 'Plaza MiCasa 1',
                        'aforo' => 500]);
        $s->save(); 

        $s = new Lugar(['nombre' => 'Teatro principal',
                        'telefono' => 999999999,
                        'direccion' => 'Plaza Mayor 2',
                        'aforo' => 700]);
        $s->save(); 

        $s = new Lugar(['nombre' => 'Casa de cultura',
                        'telefono' => 666666666,
                        'direccion' => 'Plaza Mayor 1',
                        'aforo' => 400]);
        $s->save(); 
        $s = new Lugar(['nombre' => 'UA',
                        'telefono' => 666666666,
                        'direccion' => 'Plaza Mayor 3',
                        'aforo' => 800]);
        $s->save(); 
    }
}
