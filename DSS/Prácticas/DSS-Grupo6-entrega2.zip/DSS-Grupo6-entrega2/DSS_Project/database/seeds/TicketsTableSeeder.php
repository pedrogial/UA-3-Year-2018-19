<?php

use Illuminate\Database\Seeder;
use App\Evento;
use App\User;
use App\Ticket;

class TicketsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Ticket::truncate();

        $u0 = User::where('nombre','Rafa')->first();
        $u1 = User::where('nombre','Melanie')->first();
        $u2 = User::where('nombre','Pedro')->first();
        $u3 = User::where('nombre','Dani')->first();
        
        $u0->tickets()->saveMany([
            new Ticket(),
            new Ticket()
        ]);

        $u1->tickets()->saveMany([
            new Ticket(),
            new Ticket()
        ]);

        $u2->tickets()->saveMany([
            new Ticket(),
            new Ticket()
        ]);

        $u3->tickets()->saveMany([
            new Ticket(),
            new Ticket()
        ]);

        $e0 = Evento::where('nombre','Evento1')->first();
        $e1 = Evento::where('nombre','Evento2')->first();
        $e2 = Evento::where('nombre','Evento3')->first();

        $e0->tickets()->saveMany([
            Ticket::where('id',1)->first(),
            Ticket::where('id',2)->first()
        ]);

        $e1->tickets()->saveMany([
            Ticket::where('id',3)->first(),
            Ticket::where('id',4)->first()
        ]);

        $e2->tickets()->saveMany([
            Ticket::where('id',5)->first(),
            Ticket::where('id',6)->first(),
            Ticket::where('id',7)->first(),
            Ticket::where('id',8)->first()
        ]);
        
    }
}
