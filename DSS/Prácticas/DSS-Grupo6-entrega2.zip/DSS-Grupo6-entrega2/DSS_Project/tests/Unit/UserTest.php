<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\User;
use App\Ticket;

class UserTest extends TestCase
{
    /**
     * A basic unit test example.
     *
     * @return void
     */
    public function testUserData()
    {
        $count = User::all()->count();
        $this->assertEquals($count, 4);

        $this->assertDatabaseHas('users', ['nombre' => 'Rafa']);
        $this->assertDatabaseHas('users', ['nombre' => 'Melanie']);
        $this->assertDatabaseHas('users', ['nombre' => 'Pedro']);
        $this->assertDatabaseHas('users', ['nombre' => 'Dani']);
    }
    //Crea un ticket y un usuario y comprueba la asociación entre ambas
    public function testAssociationUserTicket()
    {
        $user = new User();
        $user->nombre = 'Usuario';
        $user->email = 'usuario@usuario.com';
        $user->password = 'password';
        $user->esOrganizador = false;
        $user->save();

        $ticket = new Ticket();
        $ticket->id = 9999 ;
        $user->tickets()->save($ticket);

        $this->assertEquals($ticket->user->nombre, 'Usuario');
        $this->assertEquals($ticket->user->email, 'usuario@usuario.com');
        $this->assertEquals($ticket->user->password, 'password');
        $this->assertEquals($ticket->user->esOrganizador, 0);
        $this->assertEquals($user->tickets[0]->id, 9999);
        
        $ticket->delete();
        $user->delete();
    }
}
