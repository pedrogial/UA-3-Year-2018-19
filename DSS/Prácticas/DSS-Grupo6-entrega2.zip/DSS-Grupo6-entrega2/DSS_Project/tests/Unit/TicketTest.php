<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Ticket;
use App\User;
use App\Evento;

class TicketTest extends TestCase
{
    public function testTicketData()
    {
        $count = Ticket::all()->count();
        $this->assertEquals($count, 8);

        $this->assertDatabaseHas('tickets', ['id' => 1]);
        $this->assertDatabaseHas('tickets', ['id' => 2]);
        $this->assertDatabaseHas('tickets', ['id' => 3]);
        $this->assertDatabaseHas('tickets', ['id' => 4]);
        $this->assertDatabaseHas('tickets', ['id' => 5]);
        $this->assertDatabaseHas('tickets', ['id' => 6]);
        $this->assertDatabaseHas('tickets', ['id' => 7]);
        $this->assertDatabaseHas('tickets', ['id' => 8]);
    }
    //Comprueba los tickets asociados a un evento
    public function testTicketsByEvento()
    {
        $evento = Evento::where('nombre', 'Evento1')->first();
        $this->assertEquals($evento->tickets->count(), 2);
        $this->assertTrue($evento->tickets->contains('id', 1));
        $this->assertTrue($evento->tickets->contains('id', 2));
    }
    //Comprueba los tickets asociados a un usuario
    public function testTicketsByUser()
    {
        $user = User::where('nombre', 'Rafa')->first();
        $this->assertEquals($user->tickets->count(), 2);
        $this->assertTrue($user->tickets->contains('id', 1));
        $this->assertTrue($user->tickets->contains('id', 2));
    }
}
