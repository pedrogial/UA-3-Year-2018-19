<?php

namespace Tests\Unit;

use Tests\TestCase;
use Illuminate\Foundation\Testing\WithFaker;
use Illuminate\Foundation\Testing\RefreshDatabase;
use App\Ticket;
use App\Evento;

class EventoTest extends TestCase
{
    public function testEventoData()
    {
        $count = Evento::all()->count();
        $this->assertEquals($count, 4);

        $this->assertDatabaseHas('eventos', ['nombre' => 'Evento1']);
        $this->assertDatabaseHas('eventos', ['nombre' => 'Evento2']);
        $this->assertDatabaseHas('eventos', ['nombre' => 'Evento3']);
        $this->assertDatabaseHas('eventos', ['nombre' => 'Evento4']);
    }
    //Crea un ticket y un evento y comprueba la asociación entre ambas
    public function testAssociationEventoTicket()
    {
        $evento = new Evento();
        $evento->nombre = 'Evento';
        $evento->precio = 100.00;
        $evento->fechaEvento = '2019-03-01 00:00:00';
        $evento->save();

        $ticket = new Ticket();
        $ticket->id = 9999 ;
        $evento->tickets()->save($ticket);

        $this->assertEquals($ticket->evento->nombre, 'Evento');
        $this->assertEquals($ticket->evento->precio, 100.00);
        $this->assertEquals($ticket->evento->fechaEvento, '2019-03-01 00:00:00');
        $this->assertEquals($evento->tickets[0]->id, 9999);
        
        $ticket->delete();
        $evento->delete();
    }
}
