<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Evento;
use App\Categoria;
use App\Lugar;
use App\Http\Requests\EventoRequest;

class EventoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $evento = Evento::orderBy('nombre','ASC')->orderBy('precio','DESC')->paginate(3);
        return view('eventos.index',compact('evento'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $categoria = Categoria::pluck('nombre', 'id');
        $lugar = Lugar::pluck('nombre', 'id');
        return view('eventos.create', compact('categoria', 'lugar'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EventoRequest $request)
    {
        
        $evento = new Evento;
        $count =Evento::where('nombre',$request->nombre)->count();
        if($count<=0){
            $evento->nombre = $request->nombre;
            $evento->descripcion = $request->descripcion;
            /*
            $logo=$request->file('imagen');
            $upload='/imagen/';
            $filename=$logo->getClientOriginalName();
            $success=$logo->move($upload,$filename);
            */
            $evento->imagen = '/images/'.$request->imagen;
            $evento->precio = $request->precio;
            $evento->fechaEvento= $request->fechaEvento;
            $evento->categoria_id= $request->categoria_id;
            $evento->lugar_id= $request->lugar_id;
            $evento->save();
            return redirect()->route('evento.index')->with('info','El evento fue guardado');
        }else{
            return redirect()->route('evento.index')->withErrors('El nombre del evento ya existe en la BD');
        }
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $evento = Evento::find($id);
        return view('eventos.show',compact('evento'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categoria = Categoria::pluck('nombre', 'id');
        $lugar = Lugar::pluck('nombre', 'id');
        $evento = Evento::find($id);
        return view('eventos.edit', compact('evento','categoria','lugar')).$id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(EventoRequest $request, $id)
    {
        $evento = Evento::find($id);
        $count =Evento::where('nombre',$request->nombre)->count();
        if($count<=0 || $evento->nombre == $request->nombre){
            $evento->nombre = $request->nombre;
            $evento->descripcion = $request->descripcion;
            $evento->imagen = '/images/'.$request->imagen;
            $evento->precio = $request->precio;
            $evento->fechaEvento= $request->fechaEvento;
            $evento->categoria_id= $request->categoria_id;
            $evento->lugar_id= $request->lugar_id;
            $evento->save();
            return redirect()->route('evento.index')->with('info','El evento fue actualizado');
        }else{
            return redirect()->route('evento.index')->withErrors('El nombre del evento ya existe en la BD');
        }

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $evento = Evento::find($id);
        $evento->delete();
        return back()->with('info','El evento fue eliminado');
    
    }
}
