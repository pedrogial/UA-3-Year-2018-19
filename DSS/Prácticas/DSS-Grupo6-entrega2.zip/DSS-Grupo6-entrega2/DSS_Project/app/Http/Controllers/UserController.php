<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Http\Requests\UserRequest;
use App\Product;
use DB;
use View;
use Illuminate\Support\Facades\Input;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $user = User::orderBy('nombre','DESC')->paginate(6);
        return view('usuarios.index',compact('user'));
    }
    public function search(Request $request){
        //No he sido capaz de paginar la salida debido a la forma en que está hecho.(Si alguien lo quiere intentar adelante)
        //solucion:  https://translate.googleusercontent.com/translate_c?depth=1&hl=es&prev=search&rurl=translate.google.com&sl=en&sp=nmt4&u=https://stackoverflow.com/questions/17159273/laravel-pagination-links-not-including-other-get-parameters&xid=17259,15700023,15700186,15700190,15700253&usg=ALkJrhiHkB6sV9uCvS9zDXr-tYcCyQ-erg

        $nombre = $request->get('nombre');
        $fechaNacimiento =  $request->get('fechaNacimiento');
        if(isset($nombre) && isset($fechaNacimiento)){
            $user = User::where([['nombre', 'like', '%'.$nombre.'%'], ['fechaNacimiento', '=', $fechaNacimiento]])->paginate(2);
            return view('usuarios.index',compact('user'));
        }else if(isset($nombre)){
            $user = User::where([['nombre', 'like', '%'.$nombre.'%']])->paginate(2);
            return view('usuarios.index',compact('user'));
        }else if(isset($fechaNacimiento)){
            $user = User::where([ ['fechaNacimiento', '=', $fechaNacimiento]])->paginate(2);
            return view('usuarios.index',compact('user'));
        }else{
            return redirect()->route('usuario.index');
        }
    }
    public function filter(Request $request){

        $nombre = $request->get('gender');
        if($nombre==1){
            $user = User::orderBy('nombre','ASC')->paginate(6);
            return view('usuarios.index',compact('user'));
        }else if($nombre==2){
            $user = User::orderBy('fechaNacimiento','ASC')->paginate(6);
            return view('usuarios.index',compact('user'));
        }else if($nombre==3){
            $user = User::orderBy('email','ASC')->paginate(6);
            return view('usuarios.index',compact('user'));
        }else{
            return redirect()->route('usuario.index');
        }
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('usuarios.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(UserRequest $request)
    {
        $user = new User;
        $count =User::where('email',$request->email)->count();
        
        if($count<=0){
            $user->nombre = $request->nombre;
            $user->password = $request->password;
            $user->direccion = $request->direccion;
            $user->telefono = $request->telefono;
            
            $user->email = $request->email;
            $user->fechaNacimiento = $request->fechaNacimiento;
            $user->save();
            return redirect()->route('usuario.index')->with('info','El usuario fue guardado');
        }else{
            return redirect()->route('usuario.create')->withErrors('Email invalido');
        }
       ;
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $usuario = User::find($id);
        return view('usuarios.show', compact('usuario'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $usuario = User::find($id);
        return view('usuarios.edit', compact('usuario')).$id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(UserRequest $request, $id)
    {
        $user = User::find($id);
        $user->nombre = $request->nombre;
        $user->password = $request->password;
        $user->direccion = $request->direccion;
        $user->telefono = $request->telefono;
        $user->email = $request->email;
        $user->fechaNacimiento= $request->fechaNacimiento;
        $user->save();
        return redirect()->route('usuario.index')->with('info','El usuario fue actualizado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $user = User::find($id);
        $user->delete();
        return back()->with('info','El usuario fue eliminado');
    }
}
