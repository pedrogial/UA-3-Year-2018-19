<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Categoria;
use App\Evento;
use App\Http\Requests\CategoriaRequest;

class CategoriaController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $categoria = Categoria::orderBy('nombre','ASC')->paginate(3);
        return view('categorias.index',compact('categoria'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categorias.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(CategoriaRequest $request)
    {
        $categoria = new Categoria;
        $categoria->nombre = $request->nombre;
        $count =Categoria::where('nombre',$request->nombre)->count();
        if($count<=0){
            $categoria->save();
            return redirect()->route('categoria.index')->with('info','La categoría fue creada');
        }else{
            return redirect()->route('categoria.index')->withErrors('La categoría introducida ya existe en la BD');
        }
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $categoria = Categoria::find($id);
        return view('categorias.show', compact('categoria'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categoria = Categoria::find($id);
        return view('categorias.edit', compact('categoria')).$id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(CategoriaRequest $request, $id)
    {
        $categoria = Categoria::find($id);
        $categoria->nombre = $request->nombre;
        $count =Categoria::where('nombre',$request->nombre)->count();
        if($count<=0 || $categoria->nombre == $request->nombre){
            $categoria->save();
            return redirect()->route('categoria.index')->with('info','La categoría fue actualizada');
        }else{
            return redirect()->route('categoria.index')->withErrors('La categoría introducida ya existe en la BD');
        }
    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $categoria = Categoria::find($id);
        $count =Evento::where('categoria_id',$id)->count();
        if($count>0){
            return back()->withErrors('La categoría no fue eliminada debido a que existen eventos asociados');
        }else{
            $categoria->delete();
            return back()->with('info','La categoría fue eliminada');
        }
        
    }
}
