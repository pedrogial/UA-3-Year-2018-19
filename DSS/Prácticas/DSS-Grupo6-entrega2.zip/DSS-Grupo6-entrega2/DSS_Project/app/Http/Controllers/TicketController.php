<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ticket;
use App\Evento;
use App\Categoria;
use App\Lugar;
use App\User;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ticket = Ticket::orderBy('id','ASC')->paginate(3);
        return view('tickets.index',compact('ticket'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $evento = Evento::pluck('nombre', 'id');
        $user = User::pluck('email', 'id');
        return view('tickets.create', compact('evento', 'user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ticket = new Ticket;

        $ticket->user_id = $request->user_id;
        $ticket->evento_id = $request->evento_id;

        $ticket->save();
        return redirect()->route('ticket.index')->with('info','El ticket fue guardado');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ticket = Ticket::find($id);
        return view('tickets.show',compact('ticket'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $evento = Evento::pluck('nombre', 'id');
        $user = User::pluck('email', 'id');
        $ticket = Ticket::find($id);
        return view('tickets.edit', compact('ticket','evento','user')).$id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $ticket = Ticket::find($id);

        $ticket->user_id = $request->user_id;
        $ticket->evento_id = $request->evento_id;

        $ticket->save();
        return redirect()->route('ticket.index')->with('info','El ticket fue guardado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ticket = Ticket::find($id);
        $ticket->delete();
        return back()->with('info','El ticket fue eliminado');
    }
}
