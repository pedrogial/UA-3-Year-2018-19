<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lugar extends Model
{
    protected $fillable = [
        'nombre', 'telefono', 'direccion', 'aforo'
    ];

    public function eventos(){
        return $this->hasmany('App\Evento');
    }
}
