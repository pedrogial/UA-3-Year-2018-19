<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Evento extends Model
{
    protected $fillable = [
        'nombre',
        'descripcion',
        'imagen',
        'precio',
        'fechaEvento',
        'categoria_id',
        'lugar_id'
    ];
    

    public function categoria(){
        return $this->belongsTo('App\Categoria');
    }
    public function lugar(){
        return $this->belongsTo('App\Lugar');
    }
    public function tickets() {
        return $this->hasMany('App\Ticket');
    }
}
