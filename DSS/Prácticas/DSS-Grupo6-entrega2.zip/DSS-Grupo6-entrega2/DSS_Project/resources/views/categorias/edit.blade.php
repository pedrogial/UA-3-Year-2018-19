@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Editar Categoria
            <a href="{{ route('categoria.index') }}" class="btn btn-default pull-right"> Listado de Categorias </a>
        </h1>

        @include('categorias.fragment.error')

        {!! Form::model($categoria, ['route' => ['categoria.update', $categoria->id], 'method' => 'PUT']) !!}
            @include('categorias.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection