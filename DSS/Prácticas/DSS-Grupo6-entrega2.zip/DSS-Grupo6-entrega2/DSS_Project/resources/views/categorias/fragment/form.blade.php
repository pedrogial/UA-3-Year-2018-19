<div class="form-group">
    {!!  Form::label('nombre', 'Nombre de la categoría')  !!}
    {!!  Form::text('nombre', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::submit('Enviar', ['class' => 'btn btn-primary'])  !!}
</div>
