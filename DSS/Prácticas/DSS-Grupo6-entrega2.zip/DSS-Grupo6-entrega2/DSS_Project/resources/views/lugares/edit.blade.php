@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Editar Lugar
            <a href="{{ route('lugar.index') }}" class="btn btn-default pull-right"> Listado de Lugares </a>
        </h1>

        @include('lugares.fragment.error')

        {!! Form::model($lugar, ['route' => ['lugar.update', $lugar->id], 'method' => 'PUT']) !!}
            @include('lugares.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection