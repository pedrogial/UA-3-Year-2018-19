@extends('layout')
@section('content')
    <div class="col-sm-12">
        <h2 class="mt-5 mb-5">
            Listado de Lugares
            <a href="{{route('lugar.create')}}" class="btn btn-primary"> Nuevo </a>
        </h2> 
        @include('lugares.fragment.info')
        @include('lugares.fragment.error')
        <table class= " table table-hover table-striped">
            <thead>
                <tr> 
                    <th  >Nombre</th>
                    <th  >Telefono</th>
                    <th  >Dirección</th>
                    <th  >Aforo</th>
                    <th colspan="3">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                @foreach($lugar as $l)
                <tr> 
                    <td>{{$l->nombre}}</td>
                    <td>{{$l->telefono}}</td>
                    <td>{{$l->direccion}}</td>
                    <td>{{$l->aforo}}</td>
                    <td>
                        <a href="{{ route('lugar.show', $l->id) }}"> ver </a>
                    </td>
                    <td>
                        <a href="{{ route('lugar.edit', $l->id) }}"> editar </a>
                    </td>
                    <td>
                        <form action="{{ route('lugar.destroy',$l->id)}}" method="POST">
                            {{csrf_field()}}
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-link">Borrar</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {!! $lugar->render() !!}
    </div>
@endsection