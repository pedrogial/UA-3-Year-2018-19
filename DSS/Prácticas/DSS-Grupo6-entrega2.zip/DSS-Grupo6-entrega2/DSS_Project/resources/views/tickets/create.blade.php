@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Crear ticket
            <a href="{{ route('ticket.index') }}" class="btn btn-default pull-right"> Listado de Tickets </a>
        </h1>

        @include('tickets.fragment.error')
        {!! Form::open(['route' => 'ticket.store']) !!}
            @include('tickets.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection