@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
    
        <h1 class = "font-weight-bold" >
            Ticket  
            <a href="{{ route('ticket.edit', $ticket->id) }}" class="btn btn-default pull-right"> editar </a>
        </h1>

                
        <p>Id ticket: {{$ticket->id}} </p>
        <p>Nombre del Usuario: {{$ticket->user->email}} </p>
        <p>Nombre del Evento: {{$ticket->evento->nombre}} </p>  
    </div>
@endsection