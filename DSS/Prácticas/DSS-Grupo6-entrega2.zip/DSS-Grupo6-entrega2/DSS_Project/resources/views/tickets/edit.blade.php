@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Editar ticket con id: 
            {{$ticket->id}}
            <a href="{{ route('ticket.index') }}" class="btn btn-default pull-right"> Listado de Tickets </a>
        </h1>

        @include('tickets.fragment.error')
        {!! Form::model($ticket, ['route' => ['ticket.update', $ticket->id], 'method' => 'PUT']) !!}
            @include('tickets.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection