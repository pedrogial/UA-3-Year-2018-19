@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Registrar Evento
            
            <a href="{{ route('evento.index') }}" class="btn btn-default pull-right"> Listado de Evento </a>
        </h1>
        @include('eventos.fragment.info')
        @include('eventos.fragment.error')
        {!! Form::open(['route' => 'evento.store']) !!}
            @include('eventos.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection