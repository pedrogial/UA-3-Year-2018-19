@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Editar Evento
            <a href="{{ route('evento.index') }}" class="btn btn-default pull-right"> Listado de Eventos </a>
        </h1>
        @include('eventos.fragment.info')
        @include('eventos.fragment.error')
        {!! Form::model($evento, ['route' => ['evento.update', $evento->id], 'method' => 'PUT']) !!}
            @include('eventos.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection