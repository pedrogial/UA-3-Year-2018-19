<div class="form-group">
    {!!  Form::label('nombre', 'Nombre del evento')  !!}
    {!!  Form::text('nombre', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('descripcion', 'Descripcion')  !!}
    {!!  Form::textarea('descripcion', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('precio', 'Precio')  !!}
    {!!  Form::number('precio', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('fechaEvento', 'Fecha del Evento')  !!}
    {!!  Form::date('fechaEvento', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('categoria_id', 'Categoria')  !!}
    {!!  Form::select('categoria_id', $categoria, null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('lugar_id', 'Lugar')  !!}
    {!!  Form::select('lugar_id', $lugar, null, ['class' => 'form-control'])  !!}
</div>
<!-- 
<div class="form-group">
 <label for="image">Chose the picture</label>
 <input type="file" class="form-control" name="image" id="image">
</div>
-->
<div class="form-group">
    {!!  Form::label('imagen', 'Imagen')  !!}
    {!!  Form::file('imagen', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::submit('Enviar', ['class' => 'btn btn-primary'])  !!}
</div>
