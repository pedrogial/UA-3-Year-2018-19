@extends('layout')
@section('content')
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
            <img class="No funciona la imagen" src="{{ asset($evento->imagen) }}" />
            </div>
            <div class="col-md-6">
                <div class="row">
                    <div class="col-md-12 mt-5">
                        <h1 class = "font-weight-bold" >{{$evento->nombre}} </h1>
                    </div>
                    <div class="col-md-12 mt-3">
                        <h5>{{$evento->descripcion}} </h5>
                        <br />
                    </div>
                    
                    <div class="col-md-6 bottom-rule ">
                        <h2 class="product-price"> Precio: {{$evento->precio}} €</h2>
                    </div>                          
                    <div class="col-md-12 ">
                        <h2>Categoria: {{$evento->categoria->nombre}} </h2>
                    </div>
                    <div class="col-md-12 ">
                        <h2>Lugar: {{$evento->lugar->nombre}} </h2>
                    </div>
                </div>
            </div>
        </div><!-- end row -->

    </div>  
@endsection
