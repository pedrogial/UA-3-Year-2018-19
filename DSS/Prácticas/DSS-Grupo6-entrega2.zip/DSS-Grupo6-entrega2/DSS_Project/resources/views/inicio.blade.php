@extends('layout')
@section('content')
<div class="container">
<h1 class="my-5">BienVenido a YourBestTicket.com</h1>
<h1 class="my-5">Eventos Destacados</h1>
<p></p>
<!-- Tarjetas -->
<div class="row">
    @foreach ($evento as $e)
    <div class="col-lg-4 mb-4">
        <div class="card h-100">    
            <h4 class="card-header">{{$e->nombre}}</h4>

            <a href="{{ route('evento.show', $e->id) }}"> <img class="card-img-top" src="{{ asset($e->imagen) }}" /></a>
            <div class="card-body">
                <p class="card-text">{{$e->descripcion}}</p>
            </div>
            <div class="card-footer">
                <tr> 
                    <td>
                       <!-- <a href="{{ route('evento.show', $e->id) }}" class="btn btn-primary"> Comprar ticket</a>-->
                    </td>
                    <td>
                      <!-- <a href="{{ route('evento.edit', $e->id) }}" class="btn btn-primary"> Editar </a>-->
                    </td>
                    <td>
                        <p></p>
                        <form action="{{ route('evento.destroy',$e->id)}}" method="POST">
                            <a href="{{ route('evento.show', $e->id) }}" class="btn btn-primary"> Comprar ticket</a>
                        </form>
                    </td>
                </tr>
            </div>
        </div>
    </div>
    @endforeach
    <!-- Las dobles llaves son para que la vista reconozca lo de dentro como una función de laravel -->
</div>
{!! $evento->render() !!}
</div>  
@endsection