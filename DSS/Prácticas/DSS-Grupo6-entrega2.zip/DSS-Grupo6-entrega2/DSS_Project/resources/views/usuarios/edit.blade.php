@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Editar Usuario
            <a href="{{ route('usuario.index') }}" class="btn btn-default pull-right"> Listado de Usuarios </a>
        </h1>

        @include('usuarios.fragment.error')

        {!! Form::model($usuario, ['route' => ['usuario.update', $usuario->id], 'method' => 'PUT']) !!}
            @include('usuarios.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection