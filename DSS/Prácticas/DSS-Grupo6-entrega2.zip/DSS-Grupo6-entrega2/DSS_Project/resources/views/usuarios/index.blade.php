@extends('layout')
@section('content')
    <div class="col-sm-12">
        <h2 class="mt-5 mb-5">
            Listado de Usuarios 
            <a href="{{route('usuario.create')}}" class="ml-5 btn btn-primary"> Nuevo </a>
            
            <div class = row>
                <div class="col-sm-6">
                    <br/>
                    <h3> <b>Ordenar </b></h3>
                    <form action="/filter" method="get">
                        <h5> <input type="radio" name="gender" value="1"> Nombre</h5>
                        <h5> <input type="radio" name="gender" value="2"> Fecha de nacimiento</h5>
                        <h5> <input type="radio" name="gender" value="3"> Email</h5>
                        <br/>
                        <button type="submit" class="btn btn-primary"> Buscar </button>
                    </form>
                </div>
            
            <div class="col-sm-6">
                <form action="/search" method="get">
                    <div class="form-group">
                        <br/>
                        <h4>Nombre</h4>
                        <input type="text" name="nombre" class="form-control">
                        <h4>Fecha de nacimiento</h4>
                        <input type=date  name="fechaNacimiento" class="form-control">
                        <span class="form-group-btn">
                        <br/>
                        <button type="submit" class="btn btn-primary"> Buscar </button>
                    </div>
                </form >
            </div>
            </div>
        </h2> 
        @include('usuarios.fragment.info')
        
        <table class= " table table-hover table-striped">
            <thead>
                <tr> 
                    <th  >Nombre</th>
                    <th  >Email</th>
                    <th  >Telefono</th>
                    <th  >Dirección</th>
                    <th  >Fecha de Nacimiento</th>
                    <th colspan="3">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                @foreach($user as $u)
                <tr> 
                    <td>{{$u->nombre}}</td>
                    <td>{{$u->email}}</td>
                    <td>{{$u->telefono}}</td>
                    <td>{{$u->direccion}}</td>
                    <td>{{date("d-m-Y", strtotime($u->fechaNacimiento)) }}</th>
                    <td>
                        <a href="{{ route('usuario.show', $u->id) }}"> ver </a>
                    </td>
                    <td>
                        <a href="{{ route('usuario.edit', $u->id) }}"> editar </a>
                    </td>
                    <td>
                        <form action="{{ route('usuario.destroy',$u->id)}}" method="POST">
                                {{csrf_field()}}
                                <input type="hidden" name="_method" value="DELETE">
                                <button class="btn btn-link">Borrar</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {!!$user->appends(request()->input())->links(); !!}
    </div>
@endsection