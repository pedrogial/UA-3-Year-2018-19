@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Registrar Usuario
            
            <a href="{{ route('usuario.index') }}" class="btn btn-default pull-right"> Listado de Usuarios </a>
        </h1>
        @include('usuarios.fragment.info')
        @include('usuarios.fragment.error')
        {!! Form::open(['route' => 'usuario.store']) !!}
            @include('usuarios.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection