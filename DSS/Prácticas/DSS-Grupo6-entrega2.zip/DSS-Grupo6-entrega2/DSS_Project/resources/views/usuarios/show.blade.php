@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            {{$usuario->nombre}} 
            <a href="{{ route('usuario.edit', $usuario->id) }}" class="btn btn-default pull-right"> editar </a>
        </h1>

        <p> Direccion: {{ $usuario->direccion }} </p>
        <p> Telefono: {{ $usuario->telefono }} </p>
        <p> Email: {{ $usuario->email }} </p>   
        
        <p> Fecha de nacimiento: {{ date("d-m-Y", strtotime($usuario->fechaNacimiento))  }} </p>
    </div>
@endsection