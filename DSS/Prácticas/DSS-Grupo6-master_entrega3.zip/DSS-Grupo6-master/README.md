<p># DSS-Grupo6</p>
<p><span style="text-decoration: underline;"><span style="font-size: 13pt;"><strong>PASOS QUE SIEMPRE SE HACEN:</strong></span></span></p>
<ul>
<li><strong>Descargar archivos borrados:</strong>
<ul>
<li>composer update --no-scripts</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Crear Base de Datos:</strong>
<ul>
<li>touch database/database.sqlite</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Instalar las migraciones</strong>
<ul>
<li>php artisan migrate:install</li>
</ul>
</li>
</ul>
<p><br /><span style="text-decoration: underline;"><strong><span style="font-size: 12pt;">EJECUCIONES:</span></strong></span></p>
<ul>
<li><strong>Laravel y comprobar que funciona:</strong>
<ul>
<li>php artisan serve</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Tests:</strong>
<ul>
<li>vendor/bin/phpunit</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Programa Base de Datos:</strong>
<ul>
<li>sqlitebrowser database/database.sqlite</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Tinker:</strong>
<ul>
<li>php artisan tinker</li>
</ul>
</li>
</ul>
<p><br /><span style="text-decoration: underline;"><span style="font-size: 12pt;"><strong>MIGRACIONES:</strong></span></span></p>
<ul>
<li><strong>Crear fichero:</strong>
<ul>
<li>php artisan make:migration create_products_table --create=products</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Ejecutar las &uacute;ltimas migraciones:</strong>
<ul>
<li>php artisan migrate</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Deshacer todas las migraciones y volver a lanzarlas:</strong>
<ul>
<li>php artisan migrate:refresh --seed (--seed para ejecutar los seeders)</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Comprobar el estado:</strong>
<ul>
<li>php artisan migrate:status</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Eliminar:</strong>
<ul>
<li>Elminar el archivo y luego "composer dump-autoload"</li>
</ul>
</li>
</ul>
<p><br /><span style="text-decoration: underline;"><strong><span style="font-size: 12pt;">SEEDERS:</span></strong></span></p>
<ul>
<li><strong>Crear fichero:</strong>
<ul>
<li>php artisan make:seeder UsersTableSeeder</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Insertar las semillas:</strong>
<ul>
<li>php artisan db:seed</li>
</ul>
</li>
</ul>
<p><br /><span style="text-decoration: underline;"><span style="font-size: 12pt;"><strong>MODELOS:</strong></span></span></p>
<ul>
<li><strong>Crear fichero:</strong>
<ul>
<li>php artisan make:model Product</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Crear fichero junto a una migraci&oacute;n:</strong>
<ul>
<li>php artisan make:model Product -m</li>
</ul>
</li>
</ul>
<p><br /><span style="text-decoration: underline;"><strong><span style="font-size: 12pt;">TESTS:</span></strong></span></p>
<ul>
<li><strong>Crea un test en la carpeta Unit:</strong>
<ul>
<li>php artisan make:test UserTest --unit</li>
</ul>
</li>
</ul>
<p>&nbsp;</p>
<p><span style="text-decoration: underline;"><strong><span style="font-size: 12pt;">RUTAS:</span></strong></span></p>
<ul>
<li><strong>Ejemplo de ruta para peticiones tipo GET a la URL ra&iacute;z de nuestra aplicaci&oacute;n web:</strong>
<ul>
<li>Route::get('/', function() {<br />return '&iexcl;Hola mundo!';<br />});</li>
</ul>
</li>
</ul>
<ul>
<li><strong>Ejemplo de respuesta a peticiones tipo POST para la ruta &ldquo;foo/bar&rdquo;:</strong>
<ul>
<li>Route::post('foo/bar', function() {<br />return '&iexcl;Hola mundo!';<br />});</li>
</ul>
</li>
</ul>
<p><br /><span style="text-decoration: underline;"><strong><span style="font-size: 12pt;">VISTAS:</span></strong></span></p>
<ul>
<li><strong>Ejemplo de vista:</strong>
<ul>
<li>&lt;html&gt;<br />&lt;head&gt;<br />&lt;title&gt;Mi Web&lt;/title&gt;<br />&lt;/head&gt;<br />&lt;body&gt;<br />&lt;h1&gt;&iexcl;Hola &lt;?php echo $name; ?&gt;!&lt;/h1&gt;<br />&lt;/body&gt;<br />&lt;/html&gt;&nbsp;</li>
</ul>
</li>
</ul>
<ul>
<li style="list-style-type: none;">
<ul>
<li>Route::get('/', function() {<br />return view('home', array('name' =&gt; 'Javi'));<br />});</li>
</ul>
</li>
</ul>
