@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Registrar Lugar
            <a href="{{ route('lugar.index') }}" class="btn btn-default pull-right"> Listado de Usuarios </a>
        </h1>

        @include('lugares.fragment.error')
        {!! Form::open(['route' => 'lugar.store']) !!}
            @include('lugares.fragment.form')
        {!! Form::close() !!}
    </div>
@endsection