<div class="form-group">
    {!!  Form::label('nombre', 'Nombre del lugar')  !!}
    {!!  Form::text('nombre', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('telefono', 'Telefono')  !!}
    {!!  Form::number('telefono', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('direccion', 'Direccion')  !!}
    {!!  Form::text('direccion', null, ['class' => 'form-control'])  !!}
</div>
 
<div class="form-group">
    {!!  Form::submit('Enviar', ['class' => 'btn btn-primary'])  !!}
</div>
