@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            {{$lugar->nombre}} 
            <a href="{{ route('lugar.edit', $lugar->id) }}" class="btn btn-default pull-right"> editar </a>
        </h1>
        <p> Telefono: {{ $lugar->telefono }} </p>
        <p> Dirección: {{ $lugar->direccion }} </p>
        <p> Numero de Asientos: {{ $asientos }} </p>
    </div>
@endsection