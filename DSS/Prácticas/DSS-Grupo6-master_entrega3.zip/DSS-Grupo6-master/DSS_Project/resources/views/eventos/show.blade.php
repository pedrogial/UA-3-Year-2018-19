@extends('layout')
@section('content')
    <div class="container mt-5">
        <div class="row">
            <div class="col-md-6">
            <div class="left-column">
            <img width="400" height="400" src="{{ asset($evento->imagen) }}" />
            </div>
            
            </div>
            <div class="col-md-6">
                
                    <div class=" row mt-5">
                        <h1 class = "font-weight-bold" >{{$evento->nombre}} </h1>
                    </div>
                    <hr>
                    <div class="row mt-3 mb-3">
                        <h5>{{$evento->descripcion}} </h5>
                        
                    </div>
                    <hr>
                    <div class="row bottom-rule ">
                        <h4 class="product-price"> Precio: {{$evento->precio}} €</h4>
                    </div>                          
                    <div class="row ">
                        <h4>Categoria: {{$evento->categoria->nombre}} </h4>
                    </div>
                    <div class="row ">
                        <h4>Lugar: {{$evento->lugar->nombre}} </h4>
                    </div>
                    <div class="row justify-content-center mt-5">    
                         <a class="btn btn-secondary btn-lg" href="{{ route('factura.crear', ['id'=>$evento->id]) }}"> Comprar Tickets</a>
                    </div>                   
                
            </div>
        </div><!-- end row -->

    </div>  
@endsection
