@extends('layout')
@section('content')
<link href='https://fonts.googleapis.com/css?family=Vollkorn:400,400italic' rel='stylesheet' type='text/css'>
        <link href='https://fonts.googleapis.com/css?family=Droid+Serif:400,400italic,700,700italic' rel='stylesheet' type='text/css'>

 <link rel="stylesheet" href="/css/prueba.css">
    <div class="container">

        <h1 class="my-5">Nuestros Eventos</h1>

        <!-- Tarjetas -->
        @include('lugares.fragment.info')
        @include('lugares.fragment.error')
        <div class="row">
            @foreach ($evento as $e)
            <div class="col-lg-4 mb-4">
                <div class="card h-100">    
                    <h4 class="card-header">{{$e->nombre}}</h4>

                    <a href="{{ route('evento.show', $e->id) }}"> <img class="card-img-top" src="{{ asset($e->imagen) }}" /></a>
                    <div class="card-body">
                    <span class="card-text">{{$e->descripcion}}</span>
                    </div>
                    <div class="card-footer">
                        <tr> 
                            <td>
                               <!-- <a href="{{ route('evento.show', $e->id) }}" class="btn btn-primary"> Comprar ticket</a>-->
                            </td>
                            <td>
                              <!-- <a href="{{ route('evento.edit', $e->id) }}" class="btn btn-primary"> Editar </a>-->
                            </td>
                            <td>
                                <p></p>
                                <a href="{{ route('factura.crear', ['id'=>$e->id]) }}" class="btn btn-primary"> Comprar ticket</a>
                            </td>
                        </tr>
                    </div>
                </div>
            </div>
            @endforeach
            <!-- Las dobles llaves son para que la vista reconozca lo de dentro como una función de laravel -->
        </div>
        {!! $evento->render() !!}
    </div>  
@endsection