<!doctype html>
    <html>
    <head>
        <meta charset="utf-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
        

       <!-- <link rel="stylesheet" href="/css/main.css">-->
    </head>

    <body id="container">
        <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
            
            <a class="navbar-brand" href="/">YourBestTicket</a>
            <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">                
                @if (Auth::check())
                @if (Auth::user()->esAdmin==1)
                <li class="nav-item active">                   
                    <a class="nav-link" href="/evento">Gestionar Eventos <span class="sr-only">(current)</span></a>                     
                </li>
                <li class="nav-item active">                   
                    <a class="nav-link" href="{{ route('factura.index') }}">Facturas <span class="sr-only">(current)</span></a>                     
                </li>
                <li class="nav-item active">                    
                    <a class="nav-link" href="/usuario">Usuarios <span class="sr-only">(current)</span></a>                    
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/lugar">Lugares <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/categoria">Categorias <span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/ticket">Tickets <span class="sr-only">(current)</span></a>
                </li>
                @else
                </li>
                <li class="nav-item active">        
                    <a class="nav-link" href="{{ route('evento.indexUser') }}">Eventos <span class="sr-only">(current)</span></a>                     
                </li>
                <li class="nav-item active">                   
                    <a class="nav-link" href="{{ route('mifactura.index') }}">Mis Facturas <span class="sr-only">(current)</span></a>                     
                </li>
                <li class="nav-item active">                    
                    <a class="nav-link" href="{{ route('miusuario.index') }}">Mi perfil <span class="sr-only">(current)</span></a>                    
                </li>
                <li class="nav-item active">                   
                    <a class="nav-link" href="{{ route('contacto.index') }}">Contactanos <span class="sr-only">(current)</span></a>                     
                </li>
                <li class="nav-item active">                   
                    <a class="nav-link" href="{{ route('info') }}">Información <span class="sr-only">(current)</span></a>                     
                </li>
                @endif 
                @else 
                </li>
                <li class="nav-item active">        
                    <a class="nav-link pull-right" href="{{ route('evento.indexUser') }}">Eventos <span class="sr-only">(current)</span></a>                     
                </li>
                                <li class="nav-item active">                   
                    <a class="nav-link" href="{{ route('contacto.index') }}">Contactanos <span class="sr-only">(current)</span></a>                     
                </li>
                <li class="nav-item active">                   
                    <a class="nav-link" href="{{ route('info') }}">Información <span class="sr-only">(current)</span></a>                     
                </li>
                @endif
                <!-- Código para hacer bien la página de contacto
                https://elcodigo.xyz/crear-una-pagina-de-contacto-en-laravel-5-7/v-->
                </ul>  
                @if (Auth::check())
                @if (Auth::user()->esAdmin==0)
                    <a class="btn btn-secondary pull-right mr-3" href="{{ route('factura.intermediario') }}">Mi Compra<span class="sr-only">(current)</span> </a>              
                @endif
                @endif  
                @if (Auth::check()==false)            
                <a href="{{ route('login') }}" class="btn btn-secondary pull-right"> Sign in </a>
                <a href="{{ route('register') }}" class="btn btn-secondary pull-right"> Register </a> 
                @else
                
                    <a class="btn btn-secondary pull-right" href="{{ route('logout') }}"
                        onclick="event.preventDefault();
                                        document.getElementById('logout-form').submit();">
                        {{ __('Logout') }}
                    </a>
                    <form id="logout-form" action="{{ route('logout') }}" method="POST" style="display: none;">
                        @csrf
                    </form>
                @endif            
                <!--
                <form class="form-inline my-2 my-lg-0">
                    <input class="form-control mr-sm-2" type="search" placeholder="Search" aria-label="Search">
                    <button class="btn btn-outline-success my-2 my-sm-0" type="submit">Search</button>
                </form>
                -->
            </div>
        </nav>
        <header class="row">
        </header>
        <!--<div class="page-wrap">-->
        <div style="height: 1100px">
        <main role="main" class="container ">
            @yield('content')
        </main>
        <!--</div>-->
        </div>
        <br>
        <footer class="site-footer  bg-dark " >
            <div class="footer-copyright text-center py-3 container" >
                <p></p>
                <a class= "text-white">Copyright &copy; Your Best Ticket 2019 </a>
                <p></p>
            </div>
        </footer>
    </body>

    </html>