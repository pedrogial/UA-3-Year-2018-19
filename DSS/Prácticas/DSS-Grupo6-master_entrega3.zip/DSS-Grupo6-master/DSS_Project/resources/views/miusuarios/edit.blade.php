@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            Mi Perfil
        </h1>

        @include('miusuarios.fragment.error')
        @include('miusuarios.fragment.info')

        {!! Form::model($usuario, ['route' => ['miusuario.update', $usuario->id], 'method' => 'PUT']) !!}
            @include('miusuarios.fragment.form')
            
        {!! Form::close() !!}
        <p></p>
         
        <form action="{{ route('miusuario.destroy',$usuario->id)}}" method="POST">
            {{csrf_field()}}
            <input type="hidden" name="_method" value="DELETE">
            Si quieres borrar tu cuenta pulsa <button class="btn btn-primary">Aqui</button>
        </form>
    </div>
@endsection

