<div class="form-group">
    {!!  Form::label('nombre', 'Nombre de usuario')  !!}
    {!!  Form::text('nombre', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('email', 'Email')  !!}
    {!!  Form::email('email', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('telefono', 'Telefono')  !!}
    {!!  Form::number('telefono', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('direccion', 'Direccion')  !!}
    {!!  Form::text('direccion', null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('fechaNacimiento', 'Fecha de Nacimiento')  !!}
    {!!  Form::date('fechaNacimiento', null, ['class' => 'form-control'])  !!}
</div>
<div cla
ss="form-group">
    {!!  Form::submit('Cambiar', ['class' => 'btn btn-primary'])  !!}
</div>
