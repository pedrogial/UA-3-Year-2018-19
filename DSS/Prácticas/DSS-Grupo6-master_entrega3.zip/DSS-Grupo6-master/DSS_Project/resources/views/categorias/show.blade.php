@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
        <h1 class = "font-weight-bold" >
            {{$categoria->nombre}} 
            <a href="{{ route('categoria.edit', $categoria->id) }}" class="btn btn-default pull-right"> editar </a>
        </h1>
    </div>
@endsection