@extends('layout')
@section('content')
    <div class="col-sm-12">
        <h2 class="mt-5 mb-5">
            Listado de Categorias
            <a href="{{route('categoria.create')}}" class="btn btn-primary"> Nuevo </a>
        </h2> 
        @include('categorias.fragment.info')
        @include('categorias.fragment.error')
        <table class= " table table-hover table-striped">
            <thead>
                <tr> 
                    <th>Nombre</th>
                    <th colspan="3">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                @foreach($categoria as $c)
                <tr> 
                    <td>{{$c->nombre}}</td>
                    <td>
                        <a class="btn btn-link" href="{{ route('categoria.show', $c->id) }}"> Ver </a>
                    </td>
                    <td>
                        <a class="btn btn-link" href="{{ route('categoria.edit', $c->id) }}"> Editar </a>
                    </td>
                    <td>
                        <form action="{{ route('categoria.destroy',$c->id)}}" method="POST">
                            {{csrf_field()}}
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-link">Borrar</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {!! $categoria->render() !!}
    </div>
@endsection