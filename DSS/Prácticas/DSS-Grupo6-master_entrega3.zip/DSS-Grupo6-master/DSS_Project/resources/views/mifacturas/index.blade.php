@extends('layout')
@section('content')
    <div class="col-sm-12">
        <h1 class="font-weight-bold mt-5 mb-5 " >
            Mis Facturas            
        </h1>
        <table class= " table table-hover table-striped">
            <thead>
                <tr> 
                    <th  >Id</th>
                    <th  >cantTickets</th>
                    <th  >precioTotal</th>
                    <th  >Usuario</th>                    
                    <th  >Fecha de factura</th>
                    <th colspan="3">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                @foreach($factura as $f)
                <tr> 
                    <td>{{$f->id}}</td>
                    <td>{{$f->cantTickets}}</td>
                    <td>{{$f->precioTotal}}</td>
                    <td>{{$f->user->nombre}}</td>
                    <td>{{$f->fechaFactura}}</td>
                    <td>
                        <a class="btn btn-link" href="{{ route('mifactura.show', $f->id) }}"> Ver </a>
                    </td>
                    
                    <td>
                        <!--<a class="btn btn-link"href="{{ route('mifactura.borrar', $f->id) }}" > Borrar Factura </a> -->
                    </td>
                    
                </tr>
                @endforeach
            </tbody>
        </table>
        {!!$factura->appends(request()->input())->links(); !!}
    </div>
@endsection