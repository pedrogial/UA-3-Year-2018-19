@extends('layout')
@section('content')
    <div class="col-sm-12">
        <h1 class=" font-weight-bold mt-5 mb-5 "  >
            Mis Facturas            
        </h1>
        <br>
        <br>
        No se han generado facturas
    </div>
@endsection