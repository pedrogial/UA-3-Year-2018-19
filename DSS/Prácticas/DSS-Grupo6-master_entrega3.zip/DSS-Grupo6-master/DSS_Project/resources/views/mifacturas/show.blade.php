@extends('layout')
@section('content')
<div class="">
        <div class="">
            <div class="">
                  <h1 class=" font-weight-bold mt-5 mb-3" >Factura</h1>
            </div>
        </div>
        @include('mifacturas.fragment.info')
        @include('mifacturas.fragment.error')
        <div class="panel-body">
        <div class="row">
                <div class="col-sm-4">
                    <div class="form-group">
                        <b><label>Factura Nº</label></b>
                        <p>{{$factura->id}}</p>
                    </div>
                    <div class="form-group">
                    <b><label>Gran Total</label></b>
                        <p>${{$factura->precioTotal}}</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                    <b> <label>Cliente</label></b>
                        <p>{{$factura->user->nombre}}</p>
                    </div>
                    <div class="form-group">
                    <b><label>Dirección del cliente</label></b>
                        <p class="pre">{{$factura->user->direccion}}</p>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="row">
                        <div class="col-sm-6">
                        <b> <label>Fecha factura</label></b>
                            <p>{{$factura->fechaFactura}}</p>
                        </div>
                    </div>
                </div>
            </div>
            <hr>
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Nombre Evento</th>
                        <th>Precio</th>
                        <th>Lugar</th>
                        <th>Numero de asiento</th>
                        <th>Tipo de asiento</th>                        
                        <th>Precio Final</th>  
                    </tr>
                </thead>
                <tbody>
                    @foreach($factura->tickets as $t)
                        <tr>
                            <td class="table-name">{{$t->evento->nombre}}</td>
                            <td class="table-price">{{$t->evento->precio}}</td>                                                        
                            <td class="table-price">{{$t->evento->lugar->nombre}}</td> 
                            <td class="table-price">{{$t->numAsiento}}</td> 
                            <td class="table-price">{{$t->asiento()->tipo}}</td> 
                            <td class="table-price">{{$t->evento->precio*$t->asiento()->adaptacionPrecio}}</td> 
                        </tr>
                    @endforeach
                </tbody>
                <tfoot>
                    <tr>
                        <td class="table-empty" colspan="4"></td>
                        <td class="table-label">Total</td>
                        <td class="table-amount">${{$factura->precioTotal}}</td>
                    </tr>
                </tfoot>
            </table>
        </div>
</div>
@endsection