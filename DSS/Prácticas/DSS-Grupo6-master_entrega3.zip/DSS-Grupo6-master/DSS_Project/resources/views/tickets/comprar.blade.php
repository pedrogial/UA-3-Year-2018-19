@extends('layout')
@section('content')
    <div class="col-md-12 mt-5">
    <div class = row>            
        <div class="col-sm-6">
            <h1 class = "font-weight-bold" >
            <div> Comprar tickets</div>
                <a href="{{ route('ticket.index') }}" class="btn btn-default pull-right"></a>            
            </h1>
        </div>
        <div class="col-sm-6">

        </div>
    </div>
        <div class = row>            
            <div class="col-sm-6">
            <div class = row>   
                <div class="col-sm-3">
                <form action="/comprar/{{$idEvento}}/{{$idFactura}}" method="get">
                <select name="tipoAsiento">
                <option value="" selected disabled hidden>Elige el tipo </option>
                <option value="VIP">VIP </option>
                <option value="Normal">Normal</option>
                <option value="Gallinero">Gallinero </option>
                <option value="Todos">Todos</option>
                </select>         
                
                </div>
                <div class="col-sm-6">
                <input type="submit"class= "btn btn-secondary "value="Seleccionar" />
                </div>
                </form>
            </div>
            </div>
            <div class="col-sm-6">
                <p> <b>Nota: </b><br>
                <pre>    VIP:       Precio Base * 1,5 
    Normal:    Precio Base
    Gallinero: Precio Base * 0,8</pre></p>
            </div>
            
        </div>        
        <h4 class = "font-weight-bold"> Evento: {{App\Evento::find($idEvento)->nombre}}</h4>

        <table class= " table table-hover table-striped">
            <thead>
                <tr> 
                    <th  >Número de asiento</th>
                    <th  >Tipo</th>
                    <th  >Precio</th>
                    <th colspan="3">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                @foreach($asientosLibres as $a)
                <tr> 
                    <td>{{$a->id}}</td>
                    <td>{{$a->tipo}}</td>                    
                    <td>{{App\Evento::find($idEvento)->precio * $a->adaptacionPrecio}} </td>
                        
                    <td>
                        <a href="/añadir/{{$idEvento}}/{{$idFactura}}/{{$a->id}}"> Añadir Ticket </a>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        
        <a href="/carrito/{{$idFactura}}" class="btn  btn-secondary"> Pasar a Factura </a>
    </div>
@endsection