<div class="form-group">
    {!!  Form::label('user_id', 'Usuario')  !!}
    {!!  Form::select('user_id', $user, null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::label('evento_id', 'Evento')  !!}
    {!!  Form::select('evento_id', $evento, null, ['class' => 'form-control'])  !!}
</div>

<div class="form-group">
    {!!  Form::submit('Enviar', ['class' => 'btn btn-primary'])  !!}
</div>
