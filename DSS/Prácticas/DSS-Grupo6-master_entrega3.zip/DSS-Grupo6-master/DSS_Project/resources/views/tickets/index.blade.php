@extends('layout')
@section('content')
    <div class="col-sm-12">
        <h2 class="mt-5 mb-5">
            Listado de tickets            
        </h2> 
        @include('tickets.fragment.info')
        @include('tickets.fragment.error')
        <table class= " table table-hover table-striped">
            <thead>
                <tr> 
                    <th  >ID</th>
                    <th  >Usuario</th>
                    <th  >Evento</th>
                    <th colspan="3">&nbsp;</th>
                </tr>
            </thead>
            <tbody>
                @foreach($ticket as $t)
                <tr>                     
                    <td>{{$t->id}}</td>
                    <td>{{$t->factura->user->email}}</td>
                    <td>{{$t->evento->nombre}}</td>
                    <td>
                        <form action="{{ route('ticket.destroy',$t->id)}}" method="POST">
                            {{csrf_field()}}
                            <input type="hidden" name="_method" value="DELETE">
                            <button class="btn btn-link">Borrar</button>
                        </form>
                    </td>
                </tr>
                @endforeach
            </tbody>
        </table>
        {!! $ticket->render() !!}
    </div>
@endsection