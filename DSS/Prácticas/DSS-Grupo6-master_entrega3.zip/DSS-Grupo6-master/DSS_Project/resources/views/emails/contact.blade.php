<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Document</title>
</head>
<body>
	<p><strong>Nombre: </strong>{!!$nombre!!}</p>
	<p><strong>Correo: </strong>{!!$email!!}</p>
	<p><strong>Mensaje: </strong>{!!$mensaje!!}</p>
</body>
</html>