@extends('layout')

@section('content')
<p></p>
<link rel="stylesheet" href="/css/prueba.css">
<div class="jumbotron">
    <h1 class="display-4">Información</h1>
    <p class="lead">YourBestTicket.net</p>
    <hr class="my-4">

    <p>El objetivo de este proyecto es desarrollar una aplicación que permita a los 
        usuarios adquirir entradas y programar eventos dependiendo del tipo de usuario. 
        Los clientes serán capaces de filtrar sus eventos y elegir el que más se adecue a sus gustos, 
        mientras que los organizadores podrán publicar sus actividades y tener la información en todo momento de qué entradas se han reservado.
    </p>
    <p>Debido a las solicitudes de multitud de entidades organizadoras de eventos, 
        hemos decidido desarrollar una página web que almacene las especificaciones 
        necesarias para la reserva y consulta de eventos.</p>
    <p>Una vez los clientes reserven sus entradas, podrán comprobar en todo 
        momento el estado de sus eventos y en caso de que deseen cancelarlas 
        se tramitará un reembolso siempre y cuando se gestione antes de la fecha 
        acordada por el creador del evento.</p>
</div>
@endsection
