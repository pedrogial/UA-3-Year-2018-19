<?php
namespace App\ServiceLayer;
use App\Factura;
use App\Ticket;
use Illuminate\Support\Facades\DB;
class OrderServices {
    public static function processOrder($id) {
        $rollback = false;
        DB::beginTransaction();
        $tickets = Factura::find($id)->tickets;
        $asientosOcupados=array();
        $ticketsNoDisponibles = Ticket::all()->where('disponible', false);
        foreach($ticketsNoDisponibles as $t){            
            array_push($asientosOcupados,$t->numAsiento);
        }
        foreach($tickets as $t){
            if(!in_array($t->numAsiento, $asientosOcupados)){
                $t->disponible=false;
                $t->save();
            }else{
                $rollback=true;                              
            }            
        }
        $factura = Factura::find($id);
        $factura->terminada = true;       
        $factura->save();
        if ($rollback==true) {
            DB::rollBack();
            return null;
        }
        DB::commit();
        return $id;
    }
}