<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Lugar extends Model
{
    protected $fillable = [
        'id', 'nombre', 'telefono', 'direccion'
    ];

    public function eventos(){
        return $this->hasmany('App\Evento');
    }

    public function asientos(){
        return $this->hasmany('App\Asiento');
    }
}
