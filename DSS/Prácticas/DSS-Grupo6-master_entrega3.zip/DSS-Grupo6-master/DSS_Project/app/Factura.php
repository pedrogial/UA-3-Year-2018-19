<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Factura extends Model
{
    protected $fillable = [
        'id',
        'cantTickets',
        'precioTotal',
        'fechaFactura',
        'terminada',
        'user_id'
    ];
    
    
    public function user(){
        return $this->belongsTo('App\User');
    }

    public function tickets() {
        return $this->hasMany('App\Ticket');
    }
}