<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Asiento extends Model
{
    protected $fillable = [
        'id',
        'tipo',
        'adaptacionPrecio',        
    ];
    
    
    public function lugar(){
        return $this->belongsTo('App\Lugar');
    }
}