<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Asiento;

class Ticket extends Model
{
    protected $fillable = [
        'numAsiento',
        'disponible',
        'evento_id',
        'factura_id',
    ];
    
    public function factura() {
        return $this->belongsTo('App\Factura');
    }
    public function evento() {
        return $this->belongsTo('App\Evento');
    }
    public function asiento() {
        return Asiento::find($this->numAsiento);
    }

}
