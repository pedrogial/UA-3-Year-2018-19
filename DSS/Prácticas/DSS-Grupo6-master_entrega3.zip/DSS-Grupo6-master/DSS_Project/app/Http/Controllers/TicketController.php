<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Ticket;
use App\Evento;
use App\Factura;
use App\Categoria;
use App\Lugar;
use App\User;
use Illuminate\Support\Facades\Auth;

class TicketController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $ticket = Ticket::orderBy('id','ASC')->paginate(3);
        return view('tickets.index',compact('ticket'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create($id)
    {
        $user = User::pluck('email', 'id');
        $evento = Evento::pluck('nombre', 'id');
        return view('tickets.create', compact('evento', 'user'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $ticket = new Ticket;

        $ticket->user_id = $request->user_id;
        $ticket->evento_id = $request->evento_id;
        $ticket->factura_id = $request->factura_id;

        $ticket->save();
        return redirect()->route('ticket.index')->with('info','El ticket fue guardado');
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $ticket = Ticket::find($id);
        return view('tickets.show',compact('ticket'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $evento = Evento::pluck('nombre', 'id');
        $user = User::pluck('email', 'id');
        $ticket = Ticket::find($id);
        return view('tickets.edit', compact('ticket','evento','user')).$id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $ticket = Ticket::find($id);

        $ticket->user_id = $request->user_id;
        $ticket->evento_id = $request->evento_id;

        $ticket->save();
        return redirect()->route('ticket.index')->with('info','El ticket fue guardado');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $ticket = Ticket::find($id);
        $ticket->delete();
        return back()->with('info','El ticket fue eliminado');
    }

    public function comprar($idEvento,$idFactura,Request $request)
    {        
        $tickets = Ticket::all()->where('disponible', false);
        $asientosOcupados=array();
        $asientosSeleccionados=array();
        $asientosLibres=collect();
        foreach($tickets as $t){            
            array_push($asientosOcupados,$t->numAsiento);
        }        
        $idLugar=Evento::find($idEvento)->lugar_id;
        $misTickets=Factura::find($idFactura)->tickets;
        foreach($misTickets as $t){            
            array_push($asientosSeleccionados,$t->numAsiento);
        }
        if ($request->tipoAsiento && $request->tipoAsiento!="Todos") {
            $tipoAsiento = $request->tipoAsiento;
            $asientos = Lugar::find($idLugar)->asientos()->where([ ['tipo', '=', $tipoAsiento]])->paginate(100);  
            foreach($asientos as $a){
                if(!in_array($a->id, $asientosOcupados) && !in_array($a->id, $asientosSeleccionados)){
                    $asientosLibres->push($a);
                }                     
            }
            return view('tickets.comprar',compact('idEvento','idFactura','tipoAsiento','asientosLibres'));
        }else{     
            $tipoAsiento = "Todos";
            $asientos = Lugar::find($idLugar)->asientos()->paginate(100);  
            foreach($asientos as $a){
                if(!in_array($a->id, $asientosOcupados) && !in_array($a->id, $asientosSeleccionados)){
                    $asientosLibres->push($a);
                }                     
            }
            return view('tickets.comprar',compact('idEvento','idFactura','tipoAsiento','asientosLibres'));
        }
    }
    public function añadir($idEvento,$idFactura,$numAsiento)
    { 
        $ticket = new Ticket;
        
        $ticket->evento_id = $idEvento;
        $ticket->factura_id = $idFactura;
        $ticket->numAsiento = $numAsiento;
        $ticket->disponible = true;

        $ticket->save();
        return redirect()->route('ticket.comprar', ['idEvento'=>$idEvento ,'idFactura'=>$idFactura]); 
    }
}
