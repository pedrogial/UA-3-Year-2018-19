<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Factura;
use App\User;
use DateTime;

class MyFacturaController extends Controller
{
    public function index()
    {           
        $cantidad = Factura::where('user_id', Auth::user()->id)->orderBy('fechaFactura','ASC')->count();
        $factura = Factura::where([['user_id' , '=', Auth::user()->id],['terminada', '=', true]])->orderBy('fechaFactura','ASC')->paginate(3);
        $facturasNulas = Factura::where([['user_id' , '=', Auth::user()->id],['terminada', '=', true]])->orderBy('fechaFactura','ASC')->count();
        if($cantidad == 0 || $facturasNulas==0){
            return view('mifacturas.index2');
        }
        return view('mifacturas.index',compact('factura'));
    }
    public function borrar($id)
    {
        $factura = Factura::find($id);
        $factura->delete();
        return redirect()->route(mifactura.index);
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $factura = Factura::find($id);
        return view('mifacturas.show',compact('factura'));
    }
}
