<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Lugar;
use App\Evento;
use App\Http\Requests\LugarRequest;
use App\Asiento;

class LugarController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $lugar = Lugar::orderBy('nombre','ASC')->paginate(3);
        return view('lugares.index',compact('lugar'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('lugares.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(LugarRequest $request)
    {
        $lugar = new Lugar;
        $count =Lugar::where('nombre',$request->nombre)->count();
        $vip = $request->vip;
        $normal = $request->normal;
        $gallinero = $request->gallinero;
        
        $request->validate([
            'vip' => 'required',
            'normal' => 'required',
            'gallinero'=>'required'
        ]);

        if($count<=0){
            $lugar->nombre = $request->nombre;
            $lugar->direccion = $request->direccion;
            $lugar->telefono = $request->telefono;
            $lugar->save();
            While($vip != 0){
                $lugar->asientos()->saveMany([
                    $asiento = new Asiento(['tipo' => 'VIP',
                                    'adaptacionPrecio' => 1.50])
                ]);
                $vip--;
            }
            While($normal != 0){
                $lugar->asientos()->saveMany([
                    $asiento = new Asiento(['tipo' => 'Normal',
                                    'adaptacionPrecio' => 1.00])
                ]);
                $normal--;
            }
            While($gallinero != 0){
                $lugar->asientos()->saveMany([
                    $asiento = new Asiento(['tipo' => 'Gallinero',
                                    'adaptacionPrecio' => 0.80])
                ]);
                $gallinero--;
            }

            return redirect()->route('lugar.index')->with('info','El lugar fue creado');
        }else{
            return redirect()->route('lugar.index')->withErrors('El nombre del lugar ya existe');
        } 
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $lugar = Lugar::find($id);
        $asientos = Asiento::where('lugar_id', $id)->count();
        return view('lugares.show', compact('lugar', 'asientos'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $lugar = Lugar::find($id);
        return view('lugares.edit', compact('lugar')).$id;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(LugarRequest $request, $id)
    {
        $lugar = Lugar::find($id);
        $count =Lugar::where('nombre',$request->nombre)->count();
        if($count<=0 || $lugar->nombre == $request->nombre){
            $lugar->nombre = $request->nombre;
            $lugar->direccion = $request->direccion;
            $lugar->telefono = $request->telefono;
            $lugar->save();
            return redirect()->route('lugar.index')->with('info','El lugar fue actualizado');
        }else{
            return redirect()->route('lugar.index')->withErrors('El nombre del lugar ya existe');
        }
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $lugar = Lugar::find($id);
        $count =Evento::where('lugar_id',$id)->count();
        if($count>0){
            return back()->withErrors('El lugar no fue eliminado debido a que existen eventos asociados');
        }else{
            $lugar->delete();
            return back()->with('info','El lugar fue eliminado');
        }
    }
}
