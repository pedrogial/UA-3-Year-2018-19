<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Factura;
use DateTime;
use Auth;
use App\User;
use App\ServiceLayer\OrderServices;

class FacturaController extends Controller
{
    public function index()
    {
        $factura = Factura::where([['terminada', '=', true]])->orderBy('fechaFactura','ASC')->paginate(3);
        return view('facturas.index',compact('factura'));
    }
    
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $factura = Factura::find($id);
        $factura->delete();
    }
    public function borrar($id)
    {
        $factura = Factura::find($id);
        $factura->delete();
        return redirect()->route('evento.indexUser');
    }
    public function show($id)
    {
        $factura = Factura::find($id);
        return view('facturas.show',compact('factura'));
    }

    public function crear($id)
    {
        $pollas = User::find(Auth::user()->id)->facturas()->where( 'terminada', false)->count();
        if($pollas>0){
//
        }else{
            $factura = new Factura();
            $factura->cantTickets=0;
            $factura->precioTotal=0;
            $factura->fechaFactura=date('Y-m-d H:i:s');
            $factura->terminada=false;
            $factura->user_id = Auth::user()->id;
            $factura->save(); 
        }  
        $factura=User::find(Auth::user()->id)->facturas()->where('terminada', false)->first();
        return redirect()->route('ticket.comprar', ['idEvento'=>$id ,'idFactura'=>$factura->id]);       
        
    }
    public function intermediario(){
        $pollas = User::find(Auth::user()->id)->facturas()->where( 'terminada', false)->count();
        if($pollas>0){
//
        }else{
            $factura = new Factura();
            $factura->cantTickets=0;
            $factura->precioTotal=0;
            $factura->fechaFactura=date('Y-m-d H:i:s');
            $factura->terminada=false;
            $factura->user_id = Auth::user()->id;
            $factura->save(); 
        }  
        //ESTO NO LO VAIS A VOLVER A VER EN LA VIDA XAVALES
        $factura=User::find(Auth::user()->id)->facturas()->where('terminada', false)->first();
        return redirect()->route('factura.carrito',['factura'=>$factura->id]); 
    }
    public function carrito($id)
    {

        $factura = Factura::find($id);
        $tickets=Factura::find($id)->tickets;
        $precio=0;
        foreach($tickets as $t){
            $precio = $precio + $t->evento->precio * $t->asiento()->adaptacionPrecio;
        }
        $factura->cantTickets= $factura->tickets()->count();
        $factura->precioTotal= $precio; 
        $factura->save();
        return view('facturas.carrito',compact('factura'));
    }
    public function finalizar($id)
    {
        $factura = Factura::find($id);
        if($factura->cantTickets>0){
            if (OrderServices::processOrder($id)==null){  
                //asi es como se borra MADAFAKAS
                $ticketsNoDisponibles = $factura->tickets()->where('disponible', false)->delete();
                return redirect()->route('factura.carrito',['factura'=>$factura])->withErrors('La factura no fue almacenada debido a que alguno de sus tickets ya no está disponible');
            }else{    
                $factura1 = new Factura();
                $factura1->cantTickets=0;
                $factura1->precioTotal=0;
                $factura1->fechaFactura=date('Y-m-d H:i:s');
                $factura1->terminada=false;
                $factura1->user_id = Auth::user()->id;
                $factura1->save();        
                return redirect()->route('mifactura.show',['factura'=>$factura])->with('info','La factura fue almacenada');
            }
        }else{
            return redirect()->route('evento.indexUser');
        }
    }

}
