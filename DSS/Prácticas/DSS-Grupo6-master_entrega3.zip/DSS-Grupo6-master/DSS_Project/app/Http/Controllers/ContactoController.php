<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use Illuminate\Support\Facades\Session;
use Illuminate\Support\Facades\Redirect;


class ContactoController extends Controller
{
    public function index(){
        return view('contacto');
    }

    public function store(Request $request){
        
        $request->validate([
            'nombre' => 'required|string|max:255',
            'email' => 'required|string|email|max:255',
            'mensaje'=>'required|string|min:20'
        ]);

        $forminput = [
            'nombre' => $request->input('nombre'),
            'email' => $request->input('email'),
            'mensaje' => $request->input('mensaje')
        ];

        Mail::send('emails.contact', $forminput, function($msj){
            $msj->subject('Correo de Contacto');
            $msj->to('ybticket@gmail.com');
        });

        return redirect('contacto')->with('estado', '¡Mensaje enviado! Gracias por contactarnos.');
    }
}
