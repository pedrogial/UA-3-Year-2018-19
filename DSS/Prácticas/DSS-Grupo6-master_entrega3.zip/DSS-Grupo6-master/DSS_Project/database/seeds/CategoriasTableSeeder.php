<?php

use Illuminate\Database\Seeder;
use App\Categoria;
class CategoriasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Categoria::truncate();

        $s = new Categoria(['nombre' => 'Musical']);
        $s->save(); 

        $s = new Categoria(['nombre' => 'Teatro']);
        $s->save(); 

        $s = new Categoria(['nombre' => 'Feria']);
        $s->save();

        $s = new Categoria(['nombre' => 'Danza']);
        $s->save();

        $s = new Categoria(['nombre' => 'Opera']);
        $s->save();
    }
}
