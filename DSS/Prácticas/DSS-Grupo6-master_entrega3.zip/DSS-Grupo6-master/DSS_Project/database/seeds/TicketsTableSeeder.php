<?php

use Illuminate\Database\Seeder;
use App\Evento;
use App\Ticket;
use App\Factura;

class TicketsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Ticket::truncate();

        $u0 = Factura::where('id','1')->first();
        $u1 = Factura::where('id','2')->first();
        $u2 = Factura::where('id','3')->first();
        $u3 = Factura::where('id','4')->first();
        
        $u0->tickets()->saveMany([
            $s = new Ticket(['numAsiento' => 1,'disponible' => false]),
            $s = new Ticket(['numAsiento' => 2,'disponible' => false]),
        ]);

        $u1->tickets()->saveMany([
            
            $s = new Ticket(['numAsiento' => 10,'disponible' => false]),
            $s = new Ticket(['numAsiento' => 11,'disponible' => false])
        ]);

        $u2->tickets()->saveMany([
            $s = new Ticket(['numAsiento' => 19,'disponible' => false]),
            $s = new Ticket(['numAsiento' => 20,'disponible' => false])
        ]);

        $u3->tickets()->saveMany([
            $s = new Ticket(['numAsiento' => 28,'disponible' => false]),
            $s = new Ticket(['numAsiento' => 29,'disponible' => false])
        ]);

        $e0 = Evento::where('nombre','JURAWORLD')->first();
        $e1 = Evento::where('nombre','EXPONADAL')->first();
        $e2 = Evento::where('nombre','EXPOJOVE')->first();
        $e3 = Evento::where('nombre','FITUR')->first();

        $e0->tickets()->saveMany([
            Ticket::where('id',1)->first(),
            Ticket::where('id',2)->first()
        ]);

        $e1->tickets()->saveMany([
            Ticket::where('id',3)->first(),
            Ticket::where('id',4)->first()
        ]);

        $e2->tickets()->saveMany([
            Ticket::where('id',5)->first(),
            Ticket::where('id',6)->first(),            
        ]);
        $e3->tickets()->saveMany([
            Ticket::where('id',7)->first(),
            Ticket::where('id',8)->first(),            
        ]);

    }
}
