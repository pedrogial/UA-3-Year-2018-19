<?php

use Illuminate\Database\Seeder;
use App\Lugar;
class LugarsTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        Lugar::truncate();

        $s = new Lugar(['nombre' => 'IFEMA',
                        'telefono' => 674349932,
                        'direccion' => 'Partida Torrellano Alto, 03320 Torrellano, Alicante',]);
        $s->save(); 

        $s = new Lugar(['nombre' => 'FICOBA',
                        'telefono' => 639485867,
                        'direccion' => 'Avenida iparralde, 43, , Irún (España)',]);
        $s->save(); 

        $s = new Lugar(['nombre' => 'EXPOCoruña',
                        'telefono' => 634534243,
                        'direccion' => ' Juana Capdevielle, 2, , A Coruña (España)',]);
        $s->save(); 
        $s = new Lugar(['nombre' => 'IFEPA',
                        'telefono' => 692374959,
                        'direccion' => 'Avda. Gerardo Molina, 45 , , Torre Pacheco (España)',]);
        $s->save(); 
    }
}
