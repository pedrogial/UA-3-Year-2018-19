<?php

use Illuminate\Database\Seeder;
use App\Evento;
use App\Categoria;
use App\Lugar;

class EventosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {

        $img = '/images/evento.jpeg';
        $img1 = '/images/dino.jpeg';
        $img2 = '/images/jove.jpeg';
        $img3 = '/images/nadal.jpeg';
        $img4 = '/images/fitur.jpeg';

        Evento::truncate();

        $c0 = Categoria::where('nombre','Musical')->first();
        $c1 = Categoria::where('nombre','Feria')->first();
        $c2 = Categoria::where('nombre','Teatro')->first();

        $c2->eventos()->saveMany([
            new Evento(['nombre' => 'JURAWORLD',
                        'descripcion' => 'Viajar a Isla Nublar como huésped VIP y explorar el mundo Jurásico',
                        'imagen' => $img1,
                        'precio' => 10.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))])                    
        ]);
        $c1->eventos()->saveMany([
            new Evento(['nombre' => 'EXPONADAL',
                        'descripcion' => 'Ocio infantil y juvenil, atracciones feriales, manualidades y talleres de todo tipo',
                        'imagen' => $img3,
                        'precio' => 20.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))]), //Se puede hacer así tb
            new Evento(['nombre' => 'EXPOJOVE',
                        'descripcion' => 'Un lugar lleno de actividades, teatro, música y entretenimiento',
                        'imagen' => $img2,
                        'precio' => 30.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))])
        ]);
        
        $c0->eventos()->saveMany([
            new Evento(['nombre' => 'FITUR',
                        'descripcion' => 'Festival musical ecléctico y paritario',
                        'imagen' => $img4,
                        'precio' => 40.00,
                        'fechaEvento' => date('Y-m-d',strtotime('10/16/2003'))])
        ]);

        $l0 = Lugar::where('nombre','IFEMA')->first();
        $l1 = Lugar::where('nombre','FICOBA')->first();
        $l2 = Lugar::where('nombre','EXPOCoruña')->first();
        $l3 = Lugar::where('nombre','IFEPA')->first();
        
        $l0->eventos()->saveMany([
            Evento::where('id',1)->first(),            
        ]);

        $l1->eventos()->saveMany([
            Evento::where('id',2)->first(),
        ]);

        $l2->eventos()->saveMany([
            Evento::where('id',3)->first(),
        ]);
        $l3->eventos()->saveMany([
            Evento::where('id',4)->first(),
        ]);

    }
}
