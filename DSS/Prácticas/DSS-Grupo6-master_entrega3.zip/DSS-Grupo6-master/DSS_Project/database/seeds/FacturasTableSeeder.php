<?php

use Illuminate\Database\Seeder;
use App\Factura;
use App\User;

class FacturasTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Factura::truncate();
        $u0 = User::where('nombre','Rafa')->first();
        $u1 = User::where('nombre','Melanie')->first();
        $u2 = User::where('nombre','Pedro')->first();
        $u3 = User::where('nombre','Dani')->first();
        
        $u0->facturas()->saveMany([
            $s = new Factura(['cantTickets' => 2,
                            'precioTotal' => 25.00,
                            'fechaFactura' => date('Y-m-d H:i:s',strtotime('10/20/2003 23:04:52')),
                            'terminada' => true])
        ]);

        $u1->facturas()->saveMany([
            $s = new Factura(['cantTickets' => 2,
                            'precioTotal' => 46.00,
                            'fechaFactura' => date('Y-m-d H:i:s',strtotime('11/21/2003 23:04:52')),
                            'terminada' => true])
        ]);

        $u2->facturas()->saveMany([
            $s = new Factura(['cantTickets' => 2,
                            'precioTotal' => 54.00,
                            'fechaFactura' => date('Y-m-d H:i:s',strtotime('12/22/2003 23:04:52')),
                            'terminada' => true])
        ]);

        $u3->facturas()->saveMany([
            $s = new Factura(['cantTickets' => 2,
                            'precioTotal' => 100.00,
                            'fechaFactura' => date('Y-m-d H:i:s',strtotime('12/23/2003 23:04:52')),
                            'terminada' => true])
        ]);
    }
}
