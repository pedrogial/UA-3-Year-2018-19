<?php

use Illuminate\Database\Seeder;
use App\Asiento;
use App\Lugar;

class AsientosTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        Asiento::truncate();
        $u0 = Lugar::where('nombre','IFEMA')->first();        
        $u1 = Lugar::where('nombre','FICOBA')->first();
        $u2 = Lugar::where('nombre','EXPOCoruña')->first();
        $u3 = Lugar::where('nombre','IFEPA')->first();
        
        $u0->asientos()->saveMany([
            $s = new Asiento(['tipo' => 'VIP',
                            'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                            'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                            'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                            'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                            'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                            'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                            'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                            'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                            'adaptacionPrecio' => 0.80])
        ]);

        $u1->asientos()->saveMany([
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80])
        ]);

        $u2->asientos()->saveMany([
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80])
        ]);
        $u3->asientos()->saveMany([
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80]),
            $s = new Asiento(['tipo' => 'VIP',
                        'adaptacionPrecio' => 1.50]),
            $s = new Asiento(['tipo' => 'Normal',
                        'adaptacionPrecio' => 1.00]),
            $s = new Asiento(['tipo' => 'Gallinero',
                        'adaptacionPrecio' => 0.80])
        ]);
    }
}