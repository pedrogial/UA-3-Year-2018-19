<?php

use Illuminate\Database\Seeder;
use Illuminate\Foundation\Auth\User;
use Carbon\Carbon;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        User::truncate();

        $s = new User(['nombre' => 'Rafa',
                        'email' => 'rafatomassanjuan@gmail.com',
                        'password' => Hash::make('123456'),
                        'telefono' => 111111111,
                        'direccion' => 'Calle 1',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/16/2003')),
                        'esAdmin' => false]);
        $s->save();
        $s = new User(['nombre' => 'Rafa',
                        'email' => 'r3@rafa.com',
                        'password' => Hash::make('123456'),
                        'telefono' => 111111111,
                        'direccion' => 'Calle 1',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/16/2003')),
                        'esAdmin' => true]);
        $s->save();
        $s = new User(['nombre' => 'Melanie',
                        'email' => 'mel@mel.com',
                        'password' => Hash::make('123456'),
                        'telefono' => 222222222,
                        'direccion' => 'Calle 2',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/17/2003')),
                        'esAdmin' => false]);
        $s->save();

        $s = new User(['nombre' => 'Pedro',
                        'email' => 'pedrogial@gmail.com',
                        'password' => Hash::make('123456'),
                        'telefono' => 333333333,
                        'direccion' => 'Calle 3',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/18/2003')),
                        'esAdmin' => false]);
        $s->save();

        $s = new User(['nombre' => 'Dani',
                        'email' => 'dani@dani.com',
                        'password' => Hash::make('123456'),
                        'telefono' => 444444444,
                        'direccion' => 'Calle 4',
                        'fechaNacimiento' => date('Y-m-d',strtotime('10/20/2003')),
                        'esAdmin' => false]);
        $s->save();  
    }
}
