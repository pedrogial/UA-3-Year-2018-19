<?php
use App\User;
use App\Evento;
/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::group(['middleware' => 'auth'], function() {
    Route::resource('miusuario','MyUserController');
    Route::resource('mifactura','MyFacturaController');
    Route::get('/miborrar/{id}', 'MyFacturaController@borrar')->name('mifactura.borrar');
    //Ticket
    Route::get('/comprar/{idEvento}/{idFactura}', 'TicketController@comprar')->name('ticket.comprar');
    Route::get('/añadir/{idEvento}/{idFactura}/{numAsiento}', 'TicketController@añadir')->name('ticket.añadir');
    //Factura
    Route::get('/crear/{id}', 'FacturaController@crear')->name('factura.crear');
    Route::get('/carrito/{id}', 'FacturaController@carrito')->name('factura.carrito');
    Route::get('/finalizar/{id}', 'FacturaController@finalizar')->name('factura.finalizar');
    Route::get('/borrar/{id}', 'FacturaController@borrar')->name('factura.borrar');  
    Route::get('/intermediario', 'FacturaController@intermediario')->name('factura.intermediario');  
});

Route::group(['middleware' => 'admin'], function() {
    Route::resource('factura','FacturaController');
    Route::get('/search', 'UserController@search')->name('usuario.search'); // Este método genera una sola ruta con nombre name
    Route::get('/filter', 'UserController@filter')->name('usuario.filter');
    Route::resource('evento','EventoController'); // Este método genera todas las routas automáticamente
    Route::resource('usuario','UserController');
    Route::resource('ticket','TicketController');
    Route::resource('lugar','LugarController');
    Route::resource('categoria','CategoriaController');
});

Auth::routes();
Route::get('/evento/{evento}', 'EventoController@show')->name('evento.show');
Route::get('/home', 'HomeController@index')->name('home');
Route::get('/', function() {
        $evento = Evento::orderBy('nombre','ASC')->orderBy('precio','DESC')->paginate(3);
        return view('inicio',compact('evento'));
});
Route::get('/info', 'InfoController@index')->name('info');
Route::resource('contacto', 'ContactoController');
Route::get('/indexUser', 'EventoController@indexUser')->name('evento.indexUser');

