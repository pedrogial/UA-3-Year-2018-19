/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss;

import categorias.ConParametros;
import categorias.SinParametros;
import categorias.TestsLlanosTablaA;
import categorias.TestsLlanosTablaB;
import java.util.ArrayList;
import java.util.Arrays;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.experimental.categories.Category;

/**
 *
 * @author ppss
 */

public class TestDatosSinParametros {
    
    private Datos datos;
    
    public TestDatosSinParametros() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        datos = new Datos();
    }
    
    @After
    public void tearDown() {
    }

    @Category({SinParametros.class, TestsLlanosTablaA.class})
    @Test
    public void testC1A(){
        ArrayList<Integer> lecturas = new ArrayList<Integer>(Arrays.asList(3));
        
        Tramo resultadoEsperado = new Tramo(0, 0);
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
    
    @Category({SinParametros.class, TestsLlanosTablaA.class})
    @Test
    public void testC2A(){
        ArrayList<Integer> lecturas = new ArrayList<Integer>(Arrays.asList(100, 100, 100, 100));
        
        Tramo resultadoEsperado = new Tramo(0, 3);
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
    
    @Category({SinParametros.class, TestsLlanosTablaA.class})
    @Test
    public void testC3A(){
        ArrayList<Integer> lecturas = new ArrayList<Integer>(Arrays.asList(120, 140, 180, 180, 180));
        
        Tramo resultadoEsperado = new Tramo(2, 2);
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
    
    @Category(TestsLlanosTablaB.class)
    @Test
    public void testC1B(){
        ArrayList<Integer> lecturas = new ArrayList<Integer>(Arrays.asList(-1));
        
        Tramo resultadoEsperado = new Tramo(0, 0);
        assertEquals(0, datos.buscarTramoLlanoMasLargo(lecturas).getOrigen());
        assertEquals(0, datos.buscarTramoLlanoMasLargo(lecturas).getDuracion());
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
    
    @Category(TestsLlanosTablaB.class)
    @Test
    public void testC2B(){
        ArrayList<Integer> lecturas = new ArrayList<Integer>(Arrays.asList(-1, -1, -1, -1));
        
        Tramo resultadoEsperado = new Tramo(0, 3);
        assertEquals(0, datos.buscarTramoLlanoMasLargo(lecturas).getOrigen());
        assertEquals(3, datos.buscarTramoLlanoMasLargo(lecturas).getDuracion());
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
    
    @Category(TestsLlanosTablaB.class)
    @Test
    public void testC3B(){
        ArrayList<Integer> lecturas = new ArrayList<Integer>(Arrays.asList(120, 140, -10, -10, -10));
        
        Tramo resultadoEsperado = new Tramo(2, 2);
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
}
