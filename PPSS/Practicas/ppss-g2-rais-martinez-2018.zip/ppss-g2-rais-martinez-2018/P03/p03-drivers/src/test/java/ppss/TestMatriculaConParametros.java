/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss;

import categorias.ConParametros;
import java.util.Arrays;
import java.util.Collection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author ppss
 */
@Category(ConParametros.class)
@RunWith(Parameterized.class)
public class TestMatriculaConParametros {
    
    @Parameterized.Parameters(name = "Caso C{index}: calculaTasaMatricula({0},{1},{2})= {3}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{ {19, false, true, 2000.0f}, //C1
            {68, false, true, 250.0f}, //C2
            {19, true, true, 250.0f}, //C3
            {19, false, false, 500.0f}, //C4
            {61, false, false, 400.0f} //C5
        });
    }
    private int edad;
    private boolean familia_numerosa, repetidor;
    private float resultadoEsperado;
    private Matricula m = new Matricula();
    public TestMatriculaConParametros(int edad, boolean familia_numerosa, boolean repetidor, float resultadoEsperado) {
        this.edad = edad;
        this.familia_numerosa = familia_numerosa;
        this.repetidor = repetidor;
        this.resultadoEsperado = resultadoEsperado;
    }
    
    @Test
    public void testMatricula(){
        assertEquals(resultadoEsperado, m.calculaTasaMatricula(edad, familia_numerosa, repetidor), 0.002f);
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
}
