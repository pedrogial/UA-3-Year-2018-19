/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss;

import categorias.SinParametros;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.experimental.categories.Category;

/**
 *
 * @author ppss
 */
@Category(SinParametros.class)
public class TestMatriculaSinParametros {
    
    private Matricula m;
    
    public TestMatriculaSinParametros() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
        
    }
    
    @Before
    public void setUp() {
        m = new Matricula();
    }
    
    @After
    public void tearDown() {
    }

    @Test
    public void testC1() {
        int edad = 19;
        boolean familia_numerosa = false;
        boolean repetidor = true;
         
        float resultadoEsperado = 2000.0f;
        float resultadoReal = m.calculaTasaMatricula(edad, familia_numerosa, repetidor);
        
        assertEquals(resultadoEsperado, resultadoReal, 0.002f);
        
    }
    
    @Test
    public void testC2() {
        int edad = 68;
        boolean familia_numerosa = false;
        boolean repetidor = true;
        
        float resultadoEsperado = 250.0f;
        float resultadoReal = m.calculaTasaMatricula(edad, familia_numerosa, repetidor);
        
        assertEquals(resultadoEsperado, resultadoReal, 0.002f);
        
    }
    
    @Test
    public void testC3() {
        int edad = 19;
        boolean familia_numerosa = true;
        boolean repetidor = true;
        
        float resultadoEsperado = 250.0f;
        float resultadoReal = m.calculaTasaMatricula(edad, familia_numerosa, repetidor);
        
        assertEquals(resultadoEsperado, resultadoReal, 0.002f);
    }
    
    @Test
    public void testC4() {
        int edad = 19;
        boolean familia_numerosa = false;
        boolean repetidor = false;
        
        float resultadoEsperado = 500.0f;
        float resultadoReal = m.calculaTasaMatricula(edad, familia_numerosa, repetidor);
        
        assertEquals(resultadoEsperado, resultadoReal, 0.002f);
    }
    
    @Test
    public void testC5() {
        int edad = 61;
        boolean familia_numerosa = false;
        boolean repetidor = false;
        
        float resultadoEsperado = 400.0f;
        float resultadoReal = m.calculaTasaMatricula(edad, familia_numerosa, repetidor);
        
        assertEquals(resultadoEsperado, resultadoReal, 0.002f);
    }
}
