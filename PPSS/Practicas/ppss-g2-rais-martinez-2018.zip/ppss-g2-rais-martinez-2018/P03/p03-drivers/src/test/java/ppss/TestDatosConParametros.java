/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss;

import categorias.ConParametros;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;

/**
 *
 * @author ppss
 */
@Category(ConParametros.class)
@RunWith(Parameterized.class)
public class TestDatosConParametros {
    
    @Parameterized.Parameters(name = "Caso C{index}: buscarTramoLlanoMasLargo({0}) = {1}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{ 
            {new ArrayList<>(Arrays.asList(3)), new Tramo(0, 0)}, //C1A
            {new ArrayList<>(Arrays.asList(100, 100, 100, 100)), new Tramo(0, 3)}, //C2A
            {new ArrayList<>(Arrays.asList(120, 140, 180, 180, 180)), new Tramo(2, 2)}, //C3A
            {new ArrayList<>(Arrays.asList(-1)), new Tramo(0, 0)}, //C1B
            {new ArrayList<>(Arrays.asList(-1, -1, -1, -1)), new Tramo(0, 3)}, //C2B
            {new ArrayList<>(Arrays.asList(120, 140, -10, -10, -10)), new Tramo(2, 2)} //C3B
        });
    }
    private ArrayList<Integer> lecturas;
    private Datos datos = new Datos();
    private Tramo resultadoEsperado;
    
    public TestDatosConParametros(ArrayList<Integer> lecturas, Tramo resultadoEsperado) {
        this.lecturas = lecturas;
        this.resultadoEsperado = resultadoEsperado;
    }
    
    @Test
    public void testBuscarTramoLlanoMasLargo(){
        assertEquals(resultadoEsperado, datos.buscarTramoLlanoMasLargo(lecturas));
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
}
