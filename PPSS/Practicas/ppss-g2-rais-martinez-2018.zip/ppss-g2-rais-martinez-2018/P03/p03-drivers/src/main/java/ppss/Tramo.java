/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss;

/**
 *
 * @author ppss
 */
public class Tramo {
    private int longitud;
    private int duracion;

    public Tramo(int longitud, int duracion) {
        this.longitud = longitud;
        this.duracion = duracion;
    }

    public Tramo() {
        this.duracion = 0;
        this.longitud = 0;
    }
    
    public int getOrigen() {
        return longitud;
    }

    public void setOrigen(int longitud) {
        this.longitud = longitud;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 97 * hash + this.longitud;
        hash = 97 * hash + this.duracion;
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Tramo other = (Tramo) obj;
        if (this.longitud != other.longitud) {
            return false;
        }
        if (this.duracion != other.duracion) {
            return false;
        }
        return true;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }
}
