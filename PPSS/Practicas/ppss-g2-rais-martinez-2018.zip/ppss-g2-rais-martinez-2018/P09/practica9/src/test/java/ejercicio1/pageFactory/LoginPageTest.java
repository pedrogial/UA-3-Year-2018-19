/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1.pageFactory;

import junit.framework.Assert;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author ppss
 */
public class LoginPageTest {
    WebDriver driver;
    LoginPage poLogin;
    ManagerPage poManagerPage;
    public LoginPageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        driver = new FirefoxDriver();
        poLogin = PageFactory.initElements(driver, LoginPage.class);
    }
    
    @After
    public void tearDown() {
        driver.close();
    }

    /**
     * Test of login method, of class LoginPage.
     */
    @Test
    public void test_Login_Incorrect() {
        String loginPageTitle = poLogin.getLoginTitle();
        assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
        poLogin.login("mngr136769", "incorrectPass");
        
        String ResultadoEsperado = "User or Password is not valid";
        Alert alert = poLogin.getAlerta();
        String ResultadoReal = alert.getText();
        alert.accept();
        
        assertEquals(ResultadoEsperado, ResultadoReal);
        
        //driver.close();
    }
    
    @Test
    public void test_Login_Correct(){
        String loginPageTitle = poLogin.getLoginTitle();
        assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
        poLogin.login("mngr136769", "vYgYget");

        poManagerPage = PageFactory.initElements(driver, ManagerPage.class);
        assertTrue(poManagerPage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr136769"));
        //driver.close();
    }
    
}
