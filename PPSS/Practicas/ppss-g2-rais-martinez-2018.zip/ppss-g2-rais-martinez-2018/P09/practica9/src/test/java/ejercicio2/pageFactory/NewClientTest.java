/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2.pageFactory;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author ppss
 */
public class NewClientTest {
    WebDriver driver;
    LoginPage poLogin;
    ManagerPage poManagerPage;
    NewCustomerPage poNewCustomerPage;
    DeleteCustomerPage poDeleteCustomerPage;
    public NewClientTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
        driver = new FirefoxDriver();
        poLogin = PageFactory.initElements(driver, LoginPage.class);
    }
    
    @After
    public void tearDown() {
        driver.close();
    }

    /**
     * Test of register method, of class NewCustomerPage.
     */
    @Test
    public void testRegister() {
        String name = "Jasmina Rais Martinez";
        String option = "f";
        String dob = "1997-09-01";
        String addr = "Calle X";
        String c = "Alicante";
        String st = "Alicante";
        String p = "123456";
        String n = "999999999";
        String e = "jrm85@alu.ua.es";
        String pass = "123456";
        
        String loginPageTitle = poLogin.getLoginTitle();
        assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
        poLogin.login("mngr136769", "vYgYget");

        poManagerPage = PageFactory.initElements(driver, ManagerPage.class);
        assertTrue(poManagerPage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr136769"));
        
        poNewCustomerPage = poManagerPage.newCustomer();
        Assert.assertTrue(poNewCustomerPage.getHomePageDashboardUserName().toLowerCase().contains("add new customer"));
        
        poNewCustomerPage.register(name, option, dob, addr, c, st, p, n, e, pass);
        
        String ResultadoEsperado = "Customer Registered Successfully!!!";
        WebElement ResReal = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[1]/td/p"));
    
        assertTrue(ResReal.getText().contains(ResultadoEsperado));
        String m4 = driver.findElement(By.xpath("/html/body/table/tbody/tr/td/table/tbody/tr[4]/td[2]")).getText();
        System.out.println("ID customer:");
        System.out.println(m4);
        
        poNewCustomerPage.continuar();
        Assert.assertTrue(poManagerPage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr136769"));
        
        poDeleteCustomerPage = poManagerPage.deleteCustomer();
        
        Assert.assertTrue(poDeleteCustomerPage.getCabecera().toLowerCase().contains("delete customer form"));
        
        poDeleteCustomerPage.deleteCustomer(m4);
        
        Alert alert = driver.switchTo().alert();
        String mensaje = alert.getText();
        Assert.assertTrue(mensaje.equals("Do you really want to delete this Customer?"));
        alert.accept();
        
        alert = driver.switchTo().alert();
        mensaje = alert.getText();
        Assert.assertTrue(mensaje.equals("Customer deleted Successfully"));
        alert.accept();
    }
    
    @Test
    public void testRegisterIncorrect() {
        String name = "Cliente Incorrecto";
        String option = "f";
        String dob = "1997-09-01";
        String addr = "Calle X";
        String c = "Alicante";
        String st = "Alicante";
        String p = "123456";
        String n = "999999999";
        String e = "jrm85@alu.ua.es";
        String pass = "123456";
        
        String loginPageTitle = poLogin.getLoginTitle();
        assertTrue(loginPageTitle.toLowerCase().contains("guru99 bank"));
        poLogin.login("mngr136769", "vYgYget");

        poManagerPage = PageFactory.initElements(driver, ManagerPage.class);
        assertTrue(poManagerPage.getHomePageDashboardUserName().toLowerCase().contains("manger id : mngr136769"));
        
        poNewCustomerPage = poManagerPage.newCustomer();
        Assert.assertTrue(poNewCustomerPage.getHomePageDashboardUserName().toLowerCase().contains("add new customer"));
        
        poNewCustomerPage.register(name, option, dob, addr, c, st, p, n, e, pass);
        
        Alert alert = driver.switchTo().alert();
        String mensaje = alert.getText();
        Assert.assertTrue(mensaje.equals("Email Address Already Exist !!"));
        alert.accept();
    }
    
}
