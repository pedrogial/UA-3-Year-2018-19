/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio2.pageFactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

/**
 *
 * @author ppss
 */
public class NewCustomerPage {
    WebDriver driver;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[1]/td/p") WebElement pageTitle;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[4]/td[2]/input") WebElement nameCustomer;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[5]/td[2]/input[1]") WebElement maleOption;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[5]/td[2]/input[2]") WebElement femaleOption;
    @FindBy(xpath="//*[@id=\"dob\"]") WebElement dateBirth;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[7]/td[2]/textarea") WebElement address;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[8]/td[2]/input") WebElement city;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[9]/td[2]/input") WebElement state;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[10]/td[2]/input") WebElement pin;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[11]/td[2]/input") WebElement number;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[12]/td[2]/input") WebElement email;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[13]/td[2]/input") WebElement password;
    @FindBy(xpath="/html/body/table/tbody/tr/td/table/tbody/tr[14]/td[2]/input[1]") WebElement continuar;
    
    public NewCustomerPage(WebDriver driver){
        this.driver = driver;
        this.driver.get("http://demo.guru99.com/V4");
    }
    
    public void register(String name, String option, String dob, String addr, 
            String c, String st, String p, String n, String e, String pass){
        nameCustomer.sendKeys(name);
        if(option == "m"){
            maleOption.click();
        }
        else if(option == "f"){
            femaleOption.click();
        }
        dateBirth.sendKeys(dob);
        address.sendKeys(addr);
        city.sendKeys(c);
        state.sendKeys(st);
        pin.sendKeys(p);
        number.sendKeys(n);
        email.sendKeys(e);
        password.sendKeys(pass);
        continuar.click();
    }
    
    public void continuar(){
        continuar.click();
    }

    public String getHomePageDashboardUserName() {
        return pageTitle.getText();
    }
}
