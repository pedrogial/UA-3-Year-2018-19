/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio3.testsUnitarios;

import ppss.ejercicio3.Reserva;
import ppss.ejercicio3.Usuario;

/**
 *
 * @author ppss
 */
public class TestableReserva extends Reserva{
    
    @Override
    public boolean compruebaPermisos(String login, String password, Usuario tipoUsu) {
        return (login == "ppss");
    }
}
