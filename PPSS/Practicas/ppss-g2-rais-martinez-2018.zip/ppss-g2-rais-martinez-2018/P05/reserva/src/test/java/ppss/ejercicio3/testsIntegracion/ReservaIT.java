/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio3.testsIntegracion;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.logging.Level;
import java.util.logging.Logger;
import ppss.ejercicio3.testsUnitarios.TestableReserva;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.experimental.categories.Category;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import ppss.ejercicio3.Reserva;

/**
 *
 * @author ppss
 */
@RunWith(Parameterized.class)
public class ReservaIT {
    @Parameterized.Parameters(name = "Caso C{index}: realizaReserva({0}, {1}, {2}, {3}) = {4}")
    public static Collection<Object[]> data() {
        return Arrays.asList(new Object[][]{ 
            {"xxxx", "xxxx", "Luis", Arrays.asList("11111"), "ERROR de permisos; "}, //C1
            {"ppss", "ppss", "Luis", Arrays.asList("33333"), "ISBN invalido:33333; "}, //C3
            {"ppss", "ppss", "Pepe", Arrays.asList("11111"), "SOCIO invalido; "}, //C4
            {"ppss", "ppss", "Luis", Arrays.asList("11111"), "CONEXION invalida; "}, //C5
        });
    }
    private Reserva reserva;
    private String bibliotecario, pass, socio, ResultadoEsperado;
    private String[] isbns;
    public ReservaIT(String bib, String pw, String s, String RE, String[] i) {
        bibliotecario = bib;
        pass = pw;
        socio = s;
        ResultadoEsperado = RE;
        isbns = i;
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    /**
     * Test of realizaReserva method, of class Reserva.
     */
    @Test
    public void testRealizaReserva(){
        try {
            reserva.realizaReserva(bibliotecario, pass, socio, isbns);
        } catch (Exception ex) {
            assertEquals(ResultadoEsperado, ex.getMessage());
        }
    }
    @Test
    public void testRealizaReservaC2(){  
        System.out.println("realizaReservaC2");
        String login = "ppss";
        String password = "ppss";
        String socio = "Luis";
        String[] isbns = {"11111", "22222"};
        TestableReserva instance = new TestableReserva();
        try {
            instance.realizaReserva(login, password, socio, isbns);
        } catch (Exception ex) {
            fail("No se deberia haber producido una excepcion");
        }
    
    }
}
