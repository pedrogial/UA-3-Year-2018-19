/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio3.testsUnitarios;

import java.util.logging.Level;
import java.util.logging.Logger;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import ppss.ejercicio3.IOperacionBOFactory;
import static org.junit.Assert.*;
import ppss.ejercicio3.excepciones.ReservaException;

/**
 *
 * @author ppss
 */
public class ReservaTest {
    
    public ReservaTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of realizaReserva method, of class Reserva.
     */
    @Test
    public void testRealizaReservaC1(){
        System.out.println("realizaReservaC1");
        String login = "xxxx";
        String password = "xxxx";
        String socio = "Luis";
        String[] isbns = {"11111"};
        TestableReserva instance = new TestableReserva();
        try {
            OperacionStub oper = new OperacionStub();
            oper.setErrorBD(false);
            IOperacionBOFactory.setOperacion(oper);
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haber producido una excepcion");
        } catch (Exception ex) {
            String ResultadoEsperado = "ERROR de permisos; ";
            String ResultadoReal = ex.getMessage();
            
            assertEquals(ResultadoEsperado, ResultadoReal);
        }
    }
    
    @Test
    public void testRealizaReservaC2(){
        System.out.println("realizaReservaC2");
        String login = "ppss";
        String password = "ppss";
        String socio = "Luis";
        String[] isbns = {"11111", "22222"};
        TestableReserva instance = new TestableReserva();
        try {
            OperacionStub oper = new OperacionStub();
            oper.setErrorBD(false);
            IOperacionBOFactory.setOperacion(oper);
            instance.realizaReserva(login, password, socio, isbns);
            
        } catch (Exception ex) {
            fail("No se deberia haber producido una excepcion");
        }
    }
    
    @Test
    public void testRealizaReservaC3(){
        System.out.println("realizaReservaC3");
        String login = "ppss";
        String password = "ppss";
        String socio = "Luis";
        String[] isbns = {"33333"};
        TestableReserva instance = new TestableReserva();
        try {
            OperacionStub oper = new OperacionStub();
            oper.setErrorBD(false);
            IOperacionBOFactory.setOperacion(oper);
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haber producido una excepcion");
        } catch (Exception ex) {
            String ResultadoEsperado = "ISBN invalido:33333; ";
            String ResultadoReal = ex.getMessage();
            
            assertEquals(ResultadoEsperado, ResultadoReal);
        }
    }
    
    @Test
    public void testRealizaReservaC4(){
        System.out.println("realizaReservaC4");
        String login = "ppss";
        String password = "ppss";
        String socio = "Pepe";
        String[] isbns = {"11111"};
        TestableReserva instance = new TestableReserva();
        try {
            OperacionStub oper = new OperacionStub();
            oper.setErrorBD(false);
            IOperacionBOFactory.setOperacion(oper);
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haber producido una excepcion");
        } catch (Exception ex) {
            String ResultadoEsperado = "SOCIO invalido; ";
            String ResultadoReal = ex.getMessage();
            
            assertEquals(ResultadoEsperado, ResultadoReal);
        }
    }
    
    @Test
    public void testRealizaReservaC5(){
        System.out.println("realizaReservaC5");
        String login = "ppss";
        String password = "ppss";
        String socio = "Luis";
        String[] isbns = {"11111"};
        TestableReserva instance = new TestableReserva();
        try {
            OperacionStub oper = new OperacionStub();
            oper.setErrorBD(true);
            IOperacionBOFactory.setOperacion(oper);
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haber producido una excepcion");
        } catch (Exception ex) {
            String ResultadoEsperado = "CONEXION invalida; ";
            String ResultadoReal = ex.getMessage();
            
            assertEquals(ResultadoEsperado, ResultadoReal);
        }
    }
}
