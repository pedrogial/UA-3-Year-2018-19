/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio3.excepciones;

/**
 *
 * @author ppss
 */
public class ReservaException extends Exception {
    public ReservaException(String message) {super(message);}
}
