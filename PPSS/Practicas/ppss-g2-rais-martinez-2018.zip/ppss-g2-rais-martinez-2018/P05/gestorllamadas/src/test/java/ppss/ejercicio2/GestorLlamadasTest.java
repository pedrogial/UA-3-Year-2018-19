/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio2;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ppss
 */
public class GestorLlamadasTest {
    
    public GestorLlamadasTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of calculaConsumo method, of class GestorLlamadas.
     */
    @Test
    public void testCalculaConsumoC1() {
        System.out.println("calculaConsumoC1");
        int minutos = 10;
        TestableGestorLlamadas instance = new TestableGestorLlamadas();
        CalendarioStub cs = new CalendarioStub();
        cs.setResultado(15);
        instance.setCalendario(cs);
        double expResult = 208.0;
        double result = instance.calculaConsumo(minutos);
        assertEquals(expResult, result, 0.0);
    }
    
     /**
     * Test of calculaConsumo method, of class GestorLlamadas.
     */
    @Test
    public void testCalculaConsumoC2() {
        System.out.println("calculaConsumoC1");
        int minutos = 10;
        TestableGestorLlamadas instance = new TestableGestorLlamadas();
        CalendarioStub cs = new CalendarioStub();
        cs.setResultado(22);
        instance.setCalendario(cs);
        double expResult = 105.0;
        double result = instance.calculaConsumo(minutos);
        assertEquals(expResult, result, 0.0);
    }
    
}
