/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.fail;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

/**
 *
 * @author ppss
 */
public class DataArrayTest {
    int[] coleccion;
    int numElem;
    DataArray data = new DataArray();

    @BeforeClass
    public static void setUpClass() throws Exception {
    }

    @AfterClass
    public static void tearDownClass() throws Exception {
    }

    @Before
    public void setUp() throws Exception {
    }

    @After
    public void tearDown() throws Exception {
    }
    
    @Test
    public void testAddC1() {
        int E1 = 1;
        data.add(E1);
        Assert.assertEquals(this.data.size(), 1);
    }
    
    @Test
    public void testAddC2() {
        int E1 = 1;
        int E2 = 2;
        int E3 = 3;
        data.add(E1);
        data.add(E2);
        data.add(E3);
        Assert.assertEquals(this.data.size(), 3);
    }
    
    @Test
    public void testAddC3() {
        int E11 = 11;
        for(int i = 1; i <= 10; i++){
            data.add(i);
        }
        DataArray data2 = new DataArray();
        data2 = data;
        data2.add(E11);
        for(int i = 0; i < 10; i++){
            assertEquals(this.data.getColeccion()[i], data2.getColeccion()[i]);
        }   
    }
    
    @Test
    public void testAddC4() {
        int E0 = 0;
        data.add(E0);
        assertEquals(data.size(), 0);
    }

    /**
     * Test of getColeccion method, of class DataArray.
     */
    @Test
    public void testGetColeccion() {
        System.out.println("getColeccion");
        DataArray instance = new DataArray();
        int[] expResult = new int [10];
        int[] result = instance.getColeccion();
        assertArrayEquals(expResult, result);
        
    }

    /**
     * Test of delete method, of class DataArray.
     */
    @Test
    public void testDeleteC1() {
        System.out.println("delete");
        int elem = 3;
        int[] a1 = new int[10];
        a1[0] = 1;
        a1[1] = 2;
        a1[2] = 3;
        a1[3] = 4;
        DataArray instance = new DataArray(a1, 4);
        int[] expResult = new int[10];
        expResult[0] = 1;
        expResult[1] = 2;
        expResult[2] = 4;
        int[] result = instance.delete(elem);
        assertArrayEquals(expResult, result);
        assertEquals(3, instance.size());
    }
    
    @Test
    public void testDeleteC2() {
        System.out.println("delete");
        int elem = 3;
        int[] a1 = new int[10];
        a1[0] = 1;
        a1[1] = 2;
        a1[2] = 3;
        a1[3] = 4;
        a1[4] = 3;
        DataArray instance = new DataArray(a1, 5);
        int[] expResult = new int[10];
        expResult[0] = 1;
        expResult[1] = 2;
        expResult[2] = 4;
        int[] result = instance.delete(elem);
        assertArrayEquals(expResult, result);
        assertEquals(3, instance.size());
    }
    
    @Test
    public void testDeleteC3() {
        System.out.println("delete");
        int elem = 5;
        int[] a1 = new int[10];
        a1[0] = 1;
        a1[1] = 2;
        a1[2] = 3;
        a1[3] = 4;
        DataArray instance = new DataArray(a1, 4);
        int[] expResult = new int[10];
        expResult[0] = 1;
        expResult[1] = 2;
        expResult[2] = 3;
        expResult[3] = 4;
        int[] result = instance.delete(elem);
        assertArrayEquals(expResult, result);
        assertEquals(4, instance.size());
    }
    
    @Test
    public void testDeleteC4() {
        System.out.println("delete");
        int elem = 5;
        DataArray instance = new DataArray();
        int[] expResult = new int[10];
        int[] result = instance.delete(elem);
        assertArrayEquals(expResult, result);
        assertEquals(0, instance.size());
    }
}
