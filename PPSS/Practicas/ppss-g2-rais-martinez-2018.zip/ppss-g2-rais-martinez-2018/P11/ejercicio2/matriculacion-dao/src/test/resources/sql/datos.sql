USE matriculacion;

INSERT INTO alumnos(nif, nombre, direccion, email, fechaNac) VALUES
 ('12345678A','Pepe Lopez','Gran Via, 16','pepe@ppss.ua.es', '1985-02-22 00:00:00');
INSERT INTO alumnos(nif, nombre, direccion, email, fechaNac) VALUES
 ('00000000B','Juan Garcia','Rambla, 22','juan@ppss.ua.es', '1982-02-22 00:00:00');
INSERT INTO alumnos(nif, nombre, direccion, email, fechaNac) VALUES
 ('11111111C','Ana Martinez','Maisonnave, 5','ana@ppss.ua.es', '1980-02-22 00:00:00');
