/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.matriculacion.dao;

import java.util.Calendar;
import org.apache.log4j.BasicConfigurator;
import org.dbunit.Assertion;
import org.dbunit.IDatabaseTester;
import org.dbunit.JdbcDatabaseTester;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.IDataSet;
import org.dbunit.dataset.ITable;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.dbunit.util.fileloader.DataFileLoader;
import org.dbunit.util.fileloader.FlatXmlDataFileLoader;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import ppss.matriculacion.to.AlumnoTO;

/**
 *
 * @author ppss
 */
public class AlumnoDAOIT {
    
    private AlumnoTO alumno;
    private IDatabaseTester databaseTester;
    
    public AlumnoDAOIT() {
    }
    
   @BeforeClass
  public static void only_once() {
      BasicConfigurator.configure();
  }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() throws ClassNotFoundException, Exception {
        databaseTester = new JdbcDatabaseTester("com.mysql.jdbc.Driver",
        		"jdbc:mysql://localhost:3306/matriculacion?useSSL=false", "root", "ppss");
        
        DataFileLoader loader = new FlatXmlDataFileLoader();
        IDataSet dataSet = loader.load("/tabla2.xml");	 
    
        databaseTester.setDataSet(dataSet);

        databaseTester.onSetup();
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    @Test
    public void testA1() throws Exception {
        alumno = new AlumnoTO();
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.YEAR, 1985);
        cal.set(Calendar.MONTH, 1); // Nota: en la clase Calendar, el primer mes es 0
        cal.set(Calendar.DATE, 22);
        alumno.setFechaNacimiento(cal.getTime());
        alumno.setNif("33333333C");
        alumno.setNombre("Elena Aguirre Juarez");
        new FactoriaDAO().getAlumnoDAO().addAlumno(alumno);
        
        IDatabaseConnection connection = databaseTester.getConnection();
        //DatabaseConfig dbconfig = connection.getConfig();
        //dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());

        IDataSet databaseDataSet = connection.createDataSet();
        ITable actualTable = databaseDataSet.getTable("alumnos");

        DataFileLoader loader = new FlatXmlDataFileLoader();
        IDataSet expectedDataSet = loader.load("/tabla3.xml");
        ITable expectedTable = expectedDataSet.getTable("alumnos");
        
        Assertion.assertEquals(expectedTable, actualTable);

    }
    @Test(expected=DAOException.class)
    public void testA2() throws Exception {
        alumno = new AlumnoTO();
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.YEAR, 1982);
        cal.set(Calendar.MONTH, 1); // Nota: en la clase Calendar, el primer mes es 0
        cal.set(Calendar.DATE, 22);
        alumno.setFechaNacimiento(cal.getTime());
        alumno.setNif("11111111A");
        alumno.setNombre("Alfonso Ramirez Ruiz");
        new FactoriaDAO().getAlumnoDAO().addAlumno(alumno);
        
        fail("ERROR: deberia haberse lanzado excepcion DAOException");
    }
    
    @Test(expected=DAOException.class)
    public void testA3() throws Exception {
        alumno = new AlumnoTO();
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.YEAR, 1982);
        cal.set(Calendar.MONTH, 1); // Nota: en la clase Calendar, el primer mes es 0
        cal.set(Calendar.DATE, 22);
        alumno.setFechaNacimiento(cal.getTime());
        alumno.setNif("44444444D");
        new FactoriaDAO().getAlumnoDAO().addAlumno(alumno);
        
        fail("ERROR: deberia haberse lanzado excepcion DAOException");
    }
    
    @Test(expected=DAOException.class)
    public void testA4() throws Exception {
        new FactoriaDAO().getAlumnoDAO().addAlumno(null);
        
        fail("ERROR: deberia haberse lanzado excepcion DAOException");
    }
    
    @Test(expected=DAOException.class)
    public void testA5() throws Exception {
        alumno = new AlumnoTO();
        Calendar cal = Calendar.getInstance();
        cal.set(Calendar.HOUR, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        cal.set(Calendar.YEAR, 1982);
        cal.set(Calendar.MONTH, 1); // Nota: en la clase Calendar, el primer mes es 0
        cal.set(Calendar.DATE, 22);
        alumno.setFechaNacimiento(cal.getTime());
        alumno.setNombre("Pedro Garcia Lopez");
        new FactoriaDAO().getAlumnoDAO().addAlumno(alumno);
        
        fail("ERROR: deberia haberse lanzado excepcion DAOException");
    }
    
    @Test
    public void testB1() throws Exception {
        
        new FactoriaDAO().getAlumnoDAO().delAlumno("11111111A");
        
        IDatabaseConnection connection = databaseTester.getConnection();
        //DatabaseConfig dbconfig = connection.getConfig();
        //dbconfig.setProperty("http://www.dbunit.org/properties/datatypeFactory", new MySqlDataTypeFactory());

        IDataSet databaseDataSet = connection.createDataSet();
        ITable actualTable = databaseDataSet.getTable("alumnos");

        DataFileLoader loader = new FlatXmlDataFileLoader();
        IDataSet expectedDataSet = loader.load("/tabla4.xml");
        ITable expectedTable = expectedDataSet.getTable("alumnos");
        
        Assertion.assertEquals(expectedTable, actualTable);
    }
    
    @Test(expected=DAOException.class)
    public void testB2() throws Exception {
        
        new FactoriaDAO().getAlumnoDAO().delAlumno("33333333C");
        
        fail("ERROR: deberia haberse lanzado excepcion DAOException");
    }
}
