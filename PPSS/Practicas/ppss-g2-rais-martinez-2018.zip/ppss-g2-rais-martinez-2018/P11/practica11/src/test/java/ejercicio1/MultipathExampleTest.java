/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejercicio1;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ppss
 */
public class MultipathExampleTest {
    
    public MultipathExampleTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of multiPath method, of class MultipathExample.
     */
    @Test
    public void testMultiPathC1() {
        System.out.println("multiPath");
        int a = 6;
        int b = 6;
        int c = 0;
        MultipathExample instance = new MultipathExample();
        int expResult = 12;
        int result = instance.multiPath(a, b, c);
        assertEquals(expResult, result);
        
    }
    
    /**
     * Test of multiPath method, of class MultipathExample.
     */
    @Test
    public void testMultiPathC2() {
        System.out.println("multiPath");
        int a = 3;
        int b = 3;
        int c = 0;
        MultipathExample instance = new MultipathExample();
        int expResult = 0;
        int result = instance.multiPath(a, b, c);
        assertEquals(expResult, result);
        
    }
    
}
