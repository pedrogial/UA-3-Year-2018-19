/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio2;

import java.util.logging.Level;
import ppss.ejercicio2.ClienteWebServiceException;
import java.util.logging.Logger;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ppss
 */
public class PremioTest {
    
    public PremioTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of compruebaPremio method, of class Premio.
     */
    @Test
    public void testCompruebaPremioA() {
        try {
            System.out.println("compruebaPremioA");
            String expResult = "Premiado con entrada Final Champions";
            ClienteWebService mockCliente = EasyMock.createMock(ClienteWebService.class);
            EasyMock.expect(mockCliente.obtenerPremio()).andReturn("entrada Final Champions");
            EasyMock.replay(mockCliente);
            Premio instance =  EasyMock.partialMockBuilder(Premio.class).addMockedMethod("generaNumero").createMock();
            EasyMock.expect(instance.generaNumero()).andReturn(0.07f);
            
            instance.cliente = mockCliente;
            
            EasyMock.replay(instance);
            String result = instance.compruebaPremio();
            assertEquals(expResult, result);
            
            EasyMock.verify(mockCliente, instance);
        } catch (ClienteWebServiceException ex) {
            fail("No deberia haberse lanzado la excepcion");
        }
    }
    
    @Test
    public void testCompruebaPremioB() {
        try {
            System.out.println("compruebaPremioB");
            String expResult = "No se ha podido obtener el premio";
            ClienteWebService mockCliente = EasyMock.createMock(ClienteWebService.class);
            EasyMock.expect(mockCliente.obtenerPremio()).andThrow(new ClienteWebServiceException());
            EasyMock.replay(mockCliente);
            
            Premio instance =  EasyMock.partialMockBuilder(Premio.class).addMockedMethod("generaNumero").createMock();
            EasyMock.expect(instance.generaNumero()).andReturn(0.03f);
            instance.cliente = mockCliente;
            
            EasyMock.replay(instance);
            
            String result = instance.compruebaPremio();
            assertEquals(expResult, result);
            
            EasyMock.verify(mockCliente, instance);
        } catch (ClienteWebServiceException ex) {
            fail("No deberia haberse lanzado la excepcion");
        }
    }
}
