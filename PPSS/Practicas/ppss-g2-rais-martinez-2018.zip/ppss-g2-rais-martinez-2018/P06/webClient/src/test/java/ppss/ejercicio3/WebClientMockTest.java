/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio3;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ppss
 */
public class WebClientMockTest {
    
    public WebClientMockTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getContent method, of class WebClient.
     */
    @Test
    public void testGetContentC1() throws IOException {
        try {
            System.out.println("testGetContentC1");
            URL url = new URL("http://www.google.es");
            HttpURLConnection mockHttp = EasyMock.createMock(HttpURLConnection.class);
            EasyMock.expect(mockHttp.getInputStream()).andReturn(new ByteArrayInputStream("Se puede abrir la conexión".getBytes()));
            EasyMock.replay(mockHttp);
            
            WebClient instance = EasyMock.partialMockBuilder(WebClient.class).addMockedMethod("createHttpURLConnection").createMock();
            EasyMock.expect(instance.createHttpURLConnection(url)).andReturn(mockHttp);
            EasyMock.replay(instance);
            
            String expResult = "Se puede abrir la conexión";
            String result = instance.getContent(url);
            assertEquals(expResult, result);
            
            EasyMock.verify(mockHttp, instance);
        } catch (MalformedURLException ex) {
            fail("No deberia producirse excepcion");
        }
    }
    
    @Test
    public void testGetContentC2() throws IOException {
        try {
            System.out.println("testGetContentC2");
            URL url = new URL("http://www.google.es");
            HttpURLConnection mockHttp = EasyMock.createMock(HttpURLConnection.class);
            EasyMock.expect(mockHttp.getInputStream()).andThrow(new IOException());
            EasyMock.replay(mockHttp);
            
            WebClient instance = EasyMock.partialMockBuilder(WebClient.class).addMockedMethod("createHttpURLConnection").createMock();
            EasyMock.expect(instance.createHttpURLConnection(url)).andReturn(mockHttp);
            EasyMock.replay(instance);
            
            String expResult = null;
            String result = instance.getContent(url);
            assertEquals(expResult, result);
            
            EasyMock.verify(mockHttp, instance);
        } catch (MalformedURLException ex) {
            fail("No deberia producirse excepcion");
        }
    }
}
