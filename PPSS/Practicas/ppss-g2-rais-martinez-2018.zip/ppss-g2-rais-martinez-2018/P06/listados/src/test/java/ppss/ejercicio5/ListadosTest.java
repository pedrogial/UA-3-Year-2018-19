/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio5;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.easymock.EasyMock;
import org.easymock.MockType;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author ppss
 */
public class ListadosTest {
    
    public ListadosTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of porApellidos method, of class Listados.
     */
    @Test
    public void testPorApellidosA() {
        System.out.println("porApellidosA");
        ResultSet mockResultSet = EasyMock.createMock(ResultSet.class);
        Statement mockStatement = EasyMock.createMock(Statement.class);
        Connection mockConnection = EasyMock.createMock(Connection.class);
        String tableName = "alumnos";
        Listados instance = new Listados();
        String expResult = "Garcia, Planelles, Jorge\nPérez, Verdú, Carmen\n";
        try {
            EasyMock.expect(mockConnection.createStatement()).andReturn(mockStatement);
            EasyMock.expect(mockStatement.executeQuery("SELECT apellido1, apellido2, nombre FROM " + tableName)).andReturn(mockResultSet);
            EasyMock.expect(mockResultSet.next()).andReturn(Boolean.TRUE);
            EasyMock.expect(mockResultSet.getString("apellido1")).andReturn("Garcia");
            EasyMock.expect(mockResultSet.getString("apellido2")).andReturn("Planelles");
            EasyMock.expect(mockResultSet.getString("nombre")).andReturn("Jorge");
            EasyMock.expect(mockResultSet.next()).andReturn(Boolean.TRUE);
            EasyMock.expect(mockResultSet.getString("apellido1")).andReturn("Pérez");
            EasyMock.expect(mockResultSet.getString("apellido2")).andReturn("Verdú");
            EasyMock.expect(mockResultSet.getString("nombre")).andReturn("Carmen");
            EasyMock.expect(mockResultSet.next()).andReturn(Boolean.FALSE);
            
            EasyMock.replay(mockConnection, mockResultSet, mockStatement);
            String result = instance.porApellidos(mockConnection, tableName);
            assertEquals(expResult, result);
            
            EasyMock.verify(mockConnection, mockResultSet, mockStatement);
        } catch (SQLException ex) {
            fail("No deberia haberse producido la excepcion");
        }
    }
    @Test
    public void testPorApellidosB() {
        System.out.println("porApellidosB");
        ResultSet mockResultSet = EasyMock.createMock(ResultSet.class);
        Statement mockStatement = EasyMock.createMock(Statement.class);
        Connection mockConnection = EasyMock.createMock(Connection.class);
        String tableName = "alumnos";
        Listados instance = new Listados();
        try {
            EasyMock.expect(mockConnection.createStatement()).andReturn(mockStatement);
            EasyMock.expect(mockStatement.executeQuery("SELECT apellido1, apellido2, nombre FROM " + tableName)).andReturn(mockResultSet);
            EasyMock.expect(mockResultSet.next()).andThrow(new SQLException());
            
            EasyMock.replay(mockConnection, mockResultSet, mockStatement);
            String result = instance.porApellidos(mockConnection, tableName);
            
            fail("Deberia haberse producido la excepcion");
        } catch (SQLException ex) {
            
            EasyMock.verify(mockConnection, mockResultSet, mockStatement);
        }
    }
}
