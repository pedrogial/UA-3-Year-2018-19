/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio4;

import java.lang.reflect.Array;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import ppss.ejercicio4.excepciones.IsbnInvalidoException;
import ppss.ejercicio4.excepciones.JDBCException;
import ppss.ejercicio4.excepciones.ReservaException;
import ppss.ejercicio4.excepciones.SocioInvalidoException;

/**
 *
 * @author ppss
 */
public class ReservaMockTest {
    
    public ReservaMockTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of realizaReserva method, of class Reserva.
     */
    @Test
    public void testRealizaReservaC1() {
        System.out.println("testRealizaReservaC1");
        String login = "xxxx";
        String password = "xxxx";
        String socio = "Pepe";
        String[] isbns = {"22222"};
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethod("compruebaPermisos").createMock();
        try {
            
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.replay(instance);
            
            instance.realizaReserva(login, password, socio, isbns);
            
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "ERROR de permisos; ";
            assertEquals(resultadoEsperado, ex.getMessage());
            
            EasyMock.verify(instance);
        }
    }
    
    /**
     * Test of realizaReserva method, of class Reserva.
     */
    @Test
    public void testRealizaReservaC2() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        try {
            System.out.println("testRealizaReservaC2");
            String login = "ppss";
            String password = "ppss";
            String socio = "Pepe";
            String[] isbns = {"22222", "33333"};
            IOperacionBO mockOperacion = EasyMock.createStrictMock(IOperacionBO.class);
            //Expectativas
            mockOperacion.operacionReserva(socio, isbns[0]);
            mockOperacion.operacionReserva(socio, isbns[1]);
            FactoriaBOs mockFactoria = EasyMock.createMock(FactoriaBOs.class);
            EasyMock.expect(mockFactoria.getOperacionBO()).andReturn(mockOperacion);
            Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(mockFactoria);
            EasyMock.replay(mockOperacion, mockFactoria, instance);
            
            instance.realizaReserva(login, password, socio, isbns);
            
            EasyMock.verify(mockOperacion, mockFactoria, instance);
        } catch (ReservaException ex) {
            fail("No deberia haberse producido una excepcion");
        }
    }
    
    @Test
    public void testRealizaReservaC3() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        System.out.println("testRealizaReservaC3");
        String login = "ppss";
        String password = "ppss";
        String socio = "Pepe";
        String[] isbns = {"11111"};
        IOperacionBO mockOperacion = EasyMock.createStrictMock(IOperacionBO.class);
        FactoriaBOs mockFactoria = EasyMock.createMock(FactoriaBOs.class);
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        try {
            
            mockOperacion.operacionReserva(socio, isbns[0]);
            EasyMock.expectLastCall().andThrow(new IsbnInvalidoException());
            
            EasyMock.expect(mockFactoria.getOperacionBO()).andReturn(mockOperacion);
            
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(mockFactoria);
            
            EasyMock.replay(mockOperacion, mockFactoria, instance);
            instance.realizaReserva(login, password, socio, isbns);
            
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "ISBN invalido:11111; ";
            assertEquals(resultadoEsperado, ex.getMessage());
            EasyMock.verify(mockOperacion, mockFactoria, instance);
        }
    }
    
    @Test
    public void testRealizaReservaC4() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        System.out.println("testRealizaReservaC4");
        String login = "ppss";
        String password = "ppss";
        String socio = "Luis";
        String[] isbns = {"11111"};
        IOperacionBO mockOperacion = EasyMock.createStrictMock(IOperacionBO.class);
        FactoriaBOs mockFactoria = EasyMock.createMock(FactoriaBOs.class);
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        try {
            
            mockOperacion.operacionReserva(socio, isbns[0]);
            EasyMock.expectLastCall().andThrow(new SocioInvalidoException());
            
            EasyMock.expect(mockFactoria.getOperacionBO()).andReturn(mockOperacion);
            
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(mockFactoria);
            
            EasyMock.replay(mockOperacion, mockFactoria, instance);
            instance.realizaReserva(login, password, socio, isbns);
            
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "SOCIO invalido; ";
            assertEquals(resultadoEsperado, ex.getMessage());
            EasyMock.verify(mockOperacion, mockFactoria, instance);
        }
    }
    
    @Test
    public void testRealizaReservaC5() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        System.out.println("testRealizaReservaC5");
        String login = "ppss";
        String password = "ppss";
        String socio = "Pepe";
        String[] isbns = {"22222"};
        IOperacionBO mockOperacion = EasyMock.createStrictMock(IOperacionBO.class);
        FactoriaBOs mockFactoria = EasyMock.createMock(FactoriaBOs.class);
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        try {
            
            mockOperacion.operacionReserva(socio, isbns[0]);
            EasyMock.expectLastCall().andThrow(new JDBCException());
            
            EasyMock.expect(mockFactoria.getOperacionBO()).andReturn(mockOperacion);
            
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(mockFactoria);
            
            EasyMock.replay(mockOperacion, mockFactoria, instance);
            instance.realizaReserva(login, password, socio, isbns);
            
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "CONEXION invalida; ";
            assertEquals(resultadoEsperado, ex.getMessage());
            EasyMock.verify(mockOperacion, mockFactoria, instance);
        }
    }
}
