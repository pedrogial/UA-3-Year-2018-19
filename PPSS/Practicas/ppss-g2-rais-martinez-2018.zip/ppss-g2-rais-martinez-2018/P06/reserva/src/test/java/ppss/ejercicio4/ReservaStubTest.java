/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio4;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import ppss.ejercicio4.excepciones.IsbnInvalidoException;
import ppss.ejercicio4.excepciones.JDBCException;
import ppss.ejercicio4.excepciones.ReservaException;
import ppss.ejercicio4.excepciones.SocioInvalidoException;

/**
 *
 * @author ppss
 */
public class ReservaStubTest {
    
    public ReservaStubTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }
    
    /**
     * Test of realizaReserva method, of class Reserva.
     */
    @Test
    public void testRealizaReservaC1() throws Exception {
       System.out.println("testRealizaReservaC1");
        String login = "xxxx";
        String password = "xxxx";
        String socio = "Pepe";
        String[] isbns = {"22222"};
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethod("compruebaPermisos").createMock();
        try {
            
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.replay(instance);
            
            instance.realizaReserva(login, password, socio, isbns);
            
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "ERROR de permisos; ";
            assertEquals(resultadoEsperado, ex.getMessage());
        }
    }
    
    @Test
    public void testRealizaReservaC2() throws Exception {
       System.out.println("testRealizaReservaC2");
        String login = "ppss";
        String password = "ppss";
        String socio = "Pepe";
        String[] isbns = {"22222", "33333"};
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        FactoriaBOs stubFactoria = EasyMock.createNiceMock(FactoriaBOs.class);
        IOperacionBO stubOperacion = EasyMock.createNiceMock(IOperacionBO.class);
        try {
            EasyMock.expect(stubFactoria.getOperacionBO()).andStubReturn(stubOperacion);
            
            stubOperacion.operacionReserva(socio, isbns[0]);
            stubOperacion.operacionReserva(socio, isbns[1]);
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(stubFactoria);
            
            EasyMock.replay(stubFactoria, stubOperacion, instance);
            
            instance.realizaReserva(login, password, socio, isbns);
        } catch (ReservaException ex) {
            fail("No deberia haberse producido una excepcion");
        }
    }
    
    @Test
    public void testRealizaReservaC3() throws Exception {
       System.out.println("testRealizaReservaC3");
        String login = "ppss";
        String password = "ppss";
        String socio = "Pepe";
        String[] isbns = {"11111"};
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        FactoriaBOs stubFactoria = EasyMock.createNiceMock(FactoriaBOs.class);
        IOperacionBO stubOperacion = EasyMock.createNiceMock(IOperacionBO.class);
        try {
            EasyMock.expect(stubFactoria.getOperacionBO()).andStubReturn(stubOperacion);
            
            stubOperacion.operacionReserva(socio, isbns[0]);
            EasyMock.expectLastCall().andStubThrow(new IsbnInvalidoException()); 
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(stubFactoria);
            
            EasyMock.replay(stubFactoria, stubOperacion, instance);
            
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "ISBN invalido:11111; ";
            assertEquals(resultadoEsperado, ex.getMessage());
        }
    }
    
    @Test
    public void testRealizaReservaC4() throws Exception {
       System.out.println("testRealizaReservaC4");
        String login = "ppss";
        String password = "ppss";
        String socio = "Luis";
        String[] isbns = {"22222"};
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        FactoriaBOs stubFactoria = EasyMock.createNiceMock(FactoriaBOs.class);
        IOperacionBO stubOperacion = EasyMock.createNiceMock(IOperacionBO.class);
        try {
            EasyMock.expect(stubFactoria.getOperacionBO()).andStubReturn(stubOperacion);
            
            stubOperacion.operacionReserva(socio, isbns[0]);
            EasyMock.expectLastCall().andStubThrow(new SocioInvalidoException()); 
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(stubFactoria);
            
            EasyMock.replay(stubFactoria, stubOperacion, instance);
            
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "SOCIO invalido; ";
            assertEquals(resultadoEsperado, ex.getMessage());
        }
    }
    
    @Test
    public void testRealizaReservaC5() throws Exception {
       System.out.println("testRealizaReservaC4");
        String login = "ppss";
        String password = "ppss";
        String socio = "Pepe";
        String[] isbns = {"22222"};
        Reserva instance = EasyMock.partialMockBuilder(Reserva.class).addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        FactoriaBOs stubFactoria = EasyMock.createNiceMock(FactoriaBOs.class);
        IOperacionBO stubOperacion = EasyMock.createNiceMock(IOperacionBO.class);
        try {
            EasyMock.expect(stubFactoria.getOperacionBO()).andStubReturn(stubOperacion);
            
            stubOperacion.operacionReserva(socio, isbns[0]);
            EasyMock.expectLastCall().andStubThrow(new JDBCException()); 
            EasyMock.expect(instance.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(login.equals("ppss"));
            EasyMock.expect(instance.getFactoriaBOs()).andReturn(stubFactoria);
            
            EasyMock.replay(stubFactoria, stubOperacion, instance);
            
            instance.realizaReserva(login, password, socio, isbns);
            fail("Deberia haberse producido una excepcion");
        } catch (ReservaException ex) {
            String resultadoEsperado = "CONEXION invalida; ";
            assertEquals(resultadoEsperado, ex.getMessage());
        }
    }
}
