/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ppss.ejercicio4.excepciones;

/**
 *
 * @author ppss
 */
public class JDBCException extends Exception {
//no es necesario el constructor, excepto para ReservaException
}