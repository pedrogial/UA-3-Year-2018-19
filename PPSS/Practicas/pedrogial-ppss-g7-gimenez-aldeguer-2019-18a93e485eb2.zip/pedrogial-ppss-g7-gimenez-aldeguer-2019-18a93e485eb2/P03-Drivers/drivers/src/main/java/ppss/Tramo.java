package ppss;

import java.util.Objects;

public class Tramo {

    private int origen;
    private int longitud;

    public Tramo (){
        this.origen = 0;
        this.longitud = 0;
    }

    public Tramo (int o, int l){
        this.origen = o;
        this.longitud = l;
    }

    public void setOrigen(int o) {
        this.origen = o;
    }

    public void setLongitud(int l){
        this.longitud = l;
    }

    public int getOrigen() {
        return origen;
    }

    public int getLongitud() { return longitud; }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Tramo tramo = (Tramo) o;
        return origen == tramo.origen &&
                longitud == tramo.longitud;
    }

    @Override
    public int hashCode() {
        return Objects.hash(origen, longitud);
    }
}
