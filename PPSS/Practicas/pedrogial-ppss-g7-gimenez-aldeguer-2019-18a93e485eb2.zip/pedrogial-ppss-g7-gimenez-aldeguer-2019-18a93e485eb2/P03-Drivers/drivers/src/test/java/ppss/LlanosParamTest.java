package ppss;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.*;
import org.junit.jupiter.api.Tag;
import org.junit.jupiter.params.provider.Arguments;
import org.junit.jupiter.params.provider.MethodSource;

import java.util.ArrayList;
import java.util.stream.Stream;

import static org.junit.jupiter.api.Assertions.*;

@Tag("lp")
class LlanosParamTest {

    @ParameterizedTest
    @MethodSource("casosDePrueba")
    void testParametrizado(boolean esperado, ArrayList<Integer> lecturas, int o, int l){
        Tramo tra1= new Tramo(o, l);
        Llanos lla = new Llanos();
        Tramo tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(esperado, tra1.equals(tra2));
    }

    private static Stream<Arguments> casosDePrueba(){
        LlanosParamTest lt= new LlanosParamTest();
        return Stream.of(
                Arguments.of(true, lt.generarCombinaciones(1), 0, 0),
                Arguments.of(true, lt.generarCombinaciones(2), 0, 3),
                Arguments.of(true, lt.generarCombinaciones(3), 2, 2),
                Arguments.of(true, lt.generarCombinaciones(4), 0, 0),
                Arguments.of(true, lt.generarCombinaciones(5), 0, 3),
                Arguments.of(true, lt.generarCombinaciones(6), 2, 2)
        );
    }


    ArrayList generarCombinaciones(int numero){
        ArrayList<Integer> lecturas = new ArrayList<>();
        switch (numero){
            case 1:
                lecturas.add(3);
                break;
            case 2:
                lecturas.add(100);lecturas.add(100);
                lecturas.add(100);lecturas.add(100);
                break;
            case 3:
                lecturas.add(120);lecturas.add(140);
                lecturas.add(180);lecturas.add(180);
                lecturas.add(180);
                break;
            case 4:
                lecturas.add(-1);
                break;
            case 5:
                lecturas.add(-1);lecturas.add(-1);
                lecturas.add(-1);lecturas.add(-1);
                break;
            case 6:
                lecturas.add(120);lecturas.add(140);
                lecturas.add(-10);lecturas.add(-10);
                lecturas.add(-10);
                break;
            default:
                break;
        }
        return lecturas;
    }
}