package ppss;


import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Tag;
import static org.junit.jupiter.api.Assertions.*;

@Tag("l")
class LlanosTest {

    Llanos lla= new Llanos();
    Tramo tra2 = new Tramo();


    @Tag("A")
    @Test
    void C1A_buscarTramoLlanoMasLargo() {
        Tramo tra1= new Tramo(0, 0);
        ArrayList<Integer> lecturas = new ArrayList();
        lecturas.add(3);
        tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(true, tra1.equals(tra2));
    }

    @Tag("A")
    @Test
    void C2A_buscarTramoLlanoMasLargo() {
        ArrayList<Integer> lecturas = new ArrayList();
        Tramo tra1= new Tramo(0, 3);
        lecturas.add(100);lecturas.add(100);
        lecturas.add(100);lecturas.add(100);
        tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(true, tra1.equals(tra2));
    }

    @Tag("A")
    @Test
    void C3A_buscarTramoLlanoMasLargo() {
        ArrayList<Integer> lecturas = new ArrayList();
        Tramo tra1 = new Tramo(2, 2);
        lecturas.add(120);lecturas.add(140);
        lecturas.add(180);lecturas.add(180);
        lecturas.add(180);
        tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(true, tra1.equals(tra2));
    }

    @Tag("B")
    @Test
    void C1B_buscarTramoLlanoMasLargo() {
        Tramo tra1= new Tramo(0, 0);
        ArrayList<Integer> lecturas = new ArrayList();
        lecturas.add(-1);
        tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(true, tra1.equals(tra2));
    }

    @Tag("B")
    @Test
    void C2B_buscarTramoLlanoMasLargo() {
        ArrayList<Integer> lecturas = new ArrayList();
        Tramo tra1= new Tramo(0, 3);
        lecturas.add(-1);lecturas.add(-1);
        lecturas.add(-1);lecturas.add(-1);
        tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(true, tra1.equals(tra2));
    }

    @Tag("B")
    @Test
    void C3B_buscarTramoLlanoMasLargo() {
        ArrayList<Integer> lecturas = new ArrayList();
        Tramo tra1 = new Tramo(2, 2);
        lecturas.add(120);lecturas.add(140);
        lecturas.add(-10);lecturas.add(-10);
        lecturas.add(-10);
        tra2 = lla.buscarTramoLlanoMasLargo(lecturas);
        assertEquals(true, tra1.equals(tra2));
    }

}