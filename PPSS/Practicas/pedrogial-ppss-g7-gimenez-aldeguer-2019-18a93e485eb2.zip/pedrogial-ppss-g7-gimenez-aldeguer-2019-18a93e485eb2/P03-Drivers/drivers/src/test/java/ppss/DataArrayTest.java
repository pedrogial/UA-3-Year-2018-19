package ppss;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;


class DataArrayTest {

    @Test
    void C1_Test_delete() {
        int [] resultado = { 1, 3, 7, 0, 0, 0, 0, 0, 0, 0 };
        DataArray esperado = new DataArray(resultado, 3);

        int [] normal = { 1, 3, 5, 7, 0, 0, 0, 0, 0, 0 };
        DataArray data = new DataArray(normal, 4);

        assertAll("C1",
                ()-> assertArrayEquals(resultado, data.delete(5)),
                ()-> assertArrayEquals(data.getColeccion(), esperado.getColeccion()),
                ()-> assertEquals(data.size(), esperado.size())
        );
    }

    @Test
    void C2_Test_delete() {
        int [] resultado = { 1, 3, 5, 7, 0, 0, 0, 0, 0, 0 };
        DataArray esperado = new DataArray(resultado, 4);

        int [] normal = { 1, 3, 3, 5, 7, 0, 0, 0, 0, 0 };
        DataArray data = new DataArray(normal, 5);

        assertAll("C2",
                ()-> assertArrayEquals(resultado, data.delete(3)),
                ()-> assertArrayEquals(data.getColeccion(), esperado.getColeccion()),
                () -> assertEquals(data.size(), esperado.size())
        );
    }

    @Test
    void C3_Test_delete() {
        int [] resultado = { 1, 2, 3, 5, 6, 7, 8, 9, 10, 0};
        DataArray esperado = new DataArray(resultado, 9);

        int [] normal = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        DataArray data = new DataArray(normal, 10);

        assertAll("C3",
                ()-> assertArrayEquals(resultado, data.delete(4)),
                ()-> assertArrayEquals(data.getColeccion(), esperado.getColeccion()),
                () -> assertEquals(data.size(), esperado.size())
        );
    }

    @Test
    void C4_Test_delete() {

        int [] normal = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        DataArray data = new DataArray(normal, 0);
        Throwable exception = assertThrows(Exception.class,
                () -> data.delete(8));

        assertEquals("No hay elementos en la colección", exception.getMessage());
    }

    @Test
    void C5_Test_delete() {

        int [] normal = { 1, 3, 5, 7, 0, 0, 0, 0, 0, 0 };
        DataArray data = new DataArray(normal, 4);
        Throwable exception = assertThrows(Exception.class,
                () -> data.delete(-5));

        assertEquals("El valor a borrar debe ser > cero", exception.getMessage());
    }

    @Test
    void C6_Test_delete() {

        int [] normal = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
        DataArray data = new DataArray(normal, 0);
        Throwable exception = assertThrows(Exception.class,
                () -> data.delete(0));

        assertEquals("No hay elementos en la colección. Y el valor a borrar debe ser > 0", exception.getMessage());
    }

    @Test
    void C7_Test_delete() {

        int [] normal = { 1, 3, 5, 7, 0, 0, 0, 0, 0, 0 };
        DataArray data = new DataArray(normal, 4);
        Throwable exception = assertThrows(Exception.class,
                () -> data.delete(8));

        assertEquals("Elemento no encontrado", exception.getMessage());
    }
}

