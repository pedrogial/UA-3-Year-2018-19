package ppss;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DataArrayTest {
    // Hay que comparar todos los datos de entradas que hayan
    @Test
    void addC1() {
        int [] esperado = { 2, 0, 0, 0, 0,
                            0, 0, 0, 0, 0 };
        DataArray data = new DataArray();
        DataArray esp = new DataArray(esperado, 1);
        data.add(2);

        int [] real = data.getColeccion();
        assertArrayEquals(esperado, real);
        assertEquals(data.size(), esp.size());
    }

    @Test
    void addC2() {
        int [] esperado = { 2, 3, 0, 0, 0,
                            0, 0, 0, 0, 0 };
        DataArray data = new DataArray();
        DataArray esp = new DataArray(esperado, 2);

        data.add(2);
        data.add(3);
        int [] real = data.getColeccion();
        assertArrayEquals(esperado, real);
        assertEquals(data.size(), esp.size());

    }

    @Test
    void addC3() {
        int [] esperado = { 2, 3, 4, 5, 6,
                            7, 8, 9, 10, 11 };
        DataArray data = new DataArray(esperado, 10);

        data.add(2);

        int [] real = data.getColeccion();
        assertArrayEquals(esperado, real);
    }

    @Test
    void deleteC1() {
        int [] datos = { 2, 3, 4, 5, 6,
                            7, 8, 9, 10, 11 };

        int [] esperado = { 2, 4, 5, 6,
                7, 8, 9, 10, 11, 0 };

        DataArray data = new DataArray(datos, 10);
        DataArray esp = new DataArray(esperado, 9);
        int [] real = data.delete(3);
        assertArrayEquals(esperado, real);
        assertEquals(data.size(), esp.size());

    }

    @Test
    void deleteC2() {
        int [] datos = { 2, 3, 4, 5, 6,
                7, 8, 9, 10, 11 };

        int [] esperado = { 2, 3, 4, 5, 6,
                7, 8, 9, 10, 11 };

        DataArray data = new DataArray(datos, 10);
        DataArray esp = new DataArray(esperado, 10);
        int [] real = data.delete(1);
        assertArrayEquals(esperado, real);
        assertEquals(data.size(), esp.size());

    }

    @Test
    void deleteC3() {
        int [] datos = { 2, 3, 4, 5, 6,
                7, 8, 9, 10, 0 };

        int [] esperado = { 2, 3, 4, 5, 6,
                7, 8, 9, 10, 0 };

        DataArray data = new DataArray(datos, 9);
        DataArray esp = new DataArray(esperado, 9);
        int [] real = data.delete(0);
        assertArrayEquals(esperado, real);
        assertEquals(data.size(), esp.size());


    }

    @Test
    void deleteC4() {
        int [] esperado = { 0, 0, 0, 0, 0,
                            0, 0, 0, 0, 0 };

        DataArray data = new DataArray();
        DataArray esp = new DataArray(esperado, 0);
        int [] real = data.delete(3);
        assertArrayEquals(esperado, real);
        assertEquals(data.size(), esp.size());

    }
}