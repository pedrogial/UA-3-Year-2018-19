package ppss;

public class ClienteWebServiceException extends Exception{

}
