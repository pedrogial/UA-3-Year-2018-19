package ppss;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import static org.easymock.EasyMock.*;
import static org.junit.jupiter.api.Assertions.*;

class PremioTest {

    @Test
    void C1_compruebaPremio() throws ClienteWebServiceException, NullPointerException{
        String esp = "Premiado con entrada final Champions";

        ClienteWebService cmock = EasyMock.createMock(ClienteWebService.class);
        expect(cmock.obtenerPremio()).andReturn("entrada final Champions");

        Premio pmock= partialMockBuilder(Premio.class)
                .addMockedMethod("generaNumero").createMock();

        expect(pmock.generaNumero()).andReturn((float) 0.07);
        pmock.cliente = cmock;

        replay(cmock, pmock);
        assertEquals(esp, pmock.compruebaPremio());
        verify(cmock, pmock);
    }

    @Test
    void C2_compruebaPremio() throws ClienteWebServiceException{
        String esp = "No se ha podido obtener el premio";

        ClienteWebService cmock = EasyMock.createMock(ClienteWebService.class);
        expect(cmock.obtenerPremio()).andThrow(new ClienteWebServiceException());

        Premio pmock= partialMockBuilder(Premio.class)
                .addMockedMethod("generaNumero").createMock();

        expect(pmock.generaNumero()).andReturn((float) 0.03);

        pmock.cliente = cmock;

        replay(cmock, pmock);
        assertEquals(esp, pmock.compruebaPremio());
        verify(cmock, pmock);
    }

}