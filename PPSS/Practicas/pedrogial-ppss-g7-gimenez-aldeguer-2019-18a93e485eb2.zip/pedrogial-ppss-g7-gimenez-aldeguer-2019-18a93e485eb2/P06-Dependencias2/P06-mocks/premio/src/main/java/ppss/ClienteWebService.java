package ppss;

public class ClienteWebService {
    public String obtenerPremio() throws ClienteWebServiceException{

    throw new ClienteWebServiceException();

    }
}