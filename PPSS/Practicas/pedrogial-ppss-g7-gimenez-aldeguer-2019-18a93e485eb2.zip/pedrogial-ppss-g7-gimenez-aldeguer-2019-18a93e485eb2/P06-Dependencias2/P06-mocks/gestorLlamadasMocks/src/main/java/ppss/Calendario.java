package ppss;

public class Calendario {

    public int getHoraActual() {
        throw new UnsupportedOperationException
                ("Not yet implemented");
    }
}
