package ppss;

import org.easymock.EasyMock;
import org.junit.jupiter.api.Test;

import static org.easymock.EasyMock.*;
import static org.junit.jupiter.api.Assertions.*;

class GestorLlamadasTest {

    @Test
    void C1_calculaConsumo() throws UnsupportedOperationException{
        Calendario mock = EasyMock.createMock(Calendario.class);
        GestorLlamadas mockD = partialMockBuilder(GestorLlamadas.class)
                .addMockedMethod("getCalendario").createMock();

        expect(mock.getHoraActual()).andReturn(11);
        expect(mockD.getCalendario()).andReturn(mock);

        replay(mock,mockD);

        double esp = 457.6;
        assertEquals(esp, mockD.calculaConsumo(22));

        verify(mock, mockD);
    }

    @Test
    void C2_calculaConsumo() throws UnsupportedOperationException{
        Calendario mock = EasyMock.createMock(Calendario.class);

        GestorLlamadas mockD = partialMockBuilder(GestorLlamadas.class)
                                .addMockedMethod("getCalendario").createMock();

        expect(mock.getHoraActual()).andReturn(21);
        expect(mockD.getCalendario()).andReturn(mock);

        replay(mock,mockD);

        double esp = 136.5;
        assertEquals(esp, mockD.calculaConsumo(13));

        verify(mock, mockD);
    }
}