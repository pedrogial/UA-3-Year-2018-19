package ppss;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import ppss.excepciones.IsbnInvalidoException;
import ppss.excepciones.JDBCException;
import ppss.excepciones.ReservaException;
import ppss.excepciones.SocioInvalidoException;

import static org.easymock.EasyMock.*;
import static org.junit.jupiter.api.Assertions.*;

class ReservaTest {

    String login, password, socio;
    String isbns [];
    Reserva rmock;
    FactoriaBOs fmock ;
    IOperacionBO iomock ;

    @BeforeEach
    void setup(){
        rmock = createMockBuilder(Reserva.class)
                .addMockedMethods("compruebaPermisos", "getFactoriaBOs").createMock();
        fmock = createMock(FactoriaBOs.class);
        iomock = createStrictMock(IOperacionBO.class);
    }

    @Test
    void CA1_realizaReserva() {
        login = "xxxx";
        password = "xxxx";
        socio = "Pepe";
        isbns = new String[]{"22222"};
        String esp = "ERROR de permisos; ";
        expect(rmock.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(false);
        replay(rmock);

        Throwable exception = assertThrows(ReservaException.class,
                () -> rmock.realizaReserva(login, password, socio, isbns));
        assertEquals(esp, exception.getMessage());

        verify(rmock);
    }

    @Test
    void CA2_realizaReserva() throws IsbnInvalidoException, JDBCException, SocioInvalidoException, ReservaException {
        login = "ppss";
        password = "ppss";
        socio = "Pepe";
        isbns = new String[]{"2222", "3333"};

        expect(rmock.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(true);
        expect(rmock.getFactoriaBOs()).andReturn(fmock);
        expect(fmock.getOperacionBO()).andReturn(iomock);

        for (String isbn : isbns) {
            iomock.operacionReserva(socio, isbn);
        }

        replay(rmock, iomock, fmock);

        rmock.realizaReserva(login, password, socio, isbns);

        verify(rmock, iomock, fmock);
    }

    @Test
    void CA3_realizaReserva() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        login = "ppss";
        password = "ppss";
        socio = "Pepe";
        isbns = new String[]{"11111"};
        String esp = "ISBN invalido:11111; ";

        expect(rmock.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(true);
        expect(rmock.getFactoriaBOs()).andReturn(fmock);
        expect(fmock.getOperacionBO()).andReturn(iomock);

        for (String isbn : isbns) {
            iomock.operacionReserva(socio, isbn);
        }
        expectLastCall().andThrow(new IsbnInvalidoException());

        replay(rmock, iomock, fmock);
        Throwable exception = assertThrows(ReservaException.class,
                () -> rmock.realizaReserva(login, password, socio, isbns));
        assertEquals(esp, exception.getMessage());

        verify(rmock, iomock, fmock);
    }

    @Test
    void CA4_realizaReserva() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        login = "ppss";
        password = "ppss";
        socio = "Pepe";
        isbns = new String[]{"22222"};
        String esp = "CONEXION invalida; ";

        expect(rmock.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(true);
        expect(rmock.getFactoriaBOs()).andReturn(fmock);
        expect(fmock.getOperacionBO()).andReturn(iomock);

        for (String isbn : isbns) {
            iomock.operacionReserva(socio, isbn);
        }
        expectLastCall().andThrow(new JDBCException());

        replay(rmock, iomock, fmock);
        Throwable exception = assertThrows(ReservaException.class,
                () -> rmock.realizaReserva(login, password, socio, isbns));
        assertEquals(esp, exception.getMessage());

        verify(rmock, iomock, fmock);
    }

    @Test
    void CA5_realizaReserva() throws IsbnInvalidoException, JDBCException, SocioInvalidoException {
        login = "ppss";
        password = "ppss";
        socio = "Luis";
        isbns = new String[]{"22222"};
        String esp = "SOCIO invalido; ";

        expect(rmock.compruebaPermisos(login, password, Usuario.BIBLIOTECARIO)).andReturn(true);
        expect(rmock.getFactoriaBOs()).andReturn(fmock);
        expect(fmock.getOperacionBO()).andReturn(iomock);

        for (String isbn : isbns) {
            iomock.operacionReserva(socio, isbn);
        }
        expectLastCall().andThrow(new SocioInvalidoException());

        replay(rmock, iomock, fmock);
        Throwable exception = assertThrows(ReservaException.class,
                () -> rmock.realizaReserva(login, password, socio, isbns));
        assertEquals(esp, exception.getMessage());

        verify(rmock, iomock, fmock);
    }

}