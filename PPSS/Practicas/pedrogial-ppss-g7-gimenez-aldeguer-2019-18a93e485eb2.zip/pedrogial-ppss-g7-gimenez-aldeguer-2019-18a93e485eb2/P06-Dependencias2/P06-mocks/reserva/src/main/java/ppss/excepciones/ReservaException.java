package ppss.excepciones;

public class ReservaException extends Throwable {
    public ReservaException(String message) {
        super(message);
    }
}
