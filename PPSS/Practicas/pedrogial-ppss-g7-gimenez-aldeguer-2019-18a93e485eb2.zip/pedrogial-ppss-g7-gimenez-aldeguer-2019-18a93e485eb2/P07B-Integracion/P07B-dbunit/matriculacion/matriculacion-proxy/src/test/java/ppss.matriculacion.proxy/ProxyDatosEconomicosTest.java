package ppss.matriculacion.proxy;

import org.junit.jupiter.api.Test;

class ProxyDatosEconomicosTest {

    @Test
    void getDatosEconomicosAlumno() {
    }
}