package ppss.matriculacion.proxy;

import org.junit.jupiter.api.Test;



class ProxyDatosEconomicosIT {

    @Test
    void getDatosEconomicosAlumno() {
    }
}