package ppss.matriculacion.dao;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

@Tag("Integracion-fase1")
public class JDBCAlumnoDAOTest {

    @Test
    void TU1() {

    }

    @Test
    void TU2() {

    }

    @Test
    void TU3() {

    }
}
