package ppss.matriculacion.bo;

import org.junit.jupiter.api.Test;


class AlumnoBRIT {

        @Test
        void BU1() {

        }

        @Test
        void BU2() {

        }

}
