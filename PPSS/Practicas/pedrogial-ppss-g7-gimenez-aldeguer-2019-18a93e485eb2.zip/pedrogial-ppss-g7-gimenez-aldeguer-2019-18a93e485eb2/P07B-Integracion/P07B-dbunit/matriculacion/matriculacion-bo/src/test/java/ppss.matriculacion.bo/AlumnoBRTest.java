package ppss.matriculacion.bo;

import org.junit.jupiter.api.Test;


class AlumnoBRTest {

        @Test
        void BO1() {

        }

        @Test
        void BO2() {

        }

}
