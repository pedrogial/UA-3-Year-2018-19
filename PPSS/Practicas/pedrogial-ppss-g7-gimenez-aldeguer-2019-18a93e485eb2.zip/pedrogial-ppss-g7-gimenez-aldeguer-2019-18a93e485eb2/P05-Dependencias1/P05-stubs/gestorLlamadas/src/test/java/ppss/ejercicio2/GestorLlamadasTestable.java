package ppss.ejercicio2;

public class GestorLlamadasTestable extends GestorLlamadas{
    int hora;

    @Override
    public Calendario getCalendario(){
        Calendario c = new CalendarioStub(this.hora);
        return c;
    }
}
