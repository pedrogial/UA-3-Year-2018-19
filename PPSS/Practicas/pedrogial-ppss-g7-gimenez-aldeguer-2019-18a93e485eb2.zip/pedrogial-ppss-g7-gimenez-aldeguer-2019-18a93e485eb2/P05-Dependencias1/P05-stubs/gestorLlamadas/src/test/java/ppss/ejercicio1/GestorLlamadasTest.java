package ppss.ejercicio1;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GestorLlamadasTest {

    @Test
    void C1_CalculaConsumo(){
        GestorLlamadas g = new GestorLlamadasStub();
        ((GestorLlamadasStub)g).hora = 15;
        double realResult = g.calculaConsumo(10);
        assertEquals(208, realResult);
    }

    @Test
    void C2_CalculaConsumo(){
        GestorLlamadas g = new GestorLlamadasStub();
        ((GestorLlamadasStub)g).hora = 22;
        double realResult = g.calculaConsumo(10);
        assertEquals(105, realResult);
    }
}