package ppss.ejercicio2;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class GestorLlamadasTest {

    @Test
    void C1_calculaConsumo() {
        GestorLlamadas g = new GestorLlamadasTestable();
        ((GestorLlamadasTestable)g).hora = 15;
        double realResult = g.calculaConsumo(10);
        assertEquals(208, realResult);
    }

    @Test
    void C2_calculaConsumo() {
        GestorLlamadas g = new GestorLlamadasTestable();
        ((GestorLlamadasTestable)g).hora = 22;
        double realResult = g.calculaConsumo(10);
        assertEquals(105, realResult);
    }
}