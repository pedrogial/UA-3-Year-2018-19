package ppss.ejercicio1;

import java.util.Calendar;

public class GestorLlamadasStub extends GestorLlamadas {
    public int hora;

    @Override
    public int getHoraActual() {
        return hora;
    }
}
