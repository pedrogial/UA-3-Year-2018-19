package ppss;

public class ReservaTestable extends Reserva{
    IOperacionBO op;

    @Override
    public IOperacionBO getBuscador() {
        return op;
    }

    public void setOperacion(IOperacionBO op){
        this.op = op;
    }

    public boolean compruebaPermisos(String login, String password, Usuario tipoUsu) {
        String aux = "ppss";
        return login.equals(aux) && password.equals(aux) && tipoUsu.equals(Usuario.BIBLIOTECARIO);
    }
}
