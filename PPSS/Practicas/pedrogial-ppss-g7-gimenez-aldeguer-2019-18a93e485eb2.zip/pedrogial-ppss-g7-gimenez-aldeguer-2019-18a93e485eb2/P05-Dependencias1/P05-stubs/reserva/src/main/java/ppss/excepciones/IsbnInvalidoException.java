package ppss.excepciones;

public class IsbnInvalidoException extends Exception{
}
