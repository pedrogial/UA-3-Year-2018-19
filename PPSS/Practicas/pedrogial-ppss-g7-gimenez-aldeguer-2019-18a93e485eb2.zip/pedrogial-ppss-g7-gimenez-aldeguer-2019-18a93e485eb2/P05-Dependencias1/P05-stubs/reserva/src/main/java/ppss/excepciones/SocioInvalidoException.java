package ppss.excepciones;

public class SocioInvalidoException extends Exception{
}
