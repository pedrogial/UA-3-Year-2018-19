package ppss;

import ppss.excepciones.IsbnInvalidoException;
import ppss.excepciones.JDBCException;
import ppss.excepciones.SocioInvalidoException;

public class OperacionStub implements IOperacionBO{
    boolean jdbc;

    public OperacionStub(boolean jdbc){
        this.jdbc = jdbc;
    }

    public void operacionReserva(String socio, String isbn)
            throws JDBCException, SocioInvalidoException, IsbnInvalidoException {

        String socioRegistrado = "Luis";
        String isbnRegistrados [] = {"1111","2222"};

        if(!jdbc){

            throw new JDBCException();

        } else if (!socio.equals(socioRegistrado)){

            throw new SocioInvalidoException();

        } else {
            boolean flag = false;

            for (int i = 0; i < isbnRegistrados.length; i++){
                if(isbn.equals(isbnRegistrados[i])) { flag = true; }
            }

            if (!flag) {
                throw new IsbnInvalidoException();
            }
        }
    }
}
