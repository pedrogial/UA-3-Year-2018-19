package ppss;

public enum Usuario {
    BIBLIOTECARIO, ALUMNO, PROFESOR
}
