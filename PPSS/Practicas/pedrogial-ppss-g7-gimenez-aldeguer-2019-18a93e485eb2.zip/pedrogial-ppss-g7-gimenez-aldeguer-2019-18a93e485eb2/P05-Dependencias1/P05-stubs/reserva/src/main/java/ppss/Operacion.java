package ppss;

public class Operacion implements IOperacionBO {

    public void operacionReserva(String socio, String isbn){

    }
}
