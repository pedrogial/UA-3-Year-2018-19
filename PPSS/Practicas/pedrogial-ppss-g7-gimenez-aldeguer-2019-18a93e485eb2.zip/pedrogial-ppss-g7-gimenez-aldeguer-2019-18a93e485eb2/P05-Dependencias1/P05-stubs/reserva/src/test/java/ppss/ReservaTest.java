package ppss;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

import ppss.excepciones.ReservaException;

class ReservaTest {

    Reserva reserva = new ReservaTestable();
    String login, password, socio;
    String isbns [];

    @Test
    void C1_realizaReserva() {
        OperacionStub stub = new OperacionStub(true);
        ((ReservaTestable)reserva).setOperacion(stub);
        login = "xxxx";
        password = "xxxx";
        socio = "Luis";
        isbns = new String[]{"1111"};

        Throwable exception = assertThrows(ReservaException.class,
                () -> reserva.realizaReserva(login, password, socio, isbns));

        assertEquals("ERROR de permisos; ",exception.getMessage() );
    }

    @Test
    public void C2_realizaReserva() throws ReservaException {
        OperacionStub stub = new OperacionStub(true);
        ((ReservaTestable)reserva).setOperacion(stub);
        login = "ppss";
        password = "ppss";
        socio = "Luis";
        isbns = new String[]{"1111", "2222"};
    }

    @Test
    public void C3_realizaReserva() throws ReservaException {
        OperacionStub stub = new OperacionStub(true);
        ((ReservaTestable)reserva).setOperacion(stub);
        login = "ppss";
        password = "ppss";
        socio = "Luis";
        isbns = new String[]{"3333"};

        Throwable exception = assertThrows(ReservaException.class,
                () -> reserva.realizaReserva(login, password, socio, isbns));

        assertEquals("ISBN invalido:3333; ",exception.getMessage() );
    }

    @Test
    public void C4_realizaReserva() throws ReservaException {
        OperacionStub stub = new OperacionStub(true);
        ((ReservaTestable)reserva).setOperacion(stub);
        login = "ppss";
        password = "ppss";
        socio = "Pepe";
        isbns = new String[]{"1111"};

        Throwable exception = assertThrows(ReservaException.class,
                () -> reserva.realizaReserva(login, password, socio, isbns));

        assertEquals("SOCIO invalido; ",exception.getMessage() );
    }

    @Test
    public void C5_realizaReserva() throws ReservaException {
        OperacionStub stub = new OperacionStub(false);
        ((ReservaTestable)reserva).setOperacion(stub);
        login = "ppss";
        password = "ppss";
        socio = "Luis";
        isbns = new String[]{"1111"};

        Throwable exception = assertThrows(ReservaException.class,
                () -> reserva.realizaReserva(login, password, socio, isbns));

        assertEquals("CONEXION invalida; ",exception.getMessage() );
    }
}